import { AuthenticationConfigurationProps } from './skill/AuthenticationConfigurationProps';
import { Value } from '../../kloudformation/Value';
import { SkillPackageProps } from './skill/SkillPackageProps';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>Alexa::ASK::Skill</code> resource creates an Alexa skill that enables customers to access new abilities. For more information about developing a skill, see the <a href="https://developer.amazon.com/docs/ask-overviews/build-skills-with-the-alexa-skills-kit.html">Build Skills with the Alexa Skills Kit developer documentation</a>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ask-skill.html">the AWS Docs</a>
*/
export declare type Skill = SkillProperties;
export declare function skill(skillProps: SkillProperties): Skill;
/**
  The <code>Alexa::ASK::Skill</code> resource creates an Alexa skill that enables customers to access new abilities. For more information about developing a skill, see the <a href="https://developer.amazon.com/docs/ask-overviews/build-skills-with-the-alexa-skills-kit.html">Build Skills with the Alexa Skills Kit developer documentation</a>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ask-skill.html">the AWS Docs</a>
*/
export interface SkillProperties extends KloudResource {
    /** <code>AuthenticationConfiguration</code>  <a name="cfn-ask-skill-authenticationconfiguration"></a>
  Login with Amazon (LWA) configuration used to authenticate with the Alexa service. Only Login with Amazon clients created through the <a href="https://developer.amazon.com/lwa/sp/overview.html">Amazon Developer Console</a> are supported. The client ID, client secret, and refresh token are required.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    authenticationConfiguration: AuthenticationConfigurationProps;
    /** <code>VendorId</code>  <a name="cfn-ask-skill-vendorid"></a>
  The vendor ID associated with the Amazon developer account that will host the skill. Details for retrieving the vendor ID are in <a href="https://github.com/alexa/alexa-smarthome/wiki/How-to-get-your-vendor-ID">How to get your vendor ID</a>. The provided LWA credentials must be linked to the developer account associated with this vendor ID.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    vendorId: Value<string>;
    /** <code>SkillPackage</code>  <a name="cfn-ask-skill-skillpackage"></a>
  Configuration for the skill package that contains the components of the Alexa skill. Skill packages are retrieved from an Amazon S3 bucket and key and used to create and update the skill. For more information about the skill package format, see the <a href="https://developer.amazon.com/docs/smapi/skill-package-api-reference.html#skill-package-format">Skill Package API Reference</a>.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    skillPackage: SkillPackageProps;
}
