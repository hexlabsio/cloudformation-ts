import { Value } from '../../../kloudformation/Value';
/**
  The <code>AuthenticationConfiguration</code> property type specifies the Login with Amazon (LWA) configuration used to authenticate with the Alexa service. Only Login with Amazon security profiles created through the <a href="https://developer.amazon.com/docs/ask-overviews/build-skills-with-the-alexa-skills-kit.html">Build Skills with the Alexa Skills Kit developer documentation</a> are supported for authentication. A client ID, client secret, and refresh token are required. You can generate a client ID and client secret by creating a new <a href="https://developer.amazon.com/lwa/sp/create-security-profile.html">security profile</a> on the Amazon Developer Portal or you can retrieve them from an existing profile. You can then retrieve the refresh token using the Alexa Skills Kit CLI. For instructions, see <a href="https://developer.amazon.com/docs/smapi/ask-cli-command-reference.html#util-command">util-command</a> in the <a href="https://developer.amazon.com/docs/smapi/ask-cli-command-reference.html">ASK CLI Command Reference</a>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ask-skill-authenticationconfiguration.html">the AWS Docs</a>
*/
export interface AuthenticationConfigurationProps {
    /** <code>RefreshToken</code>  <a name="cfn-ask-skill-authenticationconfiguration-refreshtoken"></a>
  Refresh token from Login with Amazon (LWA). This token is secret.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    refreshToken: Value<string>;
    /** <code>ClientSecret</code>  <a name="cfn-ask-skill-authenticationconfiguration-clientsecret"></a>
  Client secret from Login with Amazon (LWA).<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    clientSecret: Value<string>;
    /** <code>ClientId</code>  <a name="cfn-ask-skill-authenticationconfiguration-clientid"></a>
  Client ID from Login with Amazon (LWA).<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    clientId: Value<string>;
}
