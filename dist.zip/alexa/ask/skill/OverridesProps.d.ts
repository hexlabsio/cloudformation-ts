import { Value } from '../../../kloudformation/Value';
/**
  The <code>Overrides</code> property type provides overrides to the skill package to apply when creating or updating the skill. Values provided here do not modify the contents of the original skill package. Currently, only overriding values inside of the skill manifest component of the package is supported.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ask-skill-overrides.html">the AWS Docs</a>
*/
export interface OverridesProps {
    /** <code>Manifest</code>  <a name="cfn-ask-skill-overrides-manifest"></a>
  Overrides to apply to the skill manifest inside of the skill package. The skill manifest contains metadata about the skill. For more information, see <a href="https://developer.amazon.com/docs/smapi/skill-manifest.html">Skill Manifest Schemas</a>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    manifest?: Value<any>;
}
