import { Value } from '../../../kloudformation/Value';
import { OverridesProps } from './OverridesProps';
/**
  The <code>SkillPackage</code> property type contains configuration details for the skill package that contains the components of the Alexa skill. Skill packages are retrieved from an Amazon S3 bucket and key and used to create and update the skill. More details about the skill package format are located in the <a href="https://developer.amazon.com/docs/smapi/skill-package-api-reference.html#skill-package-format">Skill Package API Reference</a>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ask-skill-skillpackage.html">the AWS Docs</a>
*/
export interface SkillPackageProps {
    /** <code>S3BucketRole</code>  <a name="cfn-ask-skill-skillpackage-s3bucketrole"></a>
  ARN of the IAM role that grants the Alexa service (<code>alexa-appkit.amazon.com</code>) permission to access the bucket and retrieve the skill package. This property is optional. If you do not provide it, the bucket must be publicly accessible or configured with a policy that allows this access. Otherwise, AWS CloudFormation cannot create the skill.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    s3BucketRole?: Value<string>;
    /** <code>S3ObjectVersion</code>  <a name="cfn-ask-skill-skillpackage-s3objectversion"></a>
  If you have S3 versioning enabled, the version ID of the skill package.zip file.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    s3ObjectVersion?: Value<string>;
    /** <code>S3Bucket</code>  <a name="cfn-ask-skill-skillpackage-s3bucket"></a>
  The name of the Amazon S3 bucket where the .zip file that contains the skill package is stored.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    s3Bucket: Value<string>;
    /** <code>S3Key</code>  <a name="cfn-ask-skill-skillpackage-s3key"></a>
  The location and name of the skill package .zip file.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    s3Key: Value<string>;
    /** <code>Overrides</code>  <a name="cfn-ask-skill-skillpackage-overrides"></a>
  Overrides to the skill package to apply when creating or updating the skill. Values provided here do not modify the contents of the original skill package. Currently, only overriding values inside of the skill manifest component of the package is supported.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    overrides?: OverridesProps;
}
