"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function skill(skillProps) { return ({ ...skillProps, _logicalType: 'Alexa::ASK::Skill' }); }
exports.skill = skill;
