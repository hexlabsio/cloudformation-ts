import { Value } from '../../../kloudformation/Value';
/**
  The <code>AmplitudeConnectorProfileCredentials</code> property type specifies the connector-specific credentials required when using Amplitude.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-connectorprofile-amplitudeconnectorprofilecredentials.html">the AWS Docs</a>
*/
export interface AmplitudeConnectorProfileCredentialsProps {
    /** <code>ApiKey</code>  <a name="cfn-appflow-connectorprofile-amplitudeconnectorprofilecredentials-apikey"></a>
  A unique alphanumeric identifier used to authenticate a user, developer, or calling program to your API.<br />
  
  Required: Yes<br />
  
  Maximum: <code>256</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    apiKey: Value<string>;
    /** <code>SecretKey</code>  <a name="cfn-appflow-connectorprofile-amplitudeconnectorprofilecredentials-secretkey"></a>
  The Secret Access Key portion of the credentials.<br />
  
  Required: Yes<br />
  
  Maximum: <code>256</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    secretKey: Value<string>;
}
