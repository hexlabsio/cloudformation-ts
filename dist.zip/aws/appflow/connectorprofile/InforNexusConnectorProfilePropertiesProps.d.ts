import { Value } from '../../../kloudformation/Value';
/**
  The <code>InforNexusConnectorProfileProperties</code> property type specifies the connector-specific profile properties required by Infor Nexus.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-connectorprofile-infornexusconnectorprofileproperties.html">the AWS Docs</a>
*/
export interface InforNexusConnectorProfilePropertiesProps {
    /** <code>InstanceUrl</code>  <a name="cfn-appflow-connectorprofile-infornexusconnectorprofileproperties-instanceurl"></a>
  The location of the Infor Nexus resource.<br />
  
  Required: Yes<br />
  
  Maximum: <code>256</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    instanceUrl: Value<string>;
}
