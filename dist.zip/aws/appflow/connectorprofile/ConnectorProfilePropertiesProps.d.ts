import { DatadogConnectorProfilePropertiesProps } from './DatadogConnectorProfilePropertiesProps';
import { DynatraceConnectorProfilePropertiesProps } from './DynatraceConnectorProfilePropertiesProps';
import { InforNexusConnectorProfilePropertiesProps } from './InforNexusConnectorProfilePropertiesProps';
import { MarketoConnectorProfilePropertiesProps } from './MarketoConnectorProfilePropertiesProps';
import { RedshiftConnectorProfilePropertiesProps } from './RedshiftConnectorProfilePropertiesProps';
import { SalesforceConnectorProfilePropertiesProps } from './SalesforceConnectorProfilePropertiesProps';
import { ServiceNowConnectorProfilePropertiesProps } from './ServiceNowConnectorProfilePropertiesProps';
import { SlackConnectorProfilePropertiesProps } from './SlackConnectorProfilePropertiesProps';
import { SnowflakeConnectorProfilePropertiesProps } from './SnowflakeConnectorProfilePropertiesProps';
import { VeevaConnectorProfilePropertiesProps } from './VeevaConnectorProfilePropertiesProps';
import { ZendeskConnectorProfilePropertiesProps } from './ZendeskConnectorProfilePropertiesProps';
/**
  The <code>ConnectorProfileProperties</code> property type specifies the connector-specific profile properties required by each connector.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-connectorprofile-connectorprofileproperties.html">the AWS Docs</a>
*/
export interface ConnectorProfilePropertiesProps {
    /** <code>Datadog</code>  <a name="cfn-appflow-connectorprofile-connectorprofileproperties-datadog"></a>
  The connector-specific properties required by Datadog.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    datadog?: DatadogConnectorProfilePropertiesProps;
    /** <code>Dynatrace</code>  <a name="cfn-appflow-connectorprofile-connectorprofileproperties-dynatrace"></a>
  The connector-specific properties required by Dynatrace.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    dynatrace?: DynatraceConnectorProfilePropertiesProps;
    /** <code>InforNexus</code>  <a name="cfn-appflow-connectorprofile-connectorprofileproperties-infornexus"></a>
  The connector-specific properties required by Infor Nexus.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    inforNexus?: InforNexusConnectorProfilePropertiesProps;
    /** <code>Marketo</code>  <a name="cfn-appflow-connectorprofile-connectorprofileproperties-marketo"></a>
  The connector-specific properties required by Marketo.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    marketo?: MarketoConnectorProfilePropertiesProps;
    /** <code>Redshift</code>  <a name="cfn-appflow-connectorprofile-connectorprofileproperties-redshift"></a>
  The connector-specific properties required by Amazon Redshift.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    redshift?: RedshiftConnectorProfilePropertiesProps;
    /** <code>Salesforce</code>  <a name="cfn-appflow-connectorprofile-connectorprofileproperties-salesforce"></a>
  The connector-specific properties required by Salesforce.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    salesforce?: SalesforceConnectorProfilePropertiesProps;
    /** <code>ServiceNow</code>  <a name="cfn-appflow-connectorprofile-connectorprofileproperties-servicenow"></a>
  The connector-specific properties required by serviceNow.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    serviceNow?: ServiceNowConnectorProfilePropertiesProps;
    /** <code>Slack</code>  <a name="cfn-appflow-connectorprofile-connectorprofileproperties-slack"></a>
  The connector-specific properties required by Slack.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    slack?: SlackConnectorProfilePropertiesProps;
    /** <code>Snowflake</code>  <a name="cfn-appflow-connectorprofile-connectorprofileproperties-snowflake"></a>
  The connector-specific properties required by Snowflake.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    snowflake?: SnowflakeConnectorProfilePropertiesProps;
    /** <code>Veeva</code>  <a name="cfn-appflow-connectorprofile-connectorprofileproperties-veeva"></a>
  The connector-specific properties required by Veeva.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    veeva?: VeevaConnectorProfilePropertiesProps;
    /** <code>Zendesk</code>  <a name="cfn-appflow-connectorprofile-connectorprofileproperties-zendesk"></a>
  The connector-specific properties required by Zendesk.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    zendesk?: ZendeskConnectorProfilePropertiesProps;
}
