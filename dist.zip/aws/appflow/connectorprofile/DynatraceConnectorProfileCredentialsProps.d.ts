import { Value } from '../../../kloudformation/Value';
/**
  The <code>DynatraceConnectorProfileCredentials</code> property type specifies the connector-specific profile credentials required by Dynatrace.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-connectorprofile-dynatraceconnectorprofilecredentials.html">the AWS Docs</a>
*/
export interface DynatraceConnectorProfileCredentialsProps {
    /** <code>ApiToken</code>  <a name="cfn-appflow-connectorprofile-dynatraceconnectorprofilecredentials-apitoken"></a>
  The API tokens used by Dynatrace API to authenticate various API calls.<br />
  
  Required: Yes<br />
  
  Maximum: <code>256</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    apiToken: Value<string>;
}
