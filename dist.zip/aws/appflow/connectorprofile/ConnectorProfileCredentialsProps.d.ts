import { AmplitudeConnectorProfileCredentialsProps } from './AmplitudeConnectorProfileCredentialsProps';
import { DatadogConnectorProfileCredentialsProps } from './DatadogConnectorProfileCredentialsProps';
import { DynatraceConnectorProfileCredentialsProps } from './DynatraceConnectorProfileCredentialsProps';
import { GoogleAnalyticsConnectorProfileCredentialsProps } from './GoogleAnalyticsConnectorProfileCredentialsProps';
import { InforNexusConnectorProfileCredentialsProps } from './InforNexusConnectorProfileCredentialsProps';
import { MarketoConnectorProfileCredentialsProps } from './MarketoConnectorProfileCredentialsProps';
import { RedshiftConnectorProfileCredentialsProps } from './RedshiftConnectorProfileCredentialsProps';
import { SalesforceConnectorProfileCredentialsProps } from './SalesforceConnectorProfileCredentialsProps';
import { ServiceNowConnectorProfileCredentialsProps } from './ServiceNowConnectorProfileCredentialsProps';
import { SingularConnectorProfileCredentialsProps } from './SingularConnectorProfileCredentialsProps';
import { SlackConnectorProfileCredentialsProps } from './SlackConnectorProfileCredentialsProps';
import { SnowflakeConnectorProfileCredentialsProps } from './SnowflakeConnectorProfileCredentialsProps';
import { TrendmicroConnectorProfileCredentialsProps } from './TrendmicroConnectorProfileCredentialsProps';
import { VeevaConnectorProfileCredentialsProps } from './VeevaConnectorProfileCredentialsProps';
import { ZendeskConnectorProfileCredentialsProps } from './ZendeskConnectorProfileCredentialsProps';
/**
  The <code>ConnectorProfileCredentials</code> property type specifies the connector-specific credentials required by a given connector.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-connectorprofile-connectorprofilecredentials.html">the AWS Docs</a>
*/
export interface ConnectorProfileCredentialsProps {
    /** <code>Amplitude</code>  <a name="cfn-appflow-connectorprofile-connectorprofilecredentials-amplitude"></a>
  The connector-specific credentials required when using Amplitude.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    amplitude?: AmplitudeConnectorProfileCredentialsProps;
    /** <code>Datadog</code>  <a name="cfn-appflow-connectorprofile-connectorprofilecredentials-datadog"></a>
  The connector-specific credentials required when using Datadog.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    datadog?: DatadogConnectorProfileCredentialsProps;
    /** <code>Dynatrace</code>  <a name="cfn-appflow-connectorprofile-connectorprofilecredentials-dynatrace"></a>
  The connector-specific credentials required when using Dynatrace.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    dynatrace?: DynatraceConnectorProfileCredentialsProps;
    /** <code>GoogleAnalytics</code>  <a name="cfn-appflow-connectorprofile-connectorprofilecredentials-googleanalytics"></a>
  The connector-specific credentials required when using Google Analytics.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    googleAnalytics?: GoogleAnalyticsConnectorProfileCredentialsProps;
    /** <code>InforNexus</code>  <a name="cfn-appflow-connectorprofile-connectorprofilecredentials-infornexus"></a>
  The connector-specific credentials required when using Infor Nexus.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    inforNexus?: InforNexusConnectorProfileCredentialsProps;
    /** <code>Marketo</code>  <a name="cfn-appflow-connectorprofile-connectorprofilecredentials-marketo"></a>
  The connector-specific credentials required when using Marketo.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    marketo?: MarketoConnectorProfileCredentialsProps;
    /** <code>Redshift</code>  <a name="cfn-appflow-connectorprofile-connectorprofilecredentials-redshift"></a>
  The connector-specific credentials required when using Amazon Redshift.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    redshift?: RedshiftConnectorProfileCredentialsProps;
    /** <code>Salesforce</code>  <a name="cfn-appflow-connectorprofile-connectorprofilecredentials-salesforce"></a>
  The connector-specific credentials required when using Salesforce.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    salesforce?: SalesforceConnectorProfileCredentialsProps;
    /** <code>ServiceNow</code>  <a name="cfn-appflow-connectorprofile-connectorprofilecredentials-servicenow"></a>
  The connector-specific credentials required when using ServiceNow.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    serviceNow?: ServiceNowConnectorProfileCredentialsProps;
    /** <code>Singular</code>  <a name="cfn-appflow-connectorprofile-connectorprofilecredentials-singular"></a>
  The connector-specific credentials required when using Singular.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    singular?: SingularConnectorProfileCredentialsProps;
    /** <code>Slack</code>  <a name="cfn-appflow-connectorprofile-connectorprofilecredentials-slack"></a>
  The connector-specific credentials required when using Slack.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    slack?: SlackConnectorProfileCredentialsProps;
    /** <code>Snowflake</code>  <a name="cfn-appflow-connectorprofile-connectorprofilecredentials-snowflake"></a>
  The connector-specific credentials required when using Snowflake.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    snowflake?: SnowflakeConnectorProfileCredentialsProps;
    /** <code>Trendmicro</code>  <a name="cfn-appflow-connectorprofile-connectorprofilecredentials-trendmicro"></a>
  The connector-specific credentials required when using Trend Micro.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    trendmicro?: TrendmicroConnectorProfileCredentialsProps;
    /** <code>Veeva</code>  <a name="cfn-appflow-connectorprofile-connectorprofilecredentials-veeva"></a>
  The connector-specific credentials required when using Veeva.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    veeva?: VeevaConnectorProfileCredentialsProps;
    /** <code>Zendesk</code>  <a name="cfn-appflow-connectorprofile-connectorprofilecredentials-zendesk"></a>
  The connector-specific credentials required when using Zendesk.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    zendesk?: ZendeskConnectorProfileCredentialsProps;
}
