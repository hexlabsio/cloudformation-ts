import { Value } from '../../../kloudformation/Value';
/**
  The <code>InforNexusConnectorProfileCredentials</code> property type specifies the connector-specific profile credentials required by Infor Nexus.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-connectorprofile-infornexusconnectorprofilecredentials.html">the AWS Docs</a>
*/
export interface InforNexusConnectorProfileCredentialsProps {
    /** <code>AccessKeyId</code>  <a name="cfn-appflow-connectorprofile-infornexusconnectorprofilecredentials-accesskeyid"></a>
  The Access Key portion of the credentials.<br />
  
  Required: Yes<br />
  
  Maximum: <code>256</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    accessKeyId: Value<string>;
    /** <code>UserId</code>  <a name="cfn-appflow-connectorprofile-infornexusconnectorprofilecredentials-userid"></a>
  The identifier for the user.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    userId: Value<string>;
    /** <code>SecretAccessKey</code>  <a name="cfn-appflow-connectorprofile-infornexusconnectorprofilecredentials-secretaccesskey"></a>
  The secret key used to sign requests.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    secretAccessKey: Value<string>;
    /** <code>Datakey</code>  <a name="cfn-appflow-connectorprofile-infornexusconnectorprofilecredentials-datakey"></a>
  The encryption keys used to encrypt data.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    datakey: Value<string>;
}
