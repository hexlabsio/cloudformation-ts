import { Value } from '../../../kloudformation/Value';
/**
  The <code>ServiceNowConnectorProfileCredentials</code> property type specifies the connector-specific profile credentials required when using ServiceNow.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-connectorprofile-servicenowconnectorprofilecredentials.html">the AWS Docs</a>
*/
export interface ServiceNowConnectorProfileCredentialsProps {
    /** <code>Username</code>  <a name="cfn-appflow-connectorprofile-servicenowconnectorprofilecredentials-username"></a>
  The name of the user.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    username: Value<string>;
    /** <code>Password</code>  <a name="cfn-appflow-connectorprofile-servicenowconnectorprofilecredentials-password"></a>
  The password that corresponds to the user name.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>.*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    password: Value<string>;
}
