import { Value } from '../../../kloudformation/Value';
/**
  The <code>ServiceNowConnectorProfileProperties</code> property type specifies the connector-specific profile properties required when using ServiceNow.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-connectorprofile-servicenowconnectorprofileproperties.html">the AWS Docs</a>
*/
export interface ServiceNowConnectorProfilePropertiesProps {
    /** <code>InstanceUrl</code>  <a name="cfn-appflow-connectorprofile-servicenowconnectorprofileproperties-instanceurl"></a>
  The location of the ServiceNow resource.<br />
  
  Required: Yes<br />
  
  Maximum: <code>256</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    instanceUrl: Value<string>;
}
