import { Value } from '../../../kloudformation/Value';
import { ConnectorOAuthRequestProps } from './ConnectorOAuthRequestProps';
/**
  The <code>SlackConnectorProfileCredentials</code> property type specifies the connector-specific profile credentials required when using Slack.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-connectorprofile-slackconnectorprofilecredentials.html">the AWS Docs</a>
*/
export interface SlackConnectorProfileCredentialsProps {
    /** <code>ClientId</code>  <a name="cfn-appflow-connectorprofile-slackconnectorprofilecredentials-clientid"></a>
  The identifier for the client.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    clientId: Value<string>;
    /** <code>ClientSecret</code>  <a name="cfn-appflow-connectorprofile-slackconnectorprofilecredentials-clientsecret"></a>
  The client secret used by the OAuth client to authenticate to the authorization server.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    clientSecret: Value<string>;
    /** <code>AccessToken</code>  <a name="cfn-appflow-connectorprofile-slackconnectorprofilecredentials-accesstoken"></a>
  The credentials used to access protected Slack resources.<br />
  
  Required: No<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    accessToken?: Value<string>;
    /** <code>ConnectorOAuthRequest</code>  <a name="cfn-appflow-connectorprofile-slackconnectorprofilecredentials-connectoroauthrequest"></a>
  Used by select connectors for which the OAuth workflow is supported, such as Salesforce, Google Analytics, Marketo, Zendesk, and Slack.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    connectorOAuthRequest?: ConnectorOAuthRequestProps;
}
