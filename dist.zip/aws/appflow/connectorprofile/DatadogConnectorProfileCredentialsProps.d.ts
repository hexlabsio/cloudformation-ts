import { Value } from '../../../kloudformation/Value';
/**
  The <code>DatadogConnectorProfileCredentials</code> property type specifies the connector-specific credentials required by Datadog.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-connectorprofile-datadogconnectorprofilecredentials.html">the AWS Docs</a>
*/
export interface DatadogConnectorProfileCredentialsProps {
    /** <code>ApiKey</code>  <a name="cfn-appflow-connectorprofile-datadogconnectorprofilecredentials-apikey"></a>
  A unique alphanumeric identifier used to authenticate a user, developer, or calling program to your API.<br />
  
  Required: Yes<br />
  
  Maximum: <code>256</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    apiKey: Value<string>;
    /** <code>ApplicationKey</code>  <a name="cfn-appflow-connectorprofile-datadogconnectorprofilecredentials-applicationkey"></a>
  Application keys, in conjunction with your API key, give you full access to Datadog’s programmatic API. Application keys are associated with the user account that created them. The application key is used to log all requests made to the API.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    applicationKey: Value<string>;
}
