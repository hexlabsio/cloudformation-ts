import { Value } from '../../../kloudformation/Value';
/**
  The <code>RedshiftConnectorProfileProperties</code> property type specifies the connector-specific profile properties when using Amazon Redshift.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-connectorprofile-redshiftconnectorprofileproperties.html">the AWS Docs</a>
*/
export interface RedshiftConnectorProfilePropertiesProps {
    /** <code>DatabaseUrl</code>  <a name="cfn-appflow-connectorprofile-redshiftconnectorprofileproperties-databaseurl"></a>
  The JDBC URL of the Amazon Redshift cluster.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    databaseUrl: Value<string>;
    /** <code>BucketName</code>  <a name="cfn-appflow-connectorprofile-redshiftconnectorprofileproperties-bucketname"></a>
  A name for the associated Amazon S3 bucket.<br />
  
  Required: Yes<br />
  
  Minimum: <code>3</code><br />
  
  Maximum: <code>63</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    bucketName: Value<string>;
    /** <code>BucketPrefix</code>  <a name="cfn-appflow-connectorprofile-redshiftconnectorprofileproperties-bucketprefix"></a>
  The object key for the destination bucket in which Amazon AppFlow places the files.<br />
  
  Required: No<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>.*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    bucketPrefix?: Value<string>;
    /** <code>RoleArn</code>  <a name="cfn-appflow-connectorprofile-redshiftconnectorprofileproperties-rolearn"></a>
  The Amazon Resource Name (ARN) of the IAM role.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>arn:aws:iam:.*:[0-9]+:.*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    roleArn: Value<string>;
}
