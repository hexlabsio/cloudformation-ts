import { Value } from '../../../kloudformation/Value';
/**
  The <code>SnowflakeConnectorProfileProperties</code> property type specifies the connector-specific profile properties required when using Snowflake.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-connectorprofile-snowflakeconnectorprofileproperties.html">the AWS Docs</a>
*/
export interface SnowflakeConnectorProfilePropertiesProps {
    /** <code>Warehouse</code>  <a name="cfn-appflow-connectorprofile-snowflakeconnectorprofileproperties-warehouse"></a>
  The name of the Snowflake warehouse.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>[\s\w/!@#+=.-]*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    warehouse: Value<string>;
    /** <code>Stage</code>  <a name="cfn-appflow-connectorprofile-snowflakeconnectorprofileproperties-stage"></a>
  The name of the Amazon S3 stage that was created while setting up an Amazon S3 stage in the Snowflake account. This is written in the following format: &lt; Database&gt;&lt; Schema&gt;<Stage Name>.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    stage: Value<string>;
    /** <code>BucketName</code>  <a name="cfn-appflow-connectorprofile-snowflakeconnectorprofileproperties-bucketname"></a>
  The name of the Amazon S3 bucket associated with Snowflake.<br />
  
  Required: Yes<br />
  
  Minimum: <code>3</code><br />
  
  Maximum: <code>63</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    bucketName: Value<string>;
    /** <code>BucketPrefix</code>  <a name="cfn-appflow-connectorprofile-snowflakeconnectorprofileproperties-bucketprefix"></a>
  The bucket path that refers to the Amazon S3 bucket associated with Snowflake.<br />
  
  Required: No<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>.*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    bucketPrefix?: Value<string>;
    /** <code>PrivateLinkServiceName</code>  <a name="cfn-appflow-connectorprofile-snowflakeconnectorprofileproperties-privatelinkservicename"></a>
  The Snowflake Private Link service name to be used for private data transfers.<br />
  
  Required: No<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    privateLinkServiceName?: Value<string>;
    /** <code>AccountName</code>  <a name="cfn-appflow-connectorprofile-snowflakeconnectorprofileproperties-accountname"></a>
  The name of the account.<br />
  
  Required: No<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    accountName?: Value<string>;
    /** <code>Region</code>  <a name="cfn-appflow-connectorprofile-snowflakeconnectorprofileproperties-region"></a>
  The AWS Region of the Snowflake account.<br />
  
  Required: No<br />
  
  Maximum: <code>64</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    region?: Value<string>;
}
