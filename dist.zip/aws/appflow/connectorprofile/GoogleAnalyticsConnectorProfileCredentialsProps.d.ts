import { Value } from '../../../kloudformation/Value';
import { ConnectorOAuthRequestProps } from './ConnectorOAuthRequestProps';
/**
  The <code>GoogleAnalyticsConnectorProfileCredentials</code> property type specifies the connector-specific profile credentials required by Google Analytics.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-connectorprofile-googleanalyticsconnectorprofilecredentials.html">the AWS Docs</a>
*/
export interface GoogleAnalyticsConnectorProfileCredentialsProps {
    /** <code>ClientId</code>  <a name="cfn-appflow-connectorprofile-googleanalyticsconnectorprofilecredentials-clientid"></a>
  The identifier for the desired client.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    clientId: Value<string>;
    /** <code>ClientSecret</code>  <a name="cfn-appflow-connectorprofile-googleanalyticsconnectorprofilecredentials-clientsecret"></a>
  The client secret used by the OAuth client to authenticate to the authorization server.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    clientSecret: Value<string>;
    /** <code>AccessToken</code>  <a name="cfn-appflow-connectorprofile-googleanalyticsconnectorprofilecredentials-accesstoken"></a>
  The credentials used to access protected Google Analytics resources.<br />
  
  Required: No<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    accessToken?: Value<string>;
    /** <code>RefreshToken</code>  <a name="cfn-appflow-connectorprofile-googleanalyticsconnectorprofilecredentials-refreshtoken"></a>
  The credentials used to acquire new access tokens. This is required only for OAuth2 access tokens, and is not required for OAuth1 access tokens.<br />
  
  Required: No<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    refreshToken?: Value<string>;
    /** <code>ConnectorOAuthRequest</code>  <a name="cfn-appflow-connectorprofile-googleanalyticsconnectorprofilecredentials-connectoroauthrequest"></a>
  Used by select connectors for which the OAuth workflow is supported, such as Salesforce, Google Analytics, Marketo, Zendesk, and Slack.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    connectorOAuthRequest?: ConnectorOAuthRequestProps;
}
