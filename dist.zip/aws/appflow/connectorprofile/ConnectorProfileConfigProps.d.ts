import { ConnectorProfilePropertiesProps } from './ConnectorProfilePropertiesProps';
import { ConnectorProfileCredentialsProps } from './ConnectorProfileCredentialsProps';
/**
  Defines the connector-specific configuration and credentials for the connector profile.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-connectorprofile-connectorprofileconfig.html">the AWS Docs</a>
*/
export interface ConnectorProfileConfigProps {
    /** <code>ConnectorProfileProperties</code>  <a name="cfn-appflow-connectorprofile-connectorprofileconfig-connectorprofileproperties"></a>
  The connector-specific properties of the profile configuration.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    connectorProfileProperties?: ConnectorProfilePropertiesProps;
    /** <code>ConnectorProfileCredentials</code>  <a name="cfn-appflow-connectorprofile-connectorprofileconfig-connectorprofilecredentials"></a>
  The connector-specific credentials required by each connector.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    connectorProfileCredentials: ConnectorProfileCredentialsProps;
}
