import { Value } from '../../../kloudformation/Value';
/**
  The <code>ConnectorOAuthRequest</code> property type specifies the select connectors for which the OAuth workflow is supported, such as Salesforce, Google Analytics, Marketo, Zendesk, and Slack.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-connectorprofile-connectoroauthrequest.html">the AWS Docs</a>
*/
export interface ConnectorOAuthRequestProps {
    /** <code>AuthCode</code>  <a name="cfn-appflow-connectorprofile-connectoroauthrequest-authcode"></a>
  The code provided by the connector when it has been authenticated via the connected app.<br />
  
  Required: No<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    authCode?: Value<string>;
    /** <code>RedirectUri</code>  <a name="cfn-appflow-connectorprofile-connectoroauthrequest-redirecturi"></a>
  The URL to which the authentication server redirects the browser after authorization has been granted.<br />
  
  Required: No<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    redirectUri?: Value<string>;
}
