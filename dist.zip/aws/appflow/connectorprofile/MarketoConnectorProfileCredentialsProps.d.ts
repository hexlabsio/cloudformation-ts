import { Value } from '../../../kloudformation/Value';
import { ConnectorOAuthRequestProps } from './ConnectorOAuthRequestProps';
/**
  The <code>MarketoConnectorProfileCredentials</code> property type specifies the connector-specific profile credentials required by Marketo.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-connectorprofile-marketoconnectorprofilecredentials.html">the AWS Docs</a>
*/
export interface MarketoConnectorProfileCredentialsProps {
    /** <code>ClientId</code>  <a name="cfn-appflow-connectorprofile-marketoconnectorprofilecredentials-clientid"></a>
  The identifier for the desired client.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    clientId: Value<string>;
    /** <code>ClientSecret</code>  <a name="cfn-appflow-connectorprofile-marketoconnectorprofilecredentials-clientsecret"></a>
  The client secret used by the OAuth client to authenticate to the authorization server.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    clientSecret: Value<string>;
    /** <code>AccessToken</code>  <a name="cfn-appflow-connectorprofile-marketoconnectorprofilecredentials-accesstoken"></a>
  The credentials used to access protected Marketo resources.<br />
  
  Required: No<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    accessToken?: Value<string>;
    /** <code>ConnectorOAuthRequest</code>  <a name="cfn-appflow-connectorprofile-marketoconnectorprofilecredentials-connectoroauthrequest"></a>
  Used by select connectors for which the OAuth workflow is supported, such as Salesforce, Google Analytics, Marketo, Zendesk, and Slack.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    connectorOAuthRequest?: ConnectorOAuthRequestProps;
}
