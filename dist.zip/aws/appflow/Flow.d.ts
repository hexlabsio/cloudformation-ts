import { Value } from '../../kloudformation/Value';
import { TriggerConfigProps } from './flow/TriggerConfigProps';
import { SourceFlowConfigProps } from './flow/SourceFlowConfigProps';
import { DestinationFlowConfigProps } from './flow/DestinationFlowConfigProps';
import { TaskProps } from './flow/TaskProps';
import { Tag } from '../Tag';
import { Attribute } from '../../kloudformation/Attribute';
import { KloudResource } from '../../kloudformation/KloudResource';
export declare type FlowAttributes = {
    FlowArn: Attribute<string>;
};
export declare type Flow = FlowProperties & {
    attributes: FlowAttributes;
};
/**
  The <code>AWS::AppFlow::Flow</code> resource is an Amazon AppFlow resource type that specifies a new flow.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appflow-flow.html">the AWS Docs</a>
*/
export declare function flow(flowProps: FlowProperties): Flow;
/**
  The <code>AWS::AppFlow::Flow</code> resource is an Amazon AppFlow resource type that specifies a new flow.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appflow-flow.html">the AWS Docs</a>
*/
export interface FlowProperties extends KloudResource {
    /** <code>FlowName</code>  <a name="cfn-appflow-flow-flowname"></a>
  The specified name of the flow. Spaces are not allowed. Use underscores (_) or hyphens (-) only.<br />
  
  Required: Yes<br />
  
  Maximum: <code>256</code><br />
  
  Pattern: <code>[a-zA-Z0-9][\w!@#.-]+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    flowName: Value<string>;
    /** <code>Description</code>  <a name="cfn-appflow-flow-description"></a>
  A user-entered description of the flow.<br />
  
  Required: No<br />
  
  Maximum: <code>2048</code><br />
  
  Pattern: <code>[\w!@#\-.?,\s]*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>KMSArn</code>  <a name="cfn-appflow-flow-kmsarn"></a>
  The ARN (Amazon Resource Name) of the Key Management Service (KMS) key you provide for encryption. This is required if you do not want to use the Amazon AppFlow-managed KMS key. If you don’t provide anything here, Amazon AppFlow uses the Amazon AppFlow-managed KMS key.<br />
  
  Required: No<br />
  
  Minimum: <code>20</code><br />
  
  Maximum: <code>2048</code><br />
  
  Pattern: <code>arn:aws:kms:.*:[0-9]+:.*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    kMSArn?: Value<string>;
    /** <code>TriggerConfig</code>  <a name="cfn-appflow-flow-triggerconfig"></a>
  The trigger settings that determine how and when Amazon AppFlow runs the specified flow.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    triggerConfig: TriggerConfigProps;
    /** <code>SourceFlowConfig</code>  <a name="cfn-appflow-flow-sourceflowconfig"></a>
  Contains information about the configuration of the source connector used in the flow.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    sourceFlowConfig: SourceFlowConfigProps;
    /** <code>DestinationFlowConfigList</code>  <a name="cfn-appflow-flow-destinationflowconfiglist"></a>
  The configuration that controls how Amazon AppFlow places data in the destination connector.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    destinationFlowConfigList: DestinationFlowConfigProps[];
    /** <code>Tasks</code>  <a name="cfn-appflow-flow-tasks"></a>
  A list of tasks that Amazon AppFlow performs while transferring the data in the flow run.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tasks: TaskProps[];
    /** <code>Tags</code>  <a name="cfn-appflow-flow-tags"></a>
  The tags used to organize, track, or control access for your flow.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: Tag[];
}
