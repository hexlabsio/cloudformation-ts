"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  The <code>AWS::AppFlow::Flow</code> resource is an Amazon AppFlow resource type that specifies a new flow.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appflow-flow.html">the AWS Docs</a>
*/
function flow(flowProps) { return ({ ...flowProps, _logicalType: 'AWS::AppFlow::Flow', attributes: { FlowArn: 'FlowArn' } }); }
exports.flow = flow;
