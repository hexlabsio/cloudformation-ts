import { Value } from '../../../kloudformation/Value';
/**
  A map used to store task-related information. The execution service looks for particular information based on the <code>TaskType</code>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-taskpropertiesobject.html">the AWS Docs</a>
*/
export interface TaskPropertiesObjectProps {
    /** <code>Key</code>  <a name="cfn-appflow-flow-taskpropertiesobject-key"></a>
  The task property key.<br />
  
  Allowed Values: <code>VALUE | VALUES | DATA_TYPE | UPPER_BOUND | LOWER_BOUND | SOURCE_DATA_TYPE | DESTINATION_DATA_TYPE | VALIDATION_ACTION | MASK_VALUE | MASK_LENGTH | TRUNCATE_LENGTH | MATH_OPERATION_FIELDS_ORDER | CONCAT_FORMAT | SUBFIELD_CATEGORY_MAP</code><br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    key: Value<string>;
    /** <code>Value</code>  <a name="cfn-appflow-flow-taskpropertiesobject-value"></a>
  The task property value.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    value: Value<string>;
}
