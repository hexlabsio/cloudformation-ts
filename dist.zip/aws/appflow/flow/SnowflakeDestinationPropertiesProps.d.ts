import { Value } from '../../../kloudformation/Value';
import { ErrorHandlingConfigProps } from './ErrorHandlingConfigProps';
/**
  The properties that are applied when Snowflake is being used as a destination.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-snowflakedestinationproperties.html">the AWS Docs</a>
*/
export interface SnowflakeDestinationPropertiesProps {
    /** <code>Object</code>  <a name="cfn-appflow-flow-snowflakedestinationproperties-object"></a>
  The object specified in the Snowflake flow destination.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    object: Value<string>;
    /** <code>IntermediateBucketName</code>  <a name="cfn-appflow-flow-snowflakedestinationproperties-intermediatebucketname"></a>
  The intermediate bucket that Amazon AppFlow uses when moving data into Snowflake.<br />
  
  Required: Yes<br />
  
  Minimum: <code>3</code><br />
  
  Maximum: <code>63</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    intermediateBucketName: Value<string>;
    /** <code>BucketPrefix</code>  <a name="cfn-appflow-flow-snowflakedestinationproperties-bucketprefix"></a>
  The object key for the destination bucket in which Amazon AppFlow places the files.<br />
  
  Required: No<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>.*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    bucketPrefix?: Value<string>;
    /** <code>ErrorHandlingConfig</code>  <a name="cfn-appflow-flow-snowflakedestinationproperties-errorhandlingconfig"></a>
  The settings that determine how Amazon AppFlow handles an error when placing data in the Snowflake destination. For example, this setting would determine if the flow should fail after one insertion error, or continue and attempt to insert every record regardless of the initial failure. <code>ErrorHandlingConfig</code> is a part of the destination connector details.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    errorHandlingConfig?: ErrorHandlingConfigProps;
}
