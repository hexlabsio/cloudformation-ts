import { Value } from '../../../kloudformation/Value';
/**
  Specifies the configuration details of a schedule-triggered flow as defined by the user. Currently, these settings only apply to the <code>Scheduled</code> trigger type.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-scheduledtriggerproperties.html">the AWS Docs</a>
*/
export interface ScheduledTriggerPropertiesProps {
    /** <code>ScheduleExpression</code>  <a name="cfn-appflow-flow-scheduledtriggerproperties-scheduleexpression"></a>
  The scheduling expression that determines the rate at which the scheduled flow will run, for example: <code>rate(5minutes)</code>.<br />
  
  Required: Yes<br />
  
  Maximum: <code>256</code><br />
  
  Pattern: <code>.*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    scheduleExpression: Value<string>;
    /** <code>DataPullMode</code>  <a name="cfn-appflow-flow-scheduledtriggerproperties-datapullmode"></a>
  Specifies whether a scheduled flow has an incremental data transfer or a complete data transfer for each flow run.<br />
  
  Required: No<br />
  
  Allowed values: <code>Complete | Incremental</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    dataPullMode?: Value<'Complete' | 'Incremental'>;
    /** <code>ScheduleStartTime</code>  <a name="cfn-appflow-flow-scheduledtriggerproperties-schedulestarttime"></a>
  Specifies the scheduled start time for a schedule-triggered flow.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    scheduleStartTime?: Value<number>;
    /** <code>ScheduleEndTime</code>  <a name="cfn-appflow-flow-scheduledtriggerproperties-scheduleendtime"></a>
  Specifies the scheduled end time for a schedule-triggered flow.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    scheduleEndTime?: Value<number>;
    /** <code>TimeZone</code>  <a name="cfn-appflow-flow-scheduledtriggerproperties-timezone"></a>
  Specifies the time zone used when referring to the date and time of a scheduled-triggered flow, such as <code>America/New_York</code>.<br />
  
  Required: No<br />
  
  Maximum: <code>256</code><br />
  
  Pattern: <code>.*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    timeZone?: Value<string>;
}
