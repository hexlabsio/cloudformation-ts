import { Value } from '../../../kloudformation/Value';
/**
  The properties that are applied when Amplitude is being used as a source.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-amplitudesourceproperties.html">the AWS Docs</a>
*/
export interface AmplitudeSourcePropertiesProps {
    /** <code>Object</code>  <a name="cfn-appflow-flow-amplitudesourceproperties-object"></a>
  The object specified in the Amplitude flow source.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    object: Value<string>;
}
