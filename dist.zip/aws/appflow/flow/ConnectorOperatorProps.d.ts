import { Value } from '../../../kloudformation/Value';
/**
  The operation to be performed on the provided source fields.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-connectoroperator.html">the AWS Docs</a>
*/
export interface ConnectorOperatorProps {
    /** <code>Amplitude</code>  <a name="cfn-appflow-flow-connectoroperator-amplitude"></a>
  The operation to be performed on the provided Amplitude source fields.<br />
  
  Required: No<br />
  
  Allowed values: <code>BETWEEN</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    amplitude?: Value<'BETWEEN'>;
    /** <code>Datadog</code>  <a name="cfn-appflow-flow-connectoroperator-datadog"></a>
  The operation to be performed on the provided Datadog source fields.<br />
  
  Required: No<br />
  
  Allowed values: <code>ADDITION | BETWEEN | DIVISION | EQUAL_TO | MASK_ALL | MASK_FIRST_N | MASK_LAST_N | MULTIPLICATION | NO_OP | PROJECTION | SUBTRACTION | VALIDATE_NON_NEGATIVE | VALIDATE_NON_NULL | VALIDATE_NON_ZERO | VALIDATE_NUMERIC</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    datadog?: Value<'ADDITION' | 'BETWEEN' | 'DIVISION' | 'EQUAL_TO' | 'MASK_ALL' | 'MASK_FIRST_N' | 'MASK_LAST_N' | 'MULTIPLICATION' | 'NO_OP' | 'PROJECTION' | 'SUBTRACTION' | 'VALIDATE_NON_NEGATIVE' | 'VALIDATE_NON_NULL' | 'VALIDATE_NON_ZERO' | 'VALIDATE_NUMERIC'>;
    /** <code>Dynatrace</code>  <a name="cfn-appflow-flow-connectoroperator-dynatrace"></a>
  The operation to be performed on the provided Dynatrace source fields.<br />
  
  Required: No<br />
  
  Allowed values: <code>ADDITION | BETWEEN | DIVISION | EQUAL_TO | MASK_ALL | MASK_FIRST_N | MASK_LAST_N | MULTIPLICATION | NO_OP | PROJECTION | SUBTRACTION | VALIDATE_NON_NEGATIVE | VALIDATE_NON_NULL | VALIDATE_NON_ZERO | VALIDATE_NUMERIC</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    dynatrace?: Value<'ADDITION' | 'BETWEEN' | 'DIVISION' | 'EQUAL_TO' | 'MASK_ALL' | 'MASK_FIRST_N' | 'MASK_LAST_N' | 'MULTIPLICATION' | 'NO_OP' | 'PROJECTION' | 'SUBTRACTION' | 'VALIDATE_NON_NEGATIVE' | 'VALIDATE_NON_NULL' | 'VALIDATE_NON_ZERO' | 'VALIDATE_NUMERIC'>;
    /** <code>GoogleAnalytics</code>  <a name="cfn-appflow-flow-connectoroperator-googleanalytics"></a>
  The operation to be performed on the provided Google Analytics source fields.<br />
  
  Required: No<br />
  
  Allowed values: <code>BETWEEN | PROJECTION</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    googleAnalytics?: Value<'BETWEEN' | 'PROJECTION'>;
    /** <code>InforNexus</code>  <a name="cfn-appflow-flow-connectoroperator-infornexus"></a>
  The operation to be performed on the provided Infor Nexus source fields.<br />
  
  Required: No<br />
  
  Allowed values: <code>ADDITION | BETWEEN | DIVISION | EQUAL_TO | MASK_ALL | MASK_FIRST_N | MASK_LAST_N | MULTIPLICATION | NO_OP | PROJECTION | SUBTRACTION | VALIDATE_NON_NEGATIVE | VALIDATE_NON_NULL | VALIDATE_NON_ZERO | VALIDATE_NUMERIC</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    inforNexus?: Value<'ADDITION' | 'BETWEEN' | 'DIVISION' | 'EQUAL_TO' | 'MASK_ALL' | 'MASK_FIRST_N' | 'MASK_LAST_N' | 'MULTIPLICATION' | 'NO_OP' | 'PROJECTION' | 'SUBTRACTION' | 'VALIDATE_NON_NEGATIVE' | 'VALIDATE_NON_NULL' | 'VALIDATE_NON_ZERO' | 'VALIDATE_NUMERIC'>;
    /** <code>Marketo</code>  <a name="cfn-appflow-flow-connectoroperator-marketo"></a>
  The operation to be performed on the provided Marketo source fields.<br />
  
  Required: No<br />
  
  Allowed values: <code>ADDITION | BETWEEN | DIVISION | GREATER_THAN | LESS_THAN | MASK_ALL | MASK_FIRST_N | MASK_LAST_N | MULTIPLICATION | NO_OP | PROJECTION | SUBTRACTION | VALIDATE_NON_NEGATIVE | VALIDATE_NON_NULL | VALIDATE_NON_ZERO | VALIDATE_NUMERIC</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    marketo?: Value<'ADDITION' | 'BETWEEN' | 'DIVISION' | 'GREATER_THAN' | 'LESS_THAN' | 'MASK_ALL' | 'MASK_FIRST_N' | 'MASK_LAST_N' | 'MULTIPLICATION' | 'NO_OP' | 'PROJECTION' | 'SUBTRACTION' | 'VALIDATE_NON_NEGATIVE' | 'VALIDATE_NON_NULL' | 'VALIDATE_NON_ZERO' | 'VALIDATE_NUMERIC'>;
    /** <code>S3</code>  <a name="cfn-appflow-flow-connectoroperator-s3"></a>
  The operation to be performed on the provided Amazon S3 source fields.<br />
  
  Required: No<br />
  
  Allowed values: <code>ADDITION | BETWEEN | DIVISION | EQUAL_TO | GREATER_THAN | GREATER_THAN_OR_EQUAL_TO | LESS_THAN | LESS_THAN_OR_EQUAL_TO | MASK_ALL | MASK_FIRST_N | MASK_LAST_N | MULTIPLICATION | NO_OP | NOT_EQUAL_TO | PROJECTION | SUBTRACTION | VALIDATE_NON_NEGATIVE | VALIDATE_NON_NULL | VALIDATE_NON_ZERO | VALIDATE_NUMERIC</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    s3?: Value<'ADDITION' | 'BETWEEN' | 'DIVISION' | 'EQUAL_TO' | 'GREATER_THAN' | 'GREATER_THAN_OR_EQUAL_TO' | 'LESS_THAN' | 'LESS_THAN_OR_EQUAL_TO' | 'MASK_ALL' | 'MASK_FIRST_N' | 'MASK_LAST_N' | 'MULTIPLICATION' | 'NO_OP' | 'NOT_EQUAL_TO' | 'PROJECTION' | 'SUBTRACTION' | 'VALIDATE_NON_NEGATIVE' | 'VALIDATE_NON_NULL' | 'VALIDATE_NON_ZERO' | 'VALIDATE_NUMERIC'>;
    /** <code>Salesforce</code>  <a name="cfn-appflow-flow-connectoroperator-salesforce"></a>
  The operation to be performed on the provided Salesforce source fields.<br />
  
  Required: No<br />
  
  Allowed values: <code>ADDITION | BETWEEN | CONTAINS | DIVISION | EQUAL_TO | GREATER_THAN | GREATER_THAN_OR_EQUAL_TO | LESS_THAN | LESS_THAN_OR_EQUAL_TO | MASK_ALL | MASK_FIRST_N | MASK_LAST_N | MULTIPLICATION | NO_OP | NOT_EQUAL_TO | PROJECTION | SUBTRACTION | VALIDATE_NON_NEGATIVE | VALIDATE_NON_NULL | VALIDATE_NON_ZERO | VALIDATE_NUMERIC</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    salesforce?: Value<'ADDITION' | 'BETWEEN' | 'CONTAINS' | 'DIVISION' | 'EQUAL_TO' | 'GREATER_THAN' | 'GREATER_THAN_OR_EQUAL_TO' | 'LESS_THAN' | 'LESS_THAN_OR_EQUAL_TO' | 'MASK_ALL' | 'MASK_FIRST_N' | 'MASK_LAST_N' | 'MULTIPLICATION' | 'NO_OP' | 'NOT_EQUAL_TO' | 'PROJECTION' | 'SUBTRACTION' | 'VALIDATE_NON_NEGATIVE' | 'VALIDATE_NON_NULL' | 'VALIDATE_NON_ZERO' | 'VALIDATE_NUMERIC'>;
    /** <code>ServiceNow</code>  <a name="cfn-appflow-flow-connectoroperator-servicenow"></a>
  The operation to be performed on the provided ServiceNow source fields.<br />
  
  Required: No<br />
  
  Allowed values: <code>ADDITION | BETWEEN | CONTAINS | DIVISION | EQUAL_TO | GREATER_THAN | GREATER_THAN_OR_EQUAL_TO | LESS_THAN | LESS_THAN_OR_EQUAL_TO | MASK_ALL | MASK_FIRST_N | MASK_LAST_N | MULTIPLICATION | NO_OP | NOT_EQUAL_TO | PROJECTION | SUBTRACTION | VALIDATE_NON_NEGATIVE | VALIDATE_NON_NULL | VALIDATE_NON_ZERO | VALIDATE_NUMERIC</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    serviceNow?: Value<'ADDITION' | 'BETWEEN' | 'CONTAINS' | 'DIVISION' | 'EQUAL_TO' | 'GREATER_THAN' | 'GREATER_THAN_OR_EQUAL_TO' | 'LESS_THAN' | 'LESS_THAN_OR_EQUAL_TO' | 'MASK_ALL' | 'MASK_FIRST_N' | 'MASK_LAST_N' | 'MULTIPLICATION' | 'NO_OP' | 'NOT_EQUAL_TO' | 'PROJECTION' | 'SUBTRACTION' | 'VALIDATE_NON_NEGATIVE' | 'VALIDATE_NON_NULL' | 'VALIDATE_NON_ZERO' | 'VALIDATE_NUMERIC'>;
    /** <code>Singular</code>  <a name="cfn-appflow-flow-connectoroperator-singular"></a>
  The operation to be performed on the provided Singular source fields.<br />
  
  Required: No<br />
  
  Allowed values: <code>ADDITION | DIVISION | EQUAL_TO | MASK_ALL | MASK_FIRST_N | MASK_LAST_N | MULTIPLICATION | NO_OP | PROJECTION | SUBTRACTION | VALIDATE_NON_NEGATIVE | VALIDATE_NON_NULL | VALIDATE_NON_ZERO | VALIDATE_NUMERIC</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    singular?: Value<'ADDITION' | 'DIVISION' | 'EQUAL_TO' | 'MASK_ALL' | 'MASK_FIRST_N' | 'MASK_LAST_N' | 'MULTIPLICATION' | 'NO_OP' | 'PROJECTION' | 'SUBTRACTION' | 'VALIDATE_NON_NEGATIVE' | 'VALIDATE_NON_NULL' | 'VALIDATE_NON_ZERO' | 'VALIDATE_NUMERIC'>;
    /** <code>Slack</code>  <a name="cfn-appflow-flow-connectoroperator-slack"></a>
  The operation to be performed on the provided Slack source fields.<br />
  
  Required: No<br />
  
  Allowed values: <code>ADDITION | BETWEEN | DIVISION | EQUAL_TO | GREATER_THAN | GREATER_THAN_OR_EQUAL_TO | LESS_THAN | LESS_THAN_OR_EQUAL_TO | MASK_ALL | MASK_FIRST_N | MASK_LAST_N | MULTIPLICATION | NO_OP | PROJECTION | SUBTRACTION | VALIDATE_NON_NEGATIVE | VALIDATE_NON_NULL | VALIDATE_NON_ZERO | VALIDATE_NUMERIC</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    slack?: Value<'ADDITION' | 'BETWEEN' | 'DIVISION' | 'EQUAL_TO' | 'GREATER_THAN' | 'GREATER_THAN_OR_EQUAL_TO' | 'LESS_THAN' | 'LESS_THAN_OR_EQUAL_TO' | 'MASK_ALL' | 'MASK_FIRST_N' | 'MASK_LAST_N' | 'MULTIPLICATION' | 'NO_OP' | 'PROJECTION' | 'SUBTRACTION' | 'VALIDATE_NON_NEGATIVE' | 'VALIDATE_NON_NULL' | 'VALIDATE_NON_ZERO' | 'VALIDATE_NUMERIC'>;
    /** <code>Trendmicro</code>  <a name="cfn-appflow-flow-connectoroperator-trendmicro"></a>
  The operation to be performed on the provided Trend Micro source fields.<br />
  
  Required: No<br />
  
  Allowed values: <code>ADDITION | DIVISION | EQUAL_TO | MASK_ALL | MASK_FIRST_N | MASK_LAST_N | MULTIPLICATION | NO_OP | PROJECTION | SUBTRACTION | VALIDATE_NON_NEGATIVE | VALIDATE_NON_NULL | VALIDATE_NON_ZERO | VALIDATE_NUMERIC</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    trendmicro?: Value<'ADDITION' | 'DIVISION' | 'EQUAL_TO' | 'MASK_ALL' | 'MASK_FIRST_N' | 'MASK_LAST_N' | 'MULTIPLICATION' | 'NO_OP' | 'PROJECTION' | 'SUBTRACTION' | 'VALIDATE_NON_NEGATIVE' | 'VALIDATE_NON_NULL' | 'VALIDATE_NON_ZERO' | 'VALIDATE_NUMERIC'>;
    /** <code>Veeva</code>  <a name="cfn-appflow-flow-connectoroperator-veeva"></a>
  The operation to be performed on the provided Veeva source fields.<br />
  
  Required: No<br />
  
  Allowed values: <code>ADDITION | BETWEEN | CONTAINS | DIVISION | EQUAL_TO | GREATER_THAN | GREATER_THAN_OR_EQUAL_TO | LESS_THAN | LESS_THAN_OR_EQUAL_TO | MASK_ALL | MASK_FIRST_N | MASK_LAST_N | MULTIPLICATION | NO_OP | NOT_EQUAL_TO | PROJECTION | SUBTRACTION | VALIDATE_NON_NEGATIVE | VALIDATE_NON_NULL | VALIDATE_NON_ZERO | VALIDATE_NUMERIC</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    veeva?: Value<'ADDITION' | 'BETWEEN' | 'CONTAINS' | 'DIVISION' | 'EQUAL_TO' | 'GREATER_THAN' | 'GREATER_THAN_OR_EQUAL_TO' | 'LESS_THAN' | 'LESS_THAN_OR_EQUAL_TO' | 'MASK_ALL' | 'MASK_FIRST_N' | 'MASK_LAST_N' | 'MULTIPLICATION' | 'NO_OP' | 'NOT_EQUAL_TO' | 'PROJECTION' | 'SUBTRACTION' | 'VALIDATE_NON_NEGATIVE' | 'VALIDATE_NON_NULL' | 'VALIDATE_NON_ZERO' | 'VALIDATE_NUMERIC'>;
    /** <code>Zendesk</code>  <a name="cfn-appflow-flow-connectoroperator-zendesk"></a>
  The operation to be performed on the provided Zendesk source fields.<br />
  
  Required: No<br />
  
  Allowed values: <code>ADDITION | DIVISION | GREATER_THAN | MASK_ALL | MASK_FIRST_N | MASK_LAST_N | MULTIPLICATION | NO_OP | PROJECTION | SUBTRACTION | VALIDATE_NON_NEGATIVE | VALIDATE_NON_NULL | VALIDATE_NON_ZERO | VALIDATE_NUMERIC</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    zendesk?: Value<'ADDITION' | 'DIVISION' | 'GREATER_THAN' | 'MASK_ALL' | 'MASK_FIRST_N' | 'MASK_LAST_N' | 'MULTIPLICATION' | 'NO_OP' | 'PROJECTION' | 'SUBTRACTION' | 'VALIDATE_NON_NEGATIVE' | 'VALIDATE_NON_NULL' | 'VALIDATE_NON_ZERO' | 'VALIDATE_NUMERIC'>;
}
