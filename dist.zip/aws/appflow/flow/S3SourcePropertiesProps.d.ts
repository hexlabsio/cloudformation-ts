import { Value } from '../../../kloudformation/Value';
/**
  The properties that are applied when Amazon S3 is being used as the flow source.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-s3sourceproperties.html">the AWS Docs</a>
*/
export interface S3SourcePropertiesProps {
    /** <code>BucketName</code>  <a name="cfn-appflow-flow-s3sourceproperties-bucketname"></a>
  The Amazon S3 bucket name where the source files are stored.<br />
  
  Required: Yes<br />
  
  Minimum: <code>3</code><br />
  
  Maximum: <code>63</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    bucketName: Value<string>;
    /** <code>BucketPrefix</code>  <a name="cfn-appflow-flow-s3sourceproperties-bucketprefix"></a>
  The object key for the Amazon S3 bucket in which the source files are stored.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>.*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    bucketPrefix: Value<string>;
}
