import { Value } from '../../../kloudformation/Value';
/**
  The settings that determine how Amazon AppFlow handles an error when placing data in the destination. For example, this setting would determine if the flow should fail after one insertion error, or continue and attempt to insert every record regardless of the initial failure. <code>ErrorHandlingConfig</code> is a part of the destination connector details.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-errorhandlingconfig.html">the AWS Docs</a>
*/
export interface ErrorHandlingConfigProps {
    /** <code>FailOnFirstError</code>  <a name="cfn-appflow-flow-errorhandlingconfig-failonfirsterror"></a>
  Specifies if the flow should fail after the first instance of a failure when attempting to place data in the destination.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    failOnFirstError?: Value<boolean>;
    /** <code>BucketPrefix</code>  <a name="cfn-appflow-flow-errorhandlingconfig-bucketprefix"></a>
  Specifies the Amazon S3 bucket prefix.<br />
  
  Required: No<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>.*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    bucketPrefix?: Value<string>;
    /** <code>BucketName</code>  <a name="cfn-appflow-flow-errorhandlingconfig-bucketname"></a>
  Specifies the name of the Amazon S3 bucket.<br />
  
  Required: No<br />
  
  Minimum: <code>3</code><br />
  
  Maximum: <code>63</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    bucketName?: Value<string>;
}
