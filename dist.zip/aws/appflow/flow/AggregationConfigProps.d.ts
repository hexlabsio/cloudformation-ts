import { Value } from '../../../kloudformation/Value';
/**
  The aggregation settings that you can use to customize the output format of your flow data.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-aggregationconfig.html">the AWS Docs</a>
*/
export interface AggregationConfigProps {
    /** <code>AggregationType</code>  <a name="cfn-appflow-flow-aggregationconfig-aggregationtype"></a>
  Specifies whether Amazon AppFlow aggregates the flow records into a single file, or leave them unaggregated.<br />
  
  Required: No<br />
  
  Allowed values: <code>None | SingleFile</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    aggregationType?: Value<'None' | 'SingleFile'>;
}
