import { AmplitudeSourcePropertiesProps } from './AmplitudeSourcePropertiesProps';
import { DatadogSourcePropertiesProps } from './DatadogSourcePropertiesProps';
import { DynatraceSourcePropertiesProps } from './DynatraceSourcePropertiesProps';
import { GoogleAnalyticsSourcePropertiesProps } from './GoogleAnalyticsSourcePropertiesProps';
import { InforNexusSourcePropertiesProps } from './InforNexusSourcePropertiesProps';
import { MarketoSourcePropertiesProps } from './MarketoSourcePropertiesProps';
import { S3SourcePropertiesProps } from './S3SourcePropertiesProps';
import { SalesforceSourcePropertiesProps } from './SalesforceSourcePropertiesProps';
import { ServiceNowSourcePropertiesProps } from './ServiceNowSourcePropertiesProps';
import { SingularSourcePropertiesProps } from './SingularSourcePropertiesProps';
import { SlackSourcePropertiesProps } from './SlackSourcePropertiesProps';
import { TrendmicroSourcePropertiesProps } from './TrendmicroSourcePropertiesProps';
import { VeevaSourcePropertiesProps } from './VeevaSourcePropertiesProps';
import { ZendeskSourcePropertiesProps } from './ZendeskSourcePropertiesProps';
/**
  Specifies the information that is required to query a particular connector.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-sourceconnectorproperties.html">the AWS Docs</a>
*/
export interface SourceConnectorPropertiesProps {
    /** <code>Amplitude</code>  <a name="cfn-appflow-flow-sourceconnectorproperties-amplitude"></a>
  Specifies the information that is required for querying Amplitude.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    amplitude?: AmplitudeSourcePropertiesProps;
    /** <code>Datadog</code>  <a name="cfn-appflow-flow-sourceconnectorproperties-datadog"></a>
  Specifies the information that is required for querying Datadog.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    datadog?: DatadogSourcePropertiesProps;
    /** <code>Dynatrace</code>  <a name="cfn-appflow-flow-sourceconnectorproperties-dynatrace"></a>
  Specifies the information that is required for querying Dynatrace.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    dynatrace?: DynatraceSourcePropertiesProps;
    /** <code>GoogleAnalytics</code>  <a name="cfn-appflow-flow-sourceconnectorproperties-googleanalytics"></a>
  Specifies the information that is required for querying Google Analytics.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    googleAnalytics?: GoogleAnalyticsSourcePropertiesProps;
    /** <code>InforNexus</code>  <a name="cfn-appflow-flow-sourceconnectorproperties-infornexus"></a>
  Specifies the information that is required for querying Infor Nexus.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    inforNexus?: InforNexusSourcePropertiesProps;
    /** <code>Marketo</code>  <a name="cfn-appflow-flow-sourceconnectorproperties-marketo"></a>
  Specifies the information that is required for querying Marketo.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    marketo?: MarketoSourcePropertiesProps;
    /** <code>S3</code>  <a name="cfn-appflow-flow-sourceconnectorproperties-s3"></a>
  Specifies the information that is required for querying Amazon S3.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    s3?: S3SourcePropertiesProps;
    /** <code>Salesforce</code>  <a name="cfn-appflow-flow-sourceconnectorproperties-salesforce"></a>
  Specifies the information that is required for querying Salesforce.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    salesforce?: SalesforceSourcePropertiesProps;
    /** <code>ServiceNow</code>  <a name="cfn-appflow-flow-sourceconnectorproperties-servicenow"></a>
  Specifies the information that is required for querying ServiceNow.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    serviceNow?: ServiceNowSourcePropertiesProps;
    /** <code>Singular</code>  <a name="cfn-appflow-flow-sourceconnectorproperties-singular"></a>
  Specifies the information that is required for querying Singular.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    singular?: SingularSourcePropertiesProps;
    /** <code>Slack</code>  <a name="cfn-appflow-flow-sourceconnectorproperties-slack"></a>
  Specifies the information that is required for querying Slack.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    slack?: SlackSourcePropertiesProps;
    /** <code>Trendmicro</code>  <a name="cfn-appflow-flow-sourceconnectorproperties-trendmicro"></a>
  Specifies the information that is required for querying Trend Micro.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    trendmicro?: TrendmicroSourcePropertiesProps;
    /** <code>Veeva</code>  <a name="cfn-appflow-flow-sourceconnectorproperties-veeva"></a>
  Specifies the information that is required for querying Veeva.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    veeva?: VeevaSourcePropertiesProps;
    /** <code>Zendesk</code>  <a name="cfn-appflow-flow-sourceconnectorproperties-zendesk"></a>
  Specifies the information that is required for querying Zendesk.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    zendesk?: ZendeskSourcePropertiesProps;
}
