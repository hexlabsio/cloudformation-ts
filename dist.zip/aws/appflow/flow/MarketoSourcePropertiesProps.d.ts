import { Value } from '../../../kloudformation/Value';
/**
  The properties that are applied when Marketo is being used as a source.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-marketosourceproperties.html">the AWS Docs</a>
*/
export interface MarketoSourcePropertiesProps {
    /** <code>Object</code>  <a name="cfn-appflow-flow-marketosourceproperties-object"></a>
  The object specified in the Marketo flow source.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    object: Value<string>;
}
