import { Value } from '../../../kloudformation/Value';
import { S3OutputFormatConfigProps } from './S3OutputFormatConfigProps';
/**
  The properties that are applied when Amazon S3 is used as a destination.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-s3destinationproperties.html">the AWS Docs</a>
*/
export interface S3DestinationPropertiesProps {
    /** <code>BucketName</code>  <a name="cfn-appflow-flow-s3destinationproperties-bucketname"></a>
  The Amazon S3 bucket name in which Amazon AppFlow places the transferred data.<br />
  
  Required: Yes<br />
  
  Minimum: <code>3</code><br />
  
  Maximum: <code>63</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    bucketName: Value<string>;
    /** <code>BucketPrefix</code>  <a name="cfn-appflow-flow-s3destinationproperties-bucketprefix"></a>
  The object key for the destination bucket in which Amazon AppFlow places the files.<br />
  
  Required: No<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>.*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    bucketPrefix?: Value<string>;
    /** <code>S3OutputFormatConfig</code>  <a name="cfn-appflow-flow-s3destinationproperties-s3outputformatconfig"></a>
  The configuration that determines how Amazon AppFlow should format the flow output data when Amazon S3 is used as the destination.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    s3OutputFormatConfig?: S3OutputFormatConfigProps;
}
