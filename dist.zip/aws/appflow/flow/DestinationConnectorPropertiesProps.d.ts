import { RedshiftDestinationPropertiesProps } from './RedshiftDestinationPropertiesProps';
import { S3DestinationPropertiesProps } from './S3DestinationPropertiesProps';
import { SalesforceDestinationPropertiesProps } from './SalesforceDestinationPropertiesProps';
import { SnowflakeDestinationPropertiesProps } from './SnowflakeDestinationPropertiesProps';
import { EventBridgeDestinationPropertiesProps } from './EventBridgeDestinationPropertiesProps';
import { UpsolverDestinationPropertiesProps } from './UpsolverDestinationPropertiesProps';
import { LookoutMetricsDestinationPropertiesProps } from './LookoutMetricsDestinationPropertiesProps';
/**
  This stores the information that is required to query a particular connector.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-destinationconnectorproperties.html">the AWS Docs</a>
*/
export interface DestinationConnectorPropertiesProps {
    /** <code>Redshift</code>  <a name="cfn-appflow-flow-destinationconnectorproperties-redshift"></a>
  The properties required to query Amazon Redshift.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    redshift?: RedshiftDestinationPropertiesProps;
    /** <code>S3</code>  <a name="cfn-appflow-flow-destinationconnectorproperties-s3"></a>
  The properties required to query Amazon S3.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    s3?: S3DestinationPropertiesProps;
    /** <code>Salesforce</code>  <a name="cfn-appflow-flow-destinationconnectorproperties-salesforce"></a>
  The properties required to query Salesforce.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    salesforce?: SalesforceDestinationPropertiesProps;
    /** <code>Snowflake</code>  <a name="cfn-appflow-flow-destinationconnectorproperties-snowflake"></a>
  The properties required to query Snowflake.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    snowflake?: SnowflakeDestinationPropertiesProps;
    /** <code>EventBridge</code>  <a name="cfn-appflow-flow-destinationconnectorproperties-eventbridge"></a>
  The properties required to query Amazon EventBridge.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    eventBridge?: EventBridgeDestinationPropertiesProps;
    /** <code>Upsolver</code>  <a name="cfn-appflow-flow-destinationconnectorproperties-upsolver"></a>
  The properties required to query Upsolver.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    upsolver?: UpsolverDestinationPropertiesProps;
    /** <code>LookoutMetrics</code>  <a name="cfn-appflow-flow-destinationconnectorproperties-lookoutmetrics"></a>
  The properties required to query Amazon Lookout for Metrics.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    lookoutMetrics?: LookoutMetricsDestinationPropertiesProps;
}
