import { Value } from '../../../kloudformation/Value';
import { ScheduledTriggerPropertiesProps } from './ScheduledTriggerPropertiesProps';
/**
  The trigger settings that determine how and when Amazon AppFlow runs the specified flow.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-triggerconfig.html">the AWS Docs</a>
*/
export interface TriggerConfigProps {
    /** <code>TriggerType</code>  <a name="cfn-appflow-flow-triggerconfig-triggertype"></a>
  Specifies the type of flow trigger. This can be <code>OnDemand</code>, <code>Scheduled</code>, or <code>Event</code>.<br />
  
  Required: Yes<br />
  
  Allowed values: <code>Event | OnDemand | Scheduled</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    triggerType: Value<'Event' | 'OnDemand' | 'Scheduled'>;
    /** <code>TriggerProperties</code>  <a name="cfn-appflow-flow-triggerconfig-triggerproperties"></a>
  Specifies the configuration details of a schedule-triggered flow as defined by the user. Currently, these settings only apply to the <code>Scheduled</code> trigger type.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    triggerProperties?: ScheduledTriggerPropertiesProps;
}
