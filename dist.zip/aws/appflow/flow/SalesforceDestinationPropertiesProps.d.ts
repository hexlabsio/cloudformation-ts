import { Value } from '../../../kloudformation/Value';
import { ErrorHandlingConfigProps } from './ErrorHandlingConfigProps';
/**
  The properties that are applied when Salesforce is being used as a destination.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-salesforcedestinationproperties.html">the AWS Docs</a>
*/
export interface SalesforceDestinationPropertiesProps {
    /** <code>Object</code>  <a name="cfn-appflow-flow-salesforcedestinationproperties-object"></a>
  The object specified in the Salesforce flow destination.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    object: Value<string>;
    /** <code>ErrorHandlingConfig</code>  <a name="cfn-appflow-flow-salesforcedestinationproperties-errorhandlingconfig"></a>
  The settings that determine how Amazon AppFlow handles an error when placing data in the Salesforce destination. For example, this setting would determine if the flow should fail after one insertion error, or continue and attempt to insert every record regardless of the initial failure. <code>ErrorHandlingConfig</code> is a part of the destination connector details.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    errorHandlingConfig?: ErrorHandlingConfigProps;
    /** <code>IdFieldNames</code>  <a name="cfn-appflow-flow-salesforcedestinationproperties-idfieldnames"></a>
  The name of the field that Amazon AppFlow uses as an ID when performing a write operation such as update or delete.<br />
  
  Required: No<br />
  
  Maximum: <code>1</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    idFieldNames?: Value<Value<string>[]>;
    /** <code>WriteOperationType</code>  <a name="cfn-appflow-flow-salesforcedestinationproperties-writeoperationtype"></a>
  This specifies the type of write operation to be performed in Salesforce. When the value is <code>UPSERT</code>, then <code>idFieldNames</code> is required.<br />
  
  Required: No<br />
  
  Allowed values: <code>INSERT | UPDATE | UPSERT</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    writeOperationType?: Value<'INSERT' | 'UPDATE' | 'UPSERT'>;
}
