import { Value } from '../../../kloudformation/Value';
/**
  Determines the prefix that Amazon AppFlow applies to the destination folder name. You can name your destination folders according to the flow frequency and date.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-prefixconfig.html">the AWS Docs</a>
*/
export interface PrefixConfigProps {
    /** <code>PrefixType</code>  <a name="cfn-appflow-flow-prefixconfig-prefixtype"></a>
  Determines the format of the prefix, and whether it applies to the file name, file path, or both.<br />
  
  Required: No<br />
  
  Allowed values: <code>FILENAME | PATH | PATH_AND_FILENAME</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    prefixType?: Value<'FILENAME' | 'PATH' | 'PATH_AND_FILENAME'>;
    /** <code>PrefixFormat</code>  <a name="cfn-appflow-flow-prefixconfig-prefixformat"></a>
  Determines the level of granularity that’s included in the prefix.<br />
  
  Required: No<br />
  
  Allowed values: <code>DAY | HOUR | MINUTE | MONTH | YEAR</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    prefixFormat?: Value<'DAY' | 'HOUR' | 'MINUTE' | 'MONTH' | 'YEAR'>;
}
