import { Value } from '../../../kloudformation/Value';
import { UpsolverS3OutputFormatConfigProps } from './UpsolverS3OutputFormatConfigProps';
/**
  The properties that are applied when Upsolver is used as a destination.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-upsolverdestinationproperties.html">the AWS Docs</a>
*/
export interface UpsolverDestinationPropertiesProps {
    /** <code>BucketName</code>  <a name="cfn-appflow-flow-upsolverdestinationproperties-bucketname"></a>
  The Upsolver Amazon S3 bucket name in which Amazon AppFlow places the transferred data.<br />
  
  Required: Yes<br />
  
  Minimum: <code>16</code><br />
  
  Maximum: <code>63</code><br />
  
  Pattern: <code>^(upsolver-appflow)\S*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    bucketName: Value<string>;
    /** <code>BucketPrefix</code>  <a name="cfn-appflow-flow-upsolverdestinationproperties-bucketprefix"></a>
  The object key for the destination Upsolver Amazon S3 bucket in which Amazon AppFlow places the files.<br />
  
  Required: No<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>.*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    bucketPrefix?: Value<string>;
    /** <code>S3OutputFormatConfig</code>  <a name="cfn-appflow-flow-upsolverdestinationproperties-s3outputformatconfig"></a>
  The configuration that determines how data is formatted when Upsolver is used as the flow destination.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    s3OutputFormatConfig: UpsolverS3OutputFormatConfigProps;
}
