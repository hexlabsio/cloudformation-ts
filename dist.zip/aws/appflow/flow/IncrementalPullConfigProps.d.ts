import { Value } from '../../../kloudformation/Value';
/**
  Specifies the configuration used when importing incremental records from the source.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-incrementalpullconfig.html">the AWS Docs</a>
*/
export interface IncrementalPullConfigProps {
    /** <code>DatetimeTypeFieldName</code>  <a name="cfn-appflow-flow-incrementalpullconfig-datetimetypefieldname"></a>
  A field that specifies the date time or timestamp field as the criteria to use when importing incremental records from the source.<br />
  
  Required: No<br />
  
  Maximum: <code>256</code><br />
  
  Pattern: <code>.*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    datetimeTypeFieldName?: Value<string>;
}
