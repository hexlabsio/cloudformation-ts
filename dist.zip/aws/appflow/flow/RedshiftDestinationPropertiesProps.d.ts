import { Value } from '../../../kloudformation/Value';
import { ErrorHandlingConfigProps } from './ErrorHandlingConfigProps';
/**
  The properties that are applied when Amazon Redshift is being used as a destination.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-redshiftdestinationproperties.html">the AWS Docs</a>
*/
export interface RedshiftDestinationPropertiesProps {
    /** <code>Object</code>  <a name="cfn-appflow-flow-redshiftdestinationproperties-object"></a>
  The object specified in the Amazon Redshift flow destination.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    object: Value<string>;
    /** <code>IntermediateBucketName</code>  <a name="cfn-appflow-flow-redshiftdestinationproperties-intermediatebucketname"></a>
  The intermediate bucket that Amazon AppFlow uses when moving data into Amazon Redshift.<br />
  
  Required: Yes<br />
  
  Minimum: <code>3</code><br />
  
  Maximum: <code>63</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    intermediateBucketName: Value<string>;
    /** <code>BucketPrefix</code>  <a name="cfn-appflow-flow-redshiftdestinationproperties-bucketprefix"></a>
  The object key for the bucket in which Amazon AppFlow places the destination files.<br />
  
  Required: No<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>.*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    bucketPrefix?: Value<string>;
    /** <code>ErrorHandlingConfig</code>  <a name="cfn-appflow-flow-redshiftdestinationproperties-errorhandlingconfig"></a>
  The settings that determine how Amazon AppFlow handles an error when placing data in the Amazon Redshift destination. For example, this setting would determine if the flow should fail after one insertion error, or continue and attempt to insert every record regardless of the initial failure. <code>ErrorHandlingConfig</code> is a part of the destination connector details.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    errorHandlingConfig?: ErrorHandlingConfigProps;
}
