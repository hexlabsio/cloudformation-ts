import { Value } from '../../../kloudformation/Value';
import { ConnectorOperatorProps } from './ConnectorOperatorProps';
import { TaskPropertiesObjectProps } from './TaskPropertiesObjectProps';
/**
  The <code>Task</code> property type specifies the class for modeling different type of tasks. Task implementation varies based on the <code>TaskType</code>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-task.html">the AWS Docs</a>
*/
export interface TaskProps {
    /** <code>SourceFields</code>  <a name="cfn-appflow-flow-task-sourcefields"></a>
  The source fields to which a particular task is applied.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    sourceFields: Value<Value<string>[]>;
    /** <code>ConnectorOperator</code>  <a name="cfn-appflow-flow-task-connectoroperator"></a>
  The operation to be performed on the provided source fields.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    connectorOperator?: ConnectorOperatorProps;
    /** <code>DestinationField</code>  <a name="cfn-appflow-flow-task-destinationfield"></a>
  A field in a destination connector, or a field value against which Amazon AppFlow validates a source field.<br />
  
  Required: No<br />
  
  Maximum: <code>256</code><br />
  
  Pattern: <code>.*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    destinationField?: Value<string>;
    /** <code>TaskType</code>  <a name="cfn-appflow-flow-task-tasktype"></a>
  Specifies the particular task implementation that Amazon AppFlow performs.<br />
  
  Required: Yes<br />
  
  Allowed values: <code>Arithmetic | Filter | Map | Mask | Merge | Truncate | Validate</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    taskType: Value<'Arithmetic' | 'Filter' | 'Map' | 'Mask' | 'Merge' | 'Truncate' | 'Validate'>;
    /** <code>TaskProperties</code>  <a name="cfn-appflow-flow-task-taskproperties"></a>
  A map used to store task-related information. The execution service looks for particular information based on the <code>TaskType</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    taskProperties?: TaskPropertiesObjectProps[];
}
