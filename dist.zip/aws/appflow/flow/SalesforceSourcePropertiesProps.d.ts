import { Value } from '../../../kloudformation/Value';
/**
  The properties that are applied when Salesforce is being used as a source.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-salesforcesourceproperties.html">the AWS Docs</a>
*/
export interface SalesforceSourcePropertiesProps {
    /** <code>Object</code>  <a name="cfn-appflow-flow-salesforcesourceproperties-object"></a>
  The object specified in the Salesforce flow source.<br />
  
  Required: Yes<br />
  
  Maximum: <code>512</code><br />
  
  Pattern: <code>\S+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    object: Value<string>;
    /** <code>EnableDynamicFieldUpdate</code>  <a name="cfn-appflow-flow-salesforcesourceproperties-enabledynamicfieldupdate"></a>
  The flag that enables dynamic fetching of new (recently added) fields in the Salesforce objects while running a flow.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    enableDynamicFieldUpdate?: Value<boolean>;
    /** <code>IncludeDeletedRecords</code>  <a name="cfn-appflow-flow-salesforcesourceproperties-includedeletedrecords"></a>
  Indicates whether Amazon AppFlow includes deleted files in the flow run.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    includeDeletedRecords?: Value<boolean>;
}
