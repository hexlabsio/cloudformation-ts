import { Value } from '../../../kloudformation/Value';
import { PrefixConfigProps } from './PrefixConfigProps';
import { AggregationConfigProps } from './AggregationConfigProps';
/**
  The configuration that determines how Amazon AppFlow formats the flow output data when Upsolver is used as the destination.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-upsolvers3outputformatconfig.html">the AWS Docs</a>
*/
export interface UpsolverS3OutputFormatConfigProps {
    /** <code>FileType</code>  <a name="cfn-appflow-flow-upsolvers3outputformatconfig-filetype"></a>
  Indicates the file type that Amazon AppFlow places in the Upsolver Amazon S3 bucket.<br />
  
  Required: No<br />
  
  Allowed values: <code>CSV | JSON | PARQUET</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    fileType?: Value<'CSV' | 'JSON' | 'PARQUET'>;
    /** <code>PrefixConfig</code>  <a name="cfn-appflow-flow-upsolvers3outputformatconfig-prefixconfig"></a>
  Determines the prefix that Amazon AppFlow applies to the destination folder name. You can name your destination folders according to the flow frequency and date.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    prefixConfig: PrefixConfigProps;
    /** <code>AggregationConfig</code>  <a name="cfn-appflow-flow-upsolvers3outputformatconfig-aggregationconfig"></a>
  The aggregation settings that you can use to customize the output format of your flow data.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    aggregationConfig?: AggregationConfigProps;
}
