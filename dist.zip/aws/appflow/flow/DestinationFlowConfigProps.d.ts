import { Value } from '../../../kloudformation/Value';
import { DestinationConnectorPropertiesProps } from './DestinationConnectorPropertiesProps';
/**
  The <code>DestinationFlowConfig</code> property type specifies information about the configuration of destination connectors present in the flow.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-destinationflowconfig.html">the AWS Docs</a>
*/
export interface DestinationFlowConfigProps {
    /** <code>ConnectorType</code>  <a name="cfn-appflow-flow-destinationflowconfig-connectortype"></a>
  The type of destination connector, such as Salesforce, Amazon S3, and so on.<br />
  
  Allowed Values: <code>EventBridge | Redshift | S3 | Salesforce | Snowflake</code><br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    connectorType: Value<string>;
    /** <code>ConnectorProfileName</code>  <a name="cfn-appflow-flow-destinationflowconfig-connectorprofilename"></a>
  The name of the connector profile. This name must be unique for each connector profile in the AWS account.<br />
  
  Required: No<br />
  
  Maximum: <code>256</code><br />
  
  Pattern: <code>[\w/!@#+=.-]+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    connectorProfileName?: Value<string>;
    /** <code>DestinationConnectorProperties</code>  <a name="cfn-appflow-flow-destinationflowconfig-destinationconnectorproperties"></a>
  This stores the information that is required to query a particular connector.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    destinationConnectorProperties: DestinationConnectorPropertiesProps;
}
