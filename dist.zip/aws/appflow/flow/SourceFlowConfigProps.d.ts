import { Value } from '../../../kloudformation/Value';
import { SourceConnectorPropertiesProps } from './SourceConnectorPropertiesProps';
import { IncrementalPullConfigProps } from './IncrementalPullConfigProps';
/**
  Contains information about the configuration of the source connector used in the flow.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-sourceflowconfig.html">the AWS Docs</a>
*/
export interface SourceFlowConfigProps {
    /** <code>ConnectorType</code>  <a name="cfn-appflow-flow-sourceflowconfig-connectortype"></a>
  The type of source connector, such as Salesforce, Amplitude, and so on.<br />
  
  Allowed Values: S3 | Amplitude | Datadog | Dynatrace | Googleanalytics | Infornexus | Salesforce | Servicenow | Singular | Slack | Trendmicro | Veeva | Zendesk<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    connectorType: Value<string>;
    /** <code>ConnectorProfileName</code>  <a name="cfn-appflow-flow-sourceflowconfig-connectorprofilename"></a>
  The name of the connector profile. This name must be unique for each connector profile in the AWS account.<br />
  
  Required: No<br />
  
  Maximum: <code>256</code><br />
  
  Pattern: <code>[\w/!@#+=.-]+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    connectorProfileName?: Value<string>;
    /** <code>SourceConnectorProperties</code>  <a name="cfn-appflow-flow-sourceflowconfig-sourceconnectorproperties"></a>
  Specifies the information that is required to query a particular source connector.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    sourceConnectorProperties: SourceConnectorPropertiesProps;
    /** <code>IncrementalPullConfig</code>  <a name="cfn-appflow-flow-sourceflowconfig-incrementalpullconfig"></a>
  Defines the configuration for a scheduled incremental data pull. If a valid configuration is provided, the fields specified in the configuration are used when querying for the incremental data pull.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    incrementalPullConfig?: IncrementalPullConfigProps;
}
