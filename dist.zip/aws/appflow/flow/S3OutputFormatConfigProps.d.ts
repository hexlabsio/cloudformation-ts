import { Value } from '../../../kloudformation/Value';
import { PrefixConfigProps } from './PrefixConfigProps';
import { AggregationConfigProps } from './AggregationConfigProps';
/**
  The configuration that determines how Amazon AppFlow should format the flow output data when Amazon S3 is used as the destination.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-s3outputformatconfig.html">the AWS Docs</a>
*/
export interface S3OutputFormatConfigProps {
    /** <code>FileType</code>  <a name="cfn-appflow-flow-s3outputformatconfig-filetype"></a>
  Indicates the file type that Amazon AppFlow places in the Amazon S3 bucket.<br />
  
  Required: No<br />
  
  Allowed values: <code>CSV | JSON | PARQUET</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    fileType?: Value<'CSV' | 'JSON' | 'PARQUET'>;
    /** <code>PrefixConfig</code>  <a name="cfn-appflow-flow-s3outputformatconfig-prefixconfig"></a>
  Determines the prefix that Amazon AppFlow applies to the folder name in the Amazon S3 bucket. You can name folders according to the flow frequency and date.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    prefixConfig?: PrefixConfigProps;
    /** <code>AggregationConfig</code>  <a name="cfn-appflow-flow-s3outputformatconfig-aggregationconfig"></a>
  The aggregation settings that you can use to customize the output format of your flow data.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    aggregationConfig?: AggregationConfigProps;
}
