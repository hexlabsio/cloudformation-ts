import { Value } from '../../../kloudformation/Value';
/**
  The properties that are applied when Amazon Lookout for Metrics is used as a destination.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appflow-flow-lookoutmetricsdestinationproperties.html">the AWS Docs</a>
*/
export interface LookoutMetricsDestinationPropertiesProps {
    /** <code>Object</code>  <a name="cfn-appflow-flow-lookoutmetricsdestinationproperties-object"></a>
  The object specified in the Amazon Lookout for Metrics flow destination.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    object?: Value<string>;
}
