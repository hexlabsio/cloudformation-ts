import { Value } from '../../kloudformation/Value';
import { ConnectorProfileConfigProps } from './connectorprofile/ConnectorProfileConfigProps';
import { Attribute } from '../../kloudformation/Attribute';
import { KloudResource } from '../../kloudformation/KloudResource';
export declare type ConnectorProfileAttributes = {
    ConnectorProfileArn: Attribute<string>;
    CredentialsArn: Attribute<string>;
};
export declare type ConnectorProfile = ConnectorProfileProperties & {
    attributes: ConnectorProfileAttributes;
};
/**
  The <code>AWS::AppFlow::ConnectorProfile</code> resource is an Amazon AppFlow resource type that specifies the configuration profile for an instance of a connector. This includes the provided name, credentials ARN, connection-mode, and so on. The fields that are common to all types of connector profiles are explicitly specified under the <code>Properties</code> field. The rest of the connector-specific properties are specified under <code>Properties/ConnectorProfileConfig</code>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appflow-connectorprofile.html">the AWS Docs</a>
*/
export declare function connectorProfile(connectorProfileProps: ConnectorProfileProperties): ConnectorProfile;
/**
  The <code>AWS::AppFlow::ConnectorProfile</code> resource is an Amazon AppFlow resource type that specifies the configuration profile for an instance of a connector. This includes the provided name, credentials ARN, connection-mode, and so on. The fields that are common to all types of connector profiles are explicitly specified under the <code>Properties</code> field. The rest of the connector-specific properties are specified under <code>Properties/ConnectorProfileConfig</code>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appflow-connectorprofile.html">the AWS Docs</a>
*/
export interface ConnectorProfileProperties extends KloudResource {
    /** <code>ConnectorProfileName</code>  <a name="cfn-appflow-connectorprofile-connectorprofilename"></a>
  The name of the connector profile. The name is unique for each <code>ConnectorProfile</code> in the AWS account.<br />
  
  Required: Yes<br />
  
  Maximum: <code>256</code><br />
  
  Pattern: <code>[\w/!@#+=.-]+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    connectorProfileName: Value<string>;
    /** <code>KMSArn</code>  <a name="cfn-appflow-connectorprofile-kmsarn"></a>
  The ARN (Amazon Resource Name) of the Key Management Service (KMS) key you provide for encryption. This is required if you do not want to use the Amazon AppFlow-managed KMS key. If you don’t provide anything here, Amazon AppFlow uses the Amazon AppFlow-managed KMS key.<br />
  
  Required: No<br />
  
  Minimum: <code>20</code><br />
  
  Maximum: <code>2048</code><br />
  
  Pattern: <code>arn:aws:kms:.*:[0-9]+:.*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    kMSArn?: Value<string>;
    /** <code>ConnectorType</code>  <a name="cfn-appflow-connectorprofile-connectortype"></a>
  The type of connector, such as Salesforce, Amplitude, and so on.<br />
  
  Required: Yes<br />
  
  Allowed values: <code>Amplitude | CustomerProfiles | Datadog | Dynatrace | EventBridge | Googleanalytics | Honeycode | Infornexus | LookoutMetrics | Marketo | Redshift | S3 | Salesforce | Servicenow | Singular | Slack | Snowflake | Trendmicro | Upsolver | Veeva | Zendesk</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    connectorType: Value<'Amplitude' | 'CustomerProfiles' | 'Datadog' | 'Dynatrace' | 'EventBridge' | 'Googleanalytics' | 'Honeycode' | 'Infornexus' | 'LookoutMetrics' | 'Marketo' | 'Redshift' | 'S3' | 'Salesforce' | 'Servicenow' | 'Singular' | 'Slack' | 'Snowflake' | 'Trendmicro' | 'Upsolver' | 'Veeva' | 'Zendesk'>;
    /** <code>ConnectionMode</code>  <a name="cfn-appflow-connectorprofile-connectionmode"></a>
  Indicates the connection mode and if it is public or private.<br />
  
  Required: Yes<br />
  
  Allowed values: <code>Private | Public</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    connectionMode: Value<'Private' | 'Public'>;
    /** <code>ConnectorProfileConfig</code>  <a name="cfn-appflow-connectorprofile-connectorprofileconfig"></a>
  Defines the connector-specific configuration and credentials.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    connectorProfileConfig?: ConnectorProfileConfigProps;
}
