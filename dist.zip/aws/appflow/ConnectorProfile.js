"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  The <code>AWS::AppFlow::ConnectorProfile</code> resource is an Amazon AppFlow resource type that specifies the configuration profile for an instance of a connector. This includes the provided name, credentials ARN, connection-mode, and so on. The fields that are common to all types of connector profiles are explicitly specified under the <code>Properties</code> field. The rest of the connector-specific properties are specified under <code>Properties/ConnectorProfileConfig</code>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appflow-connectorprofile.html">the AWS Docs</a>
*/
function connectorProfile(connectorProfileProps) { return ({ ...connectorProfileProps, _logicalType: 'AWS::AppFlow::ConnectorProfile', attributes: { ConnectorProfileArn: 'ConnectorProfileArn', CredentialsArn: 'CredentialsArn' } }); }
exports.connectorProfile = connectorProfile;
