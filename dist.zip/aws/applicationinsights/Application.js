"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  The <code>AWS::ApplicationInsights::Application</code> resource adds an application that is created from a resource group.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-applicationinsights-application.html">the AWS Docs</a>
*/
function application(applicationProps) { return ({ ...applicationProps, _logicalType: 'AWS::ApplicationInsights::Application', attributes: { ApplicationARN: 'ApplicationARN' } }); }
exports.application = application;
