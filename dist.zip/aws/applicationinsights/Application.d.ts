import { Value } from '../../kloudformation/Value';
import { Tag } from '../Tag';
import { CustomComponentProps } from './application/CustomComponentProps';
import { LogPatternSetProps } from './application/LogPatternSetProps';
import { ComponentMonitoringSettingProps } from './application/ComponentMonitoringSettingProps';
import { Attribute } from '../../kloudformation/Attribute';
import { KloudResource } from '../../kloudformation/KloudResource';
export declare type ApplicationAttributes = {
    ApplicationARN: Attribute<string>;
};
export declare type Application = ApplicationProperties & {
    attributes: ApplicationAttributes;
};
/**
  The <code>AWS::ApplicationInsights::Application</code> resource adds an application that is created from a resource group.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-applicationinsights-application.html">the AWS Docs</a>
*/
export declare function application(applicationProps: ApplicationProperties): Application;
/**
  The <code>AWS::ApplicationInsights::Application</code> resource adds an application that is created from a resource group.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-applicationinsights-application.html">the AWS Docs</a>
*/
export interface ApplicationProperties extends KloudResource {
    /** <code>ResourceGroupName</code>  <a name="cfn-applicationinsights-application-resourcegroupname"></a>
  The name of the resource group used for the application.<br />
  
  Required: Yes<br />
  
  Minimum: <code>1</code><br />
  
  Maximum: <code>256</code><br />
  
  Pattern: <code>[a-zA-Z0-9\.\-_]*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    resourceGroupName: Value<string>;
    /** <code>CWEMonitorEnabled</code>  <a name="cfn-applicationinsights-application-cwemonitorenabled"></a>
  Indicates whether Application Insights can listen to CloudWatch events for the application resources, such as <code>instance terminated</code>, <code>failed deployment</code>, and others.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    cWEMonitorEnabled?: Value<boolean>;
    /** <code>OpsCenterEnabled</code>  <a name="cfn-applicationinsights-application-opscenterenabled"></a>
  Indicates whether Application Insights will create OpsItems for any problem that is detected by Application Insights for an application.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    opsCenterEnabled?: Value<boolean>;
    /** <code>OpsItemSNSTopicArn</code>  <a name="cfn-applicationinsights-application-opsitemsnstopicarn"></a>
  The SNS topic provided to Application Insights that is associated with the created OpsItems to receive SNS notifications for opsItem updates.<br />
  
  Required: No<br />
  
  Minimum: <code>20</code><br />
  
  Maximum: <code>300</code><br />
  
  Pattern: <code>^arn:aws(-\w+)?:[\w\d-]+:([\w\d-]*)?:[\w\d_-]*([:/].+)*$</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    opsItemSNSTopicArn?: Value<string>;
    /** <code>Tags</code>  <a name="cfn-applicationinsights-application-tags"></a>
  An array of <code>Tags</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: Tag[];
    /** <code>CustomComponents</code>  <a name="cfn-applicationinsights-application-customcomponents"></a>
  Describes a custom component by grouping similar standalone instances to monitor.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    customComponents?: CustomComponentProps[];
    /** <code>LogPatternSets</code>  <a name="cfn-applicationinsights-application-logpatternsets"></a>
  The log pattern sets.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    logPatternSets?: LogPatternSetProps[];
    /** <code>AutoConfigurationEnabled</code>  <a name="cfn-applicationinsights-application-autoconfigurationenabled"></a>
  If set to <code>true</code>, the application components will be configured with the monitoring configuration recommended by Application Insights.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    autoConfigurationEnabled?: Value<boolean>;
    /** <code>ComponentMonitoringSettings</code>  <a name="cfn-applicationinsights-application-componentmonitoringsettings"></a>
  The monitoring settings of the components.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    componentMonitoringSettings?: ComponentMonitoringSettingProps[];
}
