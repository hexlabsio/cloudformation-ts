import { Value } from '../../../kloudformation/Value';
/**
  The <code>AWS::ApplicationInsights::Application Alarm</code> property type defines a CloudWatch alarm to be monitored for the component.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationinsights-application-alarm.html">the AWS Docs</a>
*/
export interface AlarmProps {
    /** <code>AlarmName</code>  <a name="cfn-applicationinsights-application-alarm-alarmname"></a>
  The name of the CloudWatch alarm to be monitored for the component.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    alarmName: Value<string>;
    /** <code>Severity</code>  <a name="cfn-applicationinsights-application-alarm-severity"></a>
  Indicates the degree of outage when the alarm goes off.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    severity?: Value<string>;
}
