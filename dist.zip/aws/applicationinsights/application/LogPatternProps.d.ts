import { Value } from '../../../kloudformation/Value';
/**
  The <code>AWS::ApplicationInsights::Application LogPattern</code> property type specifies an object that defines the log patterns that belong to a <code>LogPatternSet</code>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationinsights-application-logpattern.html">the AWS Docs</a>
*/
export interface LogPatternProps {
    /** <code>PatternName</code>  <a name="cfn-applicationinsights-application-logpattern-patternname"></a>
  The name of the log pattern. A log pattern name can contain up to 50 characters, and it cannot be empty. The characters can be Unicode letters, digits, or one of the following symbols: period, dash, underscore.<br />
  
  Required: Yes<br />
  
  Minimum: <code>1</code><br />
  
  Maximum: <code>50</code><br />
  
  Pattern: <code>[a-zA-Z0-9\.\-_]*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    patternName: Value<string>;
    /** <code>Pattern</code>  <a name="cfn-applicationinsights-application-logpattern-pattern"></a>
  A regular expression that defines the log pattern. A log pattern can contain up to 50 characters, and it cannot be empty.<br />
  
  Required: Yes<br />
  
  Minimum: <code>1</code><br />
  
  Maximum: <code>50</code><br />
  
  Pattern: <code>[\S\s]+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    pattern: Value<string>;
    /** <code>Rank</code>  <a name="cfn-applicationinsights-application-logpattern-rank"></a>
  The rank of the log pattern.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    rank: Value<number>;
}
