import { Value } from '../../../kloudformation/Value';
/**
  The <code>AWS::ApplicationInsights::Application AlarmMetric</code> property type defines a metric to monitor for the component.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationinsights-application-alarmmetric.html">the AWS Docs</a>
*/
export interface AlarmMetricProps {
    /** <code>AlarmMetricName</code>  <a name="cfn-applicationinsights-application-alarmmetric-alarmmetricname"></a>
  The name of the metric to be monitored for the component. For metrics supported by Application Insights, see <a href="https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/appinsights-logs-and-metrics.html">Logs and metrics supported by Amazon CloudWatch Application Insights</a>.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    alarmMetricName: Value<string>;
}
