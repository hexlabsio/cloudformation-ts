import { Value } from '../../../kloudformation/Value';
import { ComponentConfigurationProps } from './ComponentConfigurationProps';
/**
  The <code>AWS::ApplicationInsights::Application ComponentMonitoringSetting</code> property type defines the monitoring setting of the component.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationinsights-application-componentmonitoringsetting.html">the AWS Docs</a>
*/
export interface ComponentMonitoringSettingProps {
    /** <code>ComponentName</code>  <a name="cfn-applicationinsights-application-componentmonitoringsetting-componentname"></a>
  The name of the component.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    componentName?: Value<string>;
    /** <code>ComponentARN</code>  <a name="cfn-applicationinsights-application-componentmonitoringsetting-componentarn"></a>
  The ARN of the component.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    componentARN?: Value<string>;
    /** <code>Tier</code>  <a name="cfn-applicationinsights-application-componentmonitoringsetting-tier"></a>
  The tier of the application component. Supported tiers include <code>DOT_NET_WORKER</code>, <code>DOT_NET_WEB</code>, <code>DOT_NET_CORE</code>, <code>SQL_SERVER</code>, and <code>DEFAULT</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tier?: Value<string>;
    /** <p> */
    componentConfigurationMode?: Value<string>;
    /** <code>DefaultOverwriteComponentConfiguration</code>  <a name="cfn-applicationinsights-application-componentmonitoringsetting-defaultoverwritecomponentconfiguration"></a>
  Customized overwrite monitoring settings. Required if CUSTOM mode is configured in <code>ComponentConfigurationMode</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    defaultOverwriteComponentConfiguration?: ComponentConfigurationProps;
    /** <code>CustomComponentConfiguration</code>  <a name="cfn-applicationinsights-application-componentmonitoringsetting-customcomponentconfiguration"></a>
  Customized monitoring settings. Required if CUSTOM mode is configured in <code>ComponentConfigurationMode</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    customComponentConfiguration?: ComponentConfigurationProps;
}
