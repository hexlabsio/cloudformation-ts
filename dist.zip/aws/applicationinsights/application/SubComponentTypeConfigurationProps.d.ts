import { Value } from '../../../kloudformation/Value';
import { SubComponentConfigurationDetailsProps } from './SubComponentConfigurationDetailsProps';
/**
  The <code>AWS::ApplicationInsights::Application SubComponentTypeConfiguration</code> property type specifies the sub-component configurations for a component.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationinsights-application-subcomponenttypeconfiguration.html">the AWS Docs</a>
*/
export interface SubComponentTypeConfigurationProps {
    /** <code>SubComponentType</code>  <a name="cfn-applicationinsights-application-subcomponenttypeconfiguration-subcomponenttype"></a>
  The sub-component type.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    subComponentType: Value<string>;
    /** <code>SubComponentConfigurationDetails</code>  <a name="cfn-applicationinsights-application-subcomponenttypeconfiguration-subcomponentconfigurationdetails"></a>
  The configuration settings of the sub-components.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    subComponentConfigurationDetails: SubComponentConfigurationDetailsProps;
}
