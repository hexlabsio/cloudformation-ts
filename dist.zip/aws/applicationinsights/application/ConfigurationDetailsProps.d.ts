import { AlarmMetricProps } from './AlarmMetricProps';
import { LogProps } from './LogProps';
import { WindowsEventProps } from './WindowsEventProps';
import { AlarmProps } from './AlarmProps';
import { JMXPrometheusExporterProps } from './JMXPrometheusExporterProps';
/**
  The <code>AWS::ApplicationInsights::Application ConfigurationDetails</code> property type specifies the configuration settings.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationinsights-application-configurationdetails.html">the AWS Docs</a>
*/
export interface ConfigurationDetailsProps {
    /** <code>AlarmMetrics</code>  <a name="cfn-applicationinsights-application-configurationdetails-alarmmetrics"></a>
  A list of metrics to monitor for the component. All component types can use <code>AlarmMetrics</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    alarmMetrics?: AlarmMetricProps[];
    /** <code>Logs</code>  <a name="cfn-applicationinsights-application-configurationdetails-logs"></a>
  A list of logs to monitor for the component. Only Amazon EC2 instances can use <code>Logs</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    logs?: LogProps[];
    /** <code>WindowsEvents</code>  <a name="cfn-applicationinsights-application-configurationdetails-windowsevents"></a>
  A list of Windows Events to monitor for the component. Only Amazon EC2 instances running on Windows can use <code>WindowsEvents</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    windowsEvents?: WindowsEventProps[];
    /** <code>Alarms</code>  <a name="cfn-applicationinsights-application-configurationdetails-alarms"></a>
  A list of alarms to monitor for the component. All component types can use <code>Alarm</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    alarms?: AlarmProps[];
    /** <code>JMXPrometheusExporter</code>  <a name="cfn-applicationinsights-application-configurationdetails-jmxprometheusexporter"></a>
  A list of Java metrics to monitor for the component.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    jMXPrometheusExporter?: JMXPrometheusExporterProps;
}
