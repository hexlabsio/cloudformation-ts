import { Value } from '../../../kloudformation/Value';
/**
  The <code>AWS::ApplicationInsights::Application JMXPrometheusExporter</code> property type defines the JMXPrometheus Exporter configuration. For more information, see the <a href="https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/component-config-sections.html#component-configuration-prometheus">component configuration</a> in the CloudWatch Application Insights documentation.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationinsights-application-jmxprometheusexporter.html">the AWS Docs</a>
*/
export interface JMXPrometheusExporterProps {
    /** <code>JMXURL</code>  <a name="cfn-applicationinsights-application-jmxprometheusexporter-jmxurl"></a>
  The complete JMX URL to connect to.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    jMXURL?: Value<string>;
    /** <code>HostPort</code>  <a name="cfn-applicationinsights-application-jmxprometheusexporter-hostport"></a>
  The host and port to connect to through remote JMX. Only one of <code>jmxURL</code> and <code>hostPort</code> can be specified.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    hostPort?: Value<string>;
    /** <code>PrometheusPort</code>  <a name="cfn-applicationinsights-application-jmxprometheusexporter-prometheusport"></a>
  The target port to send Prometheus metrics to. If not specified, the default port <code>9404</code> is used.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    prometheusPort?: Value<string>;
}
