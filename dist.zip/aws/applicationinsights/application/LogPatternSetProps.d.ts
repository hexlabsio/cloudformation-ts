import { Value } from '../../../kloudformation/Value';
import { LogPatternProps } from './LogPatternProps';
/**
  The <code>AWS::ApplicationInsights::Application LogPatternSet</code> property type specifies the log pattern set.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationinsights-application-logpatternset.html">the AWS Docs</a>
*/
export interface LogPatternSetProps {
    /** <code>PatternSetName</code>  <a name="cfn-applicationinsights-application-logpatternset-patternsetname"></a>
  The name of the log pattern. A log pattern name can contain up to 30 characters, and it cannot be empty. The characters can be Unicode letters, digits, or one of the following symbols: period, dash, underscore.<br />
  
  Required: Yes<br />
  
  Minimum: <code>1</code><br />
  
  Maximum: <code>30</code><br />
  
  Pattern: <code>[a-zA-Z0-9\.\-_]*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    patternSetName: Value<string>;
    /** <code>LogPatterns</code>  <a name="cfn-applicationinsights-application-logpatternset-logpatterns"></a>
  A list of objects that define the log patterns that belong to <code>LogPatternSet</code>.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    logPatterns: LogPatternProps[];
}
