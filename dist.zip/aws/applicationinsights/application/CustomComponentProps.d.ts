import { Value } from '../../../kloudformation/Value';
/**
  The <code>AWS::ApplicationInsights::Application CustomComponent</code> property type describes a custom component by grouping similar standalone instances to monitor.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationinsights-application-customcomponent.html">the AWS Docs</a>
*/
export interface CustomComponentProps {
    /** <code>ComponentName</code>  <a name="cfn-applicationinsights-application-customcomponent-componentname"></a>
  The name of the component.<br />
  
  Required: Yes<br />
  
  Minimum: <code>1</code><br />
  
  Maximum: <code>128</code><br />
  
  Pattern: <code>^[\d\w\-_\.+]*$</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    componentName: Value<string>;
    /** <code>ResourceList</code>  <a name="cfn-applicationinsights-application-customcomponent-resourcelist"></a>
  The list of resource ARNs that belong to the component.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    resourceList: Value<Value<string>[]>;
}
