import { Value } from '../../../kloudformation/Value';
/**
  The <code>AWS::ApplicationInsights::Application WindowsEvent</code> property type specifies a Windows Event to monitor for the component.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationinsights-application-windowsevent.html">the AWS Docs</a>
*/
export interface WindowsEventProps {
    /** <code>LogGroupName</code>  <a name="cfn-applicationinsights-application-windowsevent-loggroupname"></a>
  The CloudWatch log group name to be associated with the monitored log.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    logGroupName: Value<string>;
    /** <code>EventName</code>  <a name="cfn-applicationinsights-application-windowsevent-eventname"></a>
  The type of Windows Events to log, equivalent to the Windows Event log channel name. For example, System, Security, CustomEventName, and so on. This field is required for each type of Windows event to log.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    eventName: Value<string>;
    /** <code>EventLevels</code>  <a name="cfn-applicationinsights-application-windowsevent-eventlevels"></a>
  The levels of event to log. You must specify each level to log. Possible values include <code>INFORMATION</code>, <code>WARNING</code>, <code>ERROR</code>, <code>CRITICAL</code>, and <code>VERBOSE</code>. This field is required for each type of Windows Event to log.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    eventLevels: Value<Value<string>[]>;
    /** <code>PatternSet</code>  <a name="cfn-applicationinsights-application-windowsevent-patternset"></a>
  The log pattern set.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    patternSet?: Value<string>;
}
