import { Value } from '../../../kloudformation/Value';
/**
  The <code>AWS::ApplicationInsights::Application Log</code> property type specifies a log to monitor for the component.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationinsights-application-log.html">the AWS Docs</a>
*/
export interface LogProps {
    /** <code>LogGroupName</code>  <a name="cfn-applicationinsights-application-log-loggroupname"></a>
  The CloudWatch log group name to be associated with the monitored log.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    logGroupName?: Value<string>;
    /** <code>LogPath</code>  <a name="cfn-applicationinsights-application-log-logpath"></a>
  The path of the logs to be monitored. The log path must be an absolute Windows or Linux system file path. For more information, see <a href="https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/CloudWatch-Agent-Configuration-File-Details.html#CloudWatch-Agent-Configuration-File-Logssection">CloudWatch Agent Configuration File: Logs Section</a>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    logPath?: Value<string>;
    /** <code>LogType</code>  <a name="cfn-applicationinsights-application-log-logtype"></a>
  The log type decides the log patterns against which Application Insights analyzes the log. The log type is selected from the following: <code>SQL_SERVER</code>, <code>IIS</code>, <code>APPLICATION</code>, and <code>DEFAULT</code>.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    logType: Value<string>;
    /** <p> */
    encoding?: Value<string>;
    /** <code>PatternSet</code>  <a name="cfn-applicationinsights-application-log-patternset"></a>
  The log pattern set.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    patternSet?: Value<string>;
}
