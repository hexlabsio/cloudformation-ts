import { ConfigurationDetailsProps } from './ConfigurationDetailsProps';
import { SubComponentTypeConfigurationProps } from './SubComponentTypeConfigurationProps';
/**
  The <code>AWS::ApplicationInsights::Application ComponentConfiguration</code> property type defines the configuration settings of the component.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationinsights-application-componentconfiguration.html">the AWS Docs</a>
*/
export interface ComponentConfigurationProps {
    /** <code>ConfigurationDetails</code>  <a name="cfn-applicationinsights-application-componentconfiguration-configurationdetails"></a>
  The configuration settings.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    configurationDetails?: ConfigurationDetailsProps;
    /** <code>SubComponentTypeConfigurations</code>  <a name="cfn-applicationinsights-application-componentconfiguration-subcomponenttypeconfigurations"></a>
  Sub-component configurations of the component.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    subComponentTypeConfigurations?: SubComponentTypeConfigurationProps[];
}
