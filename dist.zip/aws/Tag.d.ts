import { Value } from '../kloudformation/Value';
/**
  You can use the Resource Tags property to apply tags to resources, which can help you identify and categorize those resources. You can tag only resources for which AWS CloudFormation supports tagging. For information about which resources you can tag with CloudFormation, see the individual resources in <a href="aws-template-resource-type-ref.md">AWS resource and property types reference</a>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resource-tags.html">the AWS Docs</a>
*/
export interface Tag {
    /** <code>Key</code>  <a name="cfn-resource-tags-key"></a>
  The key name of the tag. You can specify a value that’s 1 to 128 Unicode characters in length and can’t be prefixed with <code>aws:</code>. You can use any of the following characters: the set of Unicode letters, digits, whitespace, <code>_</code>, <code>.</code>, <code>/</code>, <code>=</code>, <code>+</code>, and <code>-</code>.<br />
  
  Required: Yes<br />
   */
    key: Value<string>;
    /** <code>Value</code>  <a name="cfn-resource-tags-value"></a>
  The value for the tag. You can specify a value that’s 0 to 256 characters in length.<br />
  
  Required: Yes<br />
   */
    value: Value<string>;
}
