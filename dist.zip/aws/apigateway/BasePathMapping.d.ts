import { Value } from '../../kloudformation/Value';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGateway::BasePathMapping</code> resource creates a base path that clients who call your API must use in the invocation URL.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-basepathmapping.html">the AWS Docs</a>
*/
export declare type BasePathMapping = BasePathMappingProperties;
export declare function basePathMapping(basePathMappingProps: BasePathMappingProperties): BasePathMapping;
/**
  The <code>AWS::ApiGateway::BasePathMapping</code> resource creates a base path that clients who call your API must use in the invocation URL.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-basepathmapping.html">the AWS Docs</a>
*/
export interface BasePathMappingProperties extends KloudResource {
    /** <code>BasePath</code>  <a name="cfn-apigateway-basepathmapping-basepath"></a>
  The base path name that callers of the API must provide in the URL after the domain name.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    basePath?: Value<string>;
    /** <code>DomainName</code>  <a name="cfn-apigateway-basepathmapping-domainname"></a>
  The <code>DomainName</code> of an <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-domainname.html">AWS::ApiGateway::DomainName</a> resource.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    domainName: Value<string>;
    /** <code>RestApiId</code>  <a name="cfn-apigateway-basepathmapping-restapiid"></a>
  The ID of the API.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    restApiId?: Value<string>;
    /** <code>Stage</code>  <a name="cfn-apigateway-basepathmapping-stage"></a>
  The name of the API’s stage.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    stage?: Value<string>;
}
