import { Value } from '../../../kloudformation/Value';
/**
  <code>ThrottleSettings</code> is a property of the <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-usageplan.html">AWS::ApiGateway::UsagePlan</a> resource that specifies the overall request rate (average requests per second) and burst capacity when users call your REST APIs.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigateway-usageplan-throttlesettings.html">the AWS Docs</a>
*/
export interface ThrottleSettingsProps {
    /** <code>BurstLimit</code>  <a name="cfn-apigateway-usageplan-throttlesettings-burstlimit"></a>
  The maximum API request rate limit over a time ranging from one to a few seconds. The maximum API request rate limit depends on whether the underlying token bucket is at its full capacity. For more information about request throttling, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-request-throttling.html">Manage API Request Throttling</a> in the
  API Gateway Developer Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    burstLimit?: Value<number>;
    /** <code>RateLimit</code>  <a name="cfn-apigateway-usageplan-throttlesettings-ratelimit"></a>
  The API request steady-state rate limit (average requests per second over an extended period of time). For more information about request throttling, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-request-throttling.html">Manage API Request Throttling</a> in the
  API Gateway Developer Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    rateLimit?: Value<number>;
}
