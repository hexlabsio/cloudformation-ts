import { Value } from '../../../kloudformation/Value';
/**
  <code>QuotaSettings</code> is a property of the <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-usageplan.html">AWS::ApiGateway::UsagePlan</a> resource that specifies the maximum number of requests users can make to your REST APIs.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigateway-usageplan-quotasettings.html">the AWS Docs</a>
*/
export interface QuotaSettingsProps {
    /** <code>Limit</code>  <a name="cfn-apigateway-usageplan-quotasettings-limit"></a>
  The maximum number of requests that users can make within the specified time period.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    limit?: Value<number>;
    /** <code>Offset</code>  <a name="cfn-apigateway-usageplan-quotasettings-offset"></a>
  The day that a time period starts. For example, with a time period of <code>WEEK</code>, an offset of <code>0</code> starts on Sunday, and an offset of <code>1</code> starts on Monday.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    offset?: Value<number>;
    /** <code>Period</code>  <a name="cfn-apigateway-usageplan-quotasettings-period"></a>
  The time period for which the maximum limit of requests applies, such as <code>DAY</code> or <code>WEEK</code>. For valid values, see the period property for the <a href="https://docs.aws.amazon.com/apigateway/api-reference/resource/usage-plan">UsagePlan</a> resource in the
  Amazon API Gateway REST API Reference: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    period?: Value<string>;
}
