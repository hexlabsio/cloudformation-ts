import { Value } from '../../../kloudformation/Value';
import { ThrottleSettingsProps } from './ThrottleSettingsProps';
/**
  <code>ApiStage</code> is a property of the <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-usageplan.html">AWS::ApiGateway::UsagePlan</a> resource that specifies which stages and APIs to associate with a usage plan.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigateway-usageplan-apistage.html">the AWS Docs</a>
*/
export interface ApiStageProps {
    /** <code>ApiId</code>  <a name="cfn-apigateway-usageplan-apistage-apiid"></a>
  The ID of an API that is in the specified <code>Stage</code> property that you want to associate with the usage plan.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    apiId?: Value<string>;
    /** <code>Stage</code>  <a name="cfn-apigateway-usageplan-apistage-stage"></a>
  The name of the stage to associate with the usage plan.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    stage?: Value<string>;
    /** <code>Throttle</code>  <a name="cfn-apigateway-usageplan-apistage-throttle"></a>
  Map containing method-level throttling information for an API stage in a usage plan. The key for the map is the path and method for which to configure custom throttling, for example, “/pets/GET”.<br />
  Duplicates are not allowed.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    throttle?: {
        [key: string]: ThrottleSettingsProps;
    };
}
