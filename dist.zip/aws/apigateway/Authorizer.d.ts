import { Value } from '../../kloudformation/Value';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGateway::Authorizer</code> resource creates an authorization layer that API Gateway activates for methods that have authorization enabled. API Gateway activates the authorizer when a client calls those methods.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-authorizer.html">the AWS Docs</a>
*/
export declare type Authorizer = AuthorizerProperties;
export declare function authorizer(authorizerProps: AuthorizerProperties): Authorizer;
/**
  The <code>AWS::ApiGateway::Authorizer</code> resource creates an authorization layer that API Gateway activates for methods that have authorization enabled. API Gateway activates the authorizer when a client calls those methods.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-authorizer.html">the AWS Docs</a>
*/
export interface AuthorizerProperties extends KloudResource {
    /** <code>AuthType</code>  <a name="cfn-apigateway-authorizer-authtype"></a>
  An optional customer-defined field that’s used in OpenApi imports and exports without functional impact.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    authType?: Value<string>;
    /** <code>AuthorizerCredentials</code>  <a name="cfn-apigateway-authorizer-authorizercredentials"></a>
  The credentials that are required for the authorizer. To specify an IAM role that API Gateway assumes, specify the role’s Amazon Resource Name (ARN). To use resource-based permissions on the Lambda function, specify null.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    authorizerCredentials?: Value<string>;
    /** <code>AuthorizerResultTtlInSeconds</code>  <a name="cfn-apigateway-authorizer-authorizerresultttlinseconds"></a>
  The time-to-live (TTL) period, in seconds, that specifies how long API Gateway caches authorizer results. If you specify a value greater than 0, API Gateway caches the authorizer responses. By default, API Gateway sets this property to 300. The maximum value is 3600, or 1 hour.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    authorizerResultTtlInSeconds?: Value<number>;
    /** <code>AuthorizerUri</code>  <a name="cfn-apigateway-authorizer-authorizeruri"></a>
  The authorizer’s Uniform Resource Identifier (URI). If you specify <code>TOKEN</code> for the authorizer’s <code>Type</code> property, specify a Lambda function URI that has the form <code>arn:aws:apigateway:region:lambda:path/path</code>. The path usually has the form /2015-03-31/functions/
  LambdaFunctionARN: nvocations.<br />
  
  Required: Conditional<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    authorizerUri?: Value<string>;
    /** <code>IdentitySource</code>  <a name="cfn-apigateway-authorizer-identitysource"></a>
  The source of the identity in an incoming request.<br />
  If you specify <code>TOKEN</code> or <code>COGNITO_USER_POOLS</code> for the <code>Type</code> property, specify a header mapping expression using the form <code>method.request.header.name</code>, where
  name: s the name of a custom authorization header that clients submit as part of their requests.<br />
  If you specify <code>REQUEST</code> for the <code>Type</code> property, specify a comma-separated string of one or more mapping expressions of the specified request parameter using the form <code>method.request.parameter.name</code>. For supported parameter types, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/configure-api-gateway-lambda-authorization-with-console.html">Configure Lambda Authorizer Using the API Gateway Console</a> in the
  API Gateway Developer Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    identitySource?: Value<string>;
    /** <code>IdentityValidationExpression</code>  <a name="cfn-apigateway-authorizer-identityvalidationexpression"></a>
  A validation expression for the incoming identity. If you specify <code>TOKEN</code> for the authorizer’s <code>Type</code> property, specify a regular expression. API Gateway uses the expression to attempt to match the incoming client token, and proceeds if the token matches. If the token doesn’t match, API Gateway responds with a 401 (unauthorized request) error code.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    identityValidationExpression?: Value<string>;
    /** <code>Name</code>  <a name="cfn-apigateway-authorizer-name"></a>
  The name of the authorizer.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    name?: Value<string>;
    /** <code>ProviderARNs</code>  <a name="cfn-apigateway-authorizer-providerarns"></a>
  A list of the Amazon Cognito user pool Amazon Resource Names (ARNs) to associate with this authorizer. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-integrate-with-cognito.html#apigateway-enable-cognito-user-pool">Use Amazon Cognito User Pools</a> in the
  API Gateway Developer Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    providerARNs?: Value<Value<string>[]>;
    /** <code>RestApiId</code>  <a name="cfn-apigateway-authorizer-restapiid"></a>
  The ID of the <code>RestApi</code> resource that API Gateway creates the authorizer in.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    restApiId: Value<string>;
    /** <p> */
    type: Value<string>;
}
