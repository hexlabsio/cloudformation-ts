import { Value } from '../../../kloudformation/Value';
/**
  The <code>EndpointConfiguration</code> property type specifies the endpoint types of an Amazon API Gateway domain name.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigateway-domainname-endpointconfiguration.html">the AWS Docs</a>
*/
export interface EndpointConfigurationProps {
    /** <code>Types</code>  <a name="cfn-apigateway-domainname-endpointconfiguration-types"></a>
  A list of endpoint types of an API or its custom domain name. For an edge-optimized API and its custom domain name, the endpoint type is <code>EDGE</code>. For a regional API and its custom domain name, the endpoint type is <code>REGIONAL</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    types?: Value<Value<string>[]>;
}
