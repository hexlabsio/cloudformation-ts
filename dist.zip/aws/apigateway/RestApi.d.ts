import { Value } from '../../kloudformation/Value';
import { S3LocationProps } from './restapi/S3LocationProps';
import { EndpointConfigurationProps } from './restapi/EndpointConfigurationProps';
import { Tag } from '../Tag';
import { Attribute } from '../../kloudformation/Attribute';
import { KloudResource } from '../../kloudformation/KloudResource';
export declare type RestApiAttributes = {
    RootResourceId: Attribute<string>;
};
export declare type RestApi = RestApiProperties & {
    attributes: RestApiAttributes;
};
/**
  The <code>AWS::ApiGateway::RestApi</code> resource creates a REST API. For more information, see <a href="https://docs.aws.amazon.com/apigateway/api-reference/link-relation/restapi-create/">restapi:create</a> in the <em>Amazon API Gateway REST API Reference</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-restapi.html">the AWS Docs</a>
*/
export declare function restApi(restApiProps: RestApiProperties): RestApi;
/**
  The <code>AWS::ApiGateway::RestApi</code> resource creates a REST API. For more information, see <a href="https://docs.aws.amazon.com/apigateway/api-reference/link-relation/restapi-create/">restapi:create</a> in the <em>Amazon API Gateway REST API Reference</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-restapi.html">the AWS Docs</a>
*/
export interface RestApiProperties extends KloudResource {
    /** <p> */
    apiKeySourceType?: Value<string>;
    /** <code>BinaryMediaTypes</code>  <a name="cfn-apigateway-restapi-binarymediatypes"></a>
  The list of binary media types that are supported by the <code>RestApi</code> resource, such as <code>image/png</code> or <code>application/octet-stream</code>. By default, <code>RestApi</code> supports only UTF-8-encoded text payloads. Duplicates are not allowed. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-payload-encodings.html">Enable Support for Binary Payloads in API Gateway</a> in the
  API Gateway Developer Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    binaryMediaTypes?: Value<Value<string>[]>;
    /** <code>Body</code>  <a name="cfn-apigateway-restapi-body"></a>
  An OpenAPI specification that defines a set of RESTful APIs in JSON format. For YAML templates, you can also provide the specification in YAML format.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    body?: Value<any>;
    /** <code>BodyS3Location</code>  <a name="cfn-apigateway-restapi-bodys3location"></a>
  The Amazon Simple Storage Service (Amazon S3) location that points to an OpenAPI file, which defines a set of RESTful APIs in JSON or YAML format.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    bodyS3Location?: S3LocationProps;
    /** <code>CloneFrom</code>  <a name="cfn-apigateway-restapi-clonefrom"></a>
  The ID of the <code>RestApi</code> resource that you want to clone.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    cloneFrom?: Value<string>;
    /** <code>Description</code>  <a name="cfn-apigateway-restapi-description"></a>
  A description of the <code>RestApi</code> resource.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>DisableExecuteApiEndpoint</code>  <a name="cfn-apigateway-restapi-disableexecuteapiendpoint"></a>
  Specifies whether clients can invoke your API by using the default <code>execute-api</code> endpoint. By default, clients can invoke your API with the default https://{api_id}.execute-api.{region}.amazonaws.com endpoint. To require that clients use a custom domain name to invoke your API, disable the default endpoint.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    disableExecuteApiEndpoint?: Value<boolean>;
    /** <code>EndpointConfiguration</code>  <a name="cfn-apigateway-restapi-endpointconfiguration"></a>
  A list of the endpoint types of the API. Use this property when creating an API. When importing an existing API, specify the endpoint configuration types using the <code>Parameters</code> property.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    endpointConfiguration?: EndpointConfigurationProps;
    /** <code>FailOnWarnings</code>  <a name="cfn-apigateway-restapi-failonwarnings"></a>
  Indicates whether to roll back the resource if a warning occurs while API Gateway is creating the <code>RestApi</code> resource.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    failOnWarnings?: Value<boolean>;
    /** <code>MinimumCompressionSize</code>  <a name="cfn-apigateway-restapi-minimumcompressionsize"></a>
  A nullable integer that is used to enable compression (with non-negative between 0 and 10485760 (10M) bytes, inclusive) or disable compression (with a null value) on an API. When compression is enabled, compression or decompression is not applied on the payload if the payload size is smaller than this value. Setting it to zero allows compression for any payload size.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    minimumCompressionSize?: Value<number>;
    /** <code>Name</code>  <a name="cfn-apigateway-restapi-name"></a>
  A name for the <code>RestApi</code> resource.<br />
  
  Required: Conditional<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    name?: Value<string>;
    /** <code>Parameters</code>  <a name="cfn-apigateway-restapi-parameters"></a>
  Custom header parameters for the request.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    parameters?: Value<{
        [key: string]: Value<string>;
    }>;
    /** <code>Policy</code>  <a name="cfn-apigateway-restapi-policy"></a>
  A policy document that contains the permissions for the <code>RestApi</code> resource. To set the ARN for the policy, use the <code>!Join</code> intrinsic function with <code>&quot;&quot;</code> as delimiter and values of <code>&quot;execute-api:/&quot;</code> and <code>&quot;*&quot;</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    policy?: Value<any>;
    /** <code>Tags</code>  <a name="cfn-apigateway-restapi-tags"></a>
  An array of arbitrary tags (key-value pairs) to associate with the API.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: Tag[];
}
