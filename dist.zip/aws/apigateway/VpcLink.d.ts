import { Value } from '../../kloudformation/Value';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGateway::VpcLink</code> resource creates an API Gateway VPC link for a REST API to access resources in an Amazon Virtual Private Cloud (VPC). For more information, see <a href="https://docs.aws.amazon.com/apigateway/api-reference/link-relation/vpclink-create/">vpclink:create</a> in the <code>Amazon API Gateway REST API Reference</code>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-vpclink.html">the AWS Docs</a>
*/
export declare type VpcLink = VpcLinkProperties;
export declare function vpcLink(vpcLinkProps: VpcLinkProperties): VpcLink;
/**
  The <code>AWS::ApiGateway::VpcLink</code> resource creates an API Gateway VPC link for a REST API to access resources in an Amazon Virtual Private Cloud (VPC). For more information, see <a href="https://docs.aws.amazon.com/apigateway/api-reference/link-relation/vpclink-create/">vpclink:create</a> in the <code>Amazon API Gateway REST API Reference</code>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-vpclink.html">the AWS Docs</a>
*/
export interface VpcLinkProperties extends KloudResource {
    /** <code>Description</code>  <a name="cfn-apigateway-vpclink-description"></a>
  A description of the VPC link.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>TargetArns</code>  <a name="cfn-apigateway-vpclink-targetarns"></a>
  The ARN of network load balancer of the VPC targeted by the VPC link. The network load balancer must be owned by the same AWS account of the API owner.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    targetArns: Value<Value<string>[]>;
    /** <code>Name</code>  <a name="cfn-apigateway-vpclink-name"></a>
  A name for the VPC link.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    name: Value<string>;
}
