"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function authorizer(authorizerProps) { return ({ ...authorizerProps, _logicalType: 'AWS::ApiGateway::Authorizer' }); }
exports.authorizer = authorizer;
