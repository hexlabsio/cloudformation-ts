import { Value } from '../../../kloudformation/Value';
/**
  <code>StageKey</code> is a property of the <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-apikey.html">AWS::ApiGateway::ApiKey</a> resource that specifies the stage to associate with the API key. This association allows only clients with the key to make requests to methods in that stage.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigateway-apikey-stagekey.html">the AWS Docs</a>
*/
export interface StageKeyProps {
    /** <code>RestApiId</code>  <a name="cfn-apigateway-apikey-stagekey-restapiid"></a>
  The ID of a <code>RestApi</code> resource that includes the stage with which you want to associate the API key.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    restApiId?: Value<string>;
    /** <code>StageName</code>  <a name="cfn-apigateway-apikey-stagekey-stagename"></a>
  The name of the stage with which to associate the API key. The stage must be included in the <code>RestApi</code> resource that you specified in the <code>RestApiId</code> property.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    stageName?: Value<string>;
}
