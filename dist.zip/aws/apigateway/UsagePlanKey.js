"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function usagePlanKey(usagePlanKeyProps) { return ({ ...usagePlanKeyProps, _logicalType: 'AWS::ApiGateway::UsagePlanKey' }); }
exports.usagePlanKey = usagePlanKey;
