import { Value } from '../../kloudformation/Value';
import { EndpointConfigurationProps } from './domainname/EndpointConfigurationProps';
import { MutualTlsAuthenticationProps } from './domainname/MutualTlsAuthenticationProps';
import { Tag } from '../Tag';
import { Attribute } from '../../kloudformation/Attribute';
import { KloudResource } from '../../kloudformation/KloudResource';
export declare type DomainNameAttributes = {
    DistributionDomainName: Attribute<string>;
    DistributionHostedZoneId: Attribute<string>;
    RegionalDomainName: Attribute<string>;
    RegionalHostedZoneId: Attribute<string>;
};
export declare type DomainName = DomainNameProperties & {
    attributes: DomainNameAttributes;
};
/**
  The <code>AWS::ApiGateway::DomainName</code> resource specifies a custom domain name for your API in API Gateway.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-domainname.html">the AWS Docs</a>
*/
export declare function domainName(domainNameProps: DomainNameProperties): DomainName;
/**
  The <code>AWS::ApiGateway::DomainName</code> resource specifies a custom domain name for your API in API Gateway.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-domainname.html">the AWS Docs</a>
*/
export interface DomainNameProperties extends KloudResource {
    /** <code>DomainName</code>  <a name="cfn-apigateway-domainname-domainname"></a>
  The custom domain name for your API. Uppercase letters are not supported.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    domainName?: Value<string>;
    /** <code>EndpointConfiguration</code>  <a name="cfn-apigateway-domainname-endpointconfiguration"></a>
  A list of the endpoint types of the domain name.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    endpointConfiguration?: EndpointConfigurationProps;
    /** <code>MutualTlsAuthentication</code>  <a name="cfn-apigateway-domainname-mutualtlsauthentication"></a>
  The mutual TLS authentication configuration for a custom domain name.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    mutualTlsAuthentication?: MutualTlsAuthenticationProps;
    /** <code>CertificateArn</code>  <a name="cfn-apigateway-domainname-certificatearn"></a>
  The reference to an AWS-managed certificate for use by the edge-optimized endpoint for this domain name. AWS Certificate Manager is the only supported source. For requirements and additional information about setting up certificates, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/how-to-custom-domains.html#how-to-custom-domains-prerequisites">Get Certificates Ready in AWS Certificate Manager</a> in the
  API Gateway Developer Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    certificateArn?: Value<string>;
    /** <code>RegionalCertificateArn</code>  <a name="cfn-apigateway-domainname-regionalcertificatearn"></a>
  The reference to an AWS-managed certificate for use by the regional endpoint for the domain name. AWS Certificate Manager is the only supported source.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    regionalCertificateArn?: Value<string>;
    /** <code>SecurityPolicy</code>  <a name="cfn-apigateway-domainname-securitypolicy"></a>
  The Transport Layer Security (TLS) version + cipher suite for this domain name.<br />
  Valid values include <code>TLS_1_0</code> and <code>TLS_1_2</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    securityPolicy?: Value<string>;
    /** <code>Tags</code>  <a name="cfn-apigateway-domainname-tags"></a>
  An array of arbitrary tags (key-value pairs) to associate with the domain name.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: Tag[];
}
