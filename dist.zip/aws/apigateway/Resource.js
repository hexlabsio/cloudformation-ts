"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function resource(resourceProps) { return ({ ...resourceProps, _logicalType: 'AWS::ApiGateway::Resource' }); }
exports.resource = resource;
