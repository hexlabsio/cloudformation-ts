"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function method(methodProps) { return ({ ...methodProps, _logicalType: 'AWS::ApiGateway::Method' }); }
exports.method = method;
