import { Value } from '../../kloudformation/Value';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGateway::DocumentationVersion</code> resource creates a snapshot of the documentation for an API. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-documenting-api-content-representation.html">Representation of API Documentation in API Gateway</a> in the <em>API Gateway Developer Guide</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-documentationversion.html">the AWS Docs</a>
*/
export declare type DocumentationVersion = DocumentationVersionProperties;
export declare function documentationVersion(documentationVersionProps: DocumentationVersionProperties): DocumentationVersion;
/**
  The <code>AWS::ApiGateway::DocumentationVersion</code> resource creates a snapshot of the documentation for an API. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-documenting-api-content-representation.html">Representation of API Documentation in API Gateway</a> in the <em>API Gateway Developer Guide</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-documentationversion.html">the AWS Docs</a>
*/
export interface DocumentationVersionProperties extends KloudResource {
    /** <code>Description</code>  <a name="cfn-apigateway-documentationversion-description"></a>
  The description of the API documentation snapshot.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>DocumentationVersion</code>  <a name="cfn-apigateway-documentationversion-documentationversion"></a>
  The version identifier of the API documentation snapshot.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    documentationVersion: Value<string>;
    /** <code>RestApiId</code>  <a name="cfn-apigateway-documentationversion-restapiid"></a>
  The identifier of the API.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    restApiId: Value<string>;
}
