import { Value } from '../../kloudformation/Value';
import { Tag } from '../Tag';
import { Attribute } from '../../kloudformation/Attribute';
import { KloudResource } from '../../kloudformation/KloudResource';
export declare type ClientCertificateAttributes = {
    ClientCertificateId: Attribute<string>;
};
export declare type ClientCertificate = ClientCertificateProperties & {
    attributes: ClientCertificateAttributes;
};
/**
  The <code>AWS::ApiGateway::ClientCertificate</code> resource creates a client certificate that API Gateway uses to configure client-side SSL authentication for sending requests to the integration endpoint.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-clientcertificate.html">the AWS Docs</a>
*/
export declare function clientCertificate(clientCertificateProps: ClientCertificateProperties): ClientCertificate;
/**
  The <code>AWS::ApiGateway::ClientCertificate</code> resource creates a client certificate that API Gateway uses to configure client-side SSL authentication for sending requests to the integration endpoint.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-clientcertificate.html">the AWS Docs</a>
*/
export interface ClientCertificateProperties extends KloudResource {
    /** <code>Description</code>  <a name="cfn-apigateway-clientcertificate-description"></a>
  A description of the client certificate.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>Tags</code>  <a name="cfn-apigateway-clientcertificate-tags"></a>
  An array of arbitrary tags (key-value pairs) to associate with the client certificate.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: Tag[];
}
