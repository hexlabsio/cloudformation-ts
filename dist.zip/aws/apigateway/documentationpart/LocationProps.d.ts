import { Value } from '../../../kloudformation/Value';
/**
  The <code>Location</code> property specifies the location of the Amazon API Gateway API entity that the documentation applies to. <code>Location</code> is a property of the <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-documentationpart.html">AWS::ApiGateway::DocumentationPart</a> resource.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigateway-documentationpart-location.html">the AWS Docs</a>
*/
export interface LocationProps {
    /** <code>Method</code>  <a name="cfn-apigateway-documentationpart-location-method"></a>
  The HTTP verb of a method.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    method?: Value<string>;
    /** <code>Name</code>  <a name="cfn-apigateway-documentationpart-location-name"></a>
  The name of the targeted API entity.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    name?: Value<string>;
    /** <code>Path</code>  <a name="cfn-apigateway-documentationpart-location-path"></a>
  The URL path of the target.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    path?: Value<string>;
    /** <code>StatusCode</code>  <a name="cfn-apigateway-documentationpart-location-statuscode"></a>
  The HTTP status code of a response.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    statusCode?: Value<string>;
    /** <code>Type</code>  <a name="cfn-apigateway-documentationpart-location-type"></a>
  The type of API entity that the documentation content applies to.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    type?: Value<string>;
}
