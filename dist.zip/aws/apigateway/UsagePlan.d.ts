import { ApiStageProps } from './usageplan/ApiStageProps';
import { Value } from '../../kloudformation/Value';
import { QuotaSettingsProps } from './usageplan/QuotaSettingsProps';
import { Tag } from '../Tag';
import { ThrottleSettingsProps } from './usageplan/ThrottleSettingsProps';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGateway::UsagePlan</code> resource creates a usage plan for deployed APIs. A usage plan enforces throttling and quota limits on individual client API keys. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-api-usage-plans.html">Creating and Using API Usage Plans in Amazon API Gateway</a> in the <em>API Gateway Developer Guide</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-usageplan.html">the AWS Docs</a>
*/
export declare type UsagePlan = UsagePlanProperties;
export declare function usagePlan(usagePlanProps: UsagePlanProperties): UsagePlan;
/**
  The <code>AWS::ApiGateway::UsagePlan</code> resource creates a usage plan for deployed APIs. A usage plan enforces throttling and quota limits on individual client API keys. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-api-usage-plans.html">Creating and Using API Usage Plans in Amazon API Gateway</a> in the <em>API Gateway Developer Guide</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-usageplan.html">the AWS Docs</a>
*/
export interface UsagePlanProperties extends KloudResource {
    /** <code>ApiStages</code>  <a name="cfn-apigateway-usageplan-apistages"></a>
  The API stages to associate with this usage plan.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    apiStages?: ApiStageProps[];
    /** <code>Description</code>  <a name="cfn-apigateway-usageplan-description"></a>
  A description of the usage plan.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>Quota</code>  <a name="cfn-apigateway-usageplan-quota"></a>
  Configures the number of requests that users can make within a given interval.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    quota?: QuotaSettingsProps;
    /** <code>Tags</code>  <a name="cfn-apigateway-usageplan-tags"></a>
  An array of arbitrary tags (key-value pairs) to associate with the usage plan.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: Tag[];
    /** <code>Throttle</code>  <a name="cfn-apigateway-usageplan-throttle"></a>
  Configures the overall request rate (average requests per second) and burst capacity.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    throttle?: ThrottleSettingsProps;
    /** <code>UsagePlanName</code>  <a name="cfn-apigateway-usageplan-usageplanname"></a>
  A name for the usage plan.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    usagePlanName?: Value<string>;
}
