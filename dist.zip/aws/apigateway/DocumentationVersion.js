"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function documentationVersion(documentationVersionProps) { return ({ ...documentationVersionProps, _logicalType: 'AWS::ApiGateway::DocumentationVersion' }); }
exports.documentationVersion = documentationVersion;
