"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function vpcLink(vpcLinkProps) { return ({ ...vpcLinkProps, _logicalType: 'AWS::ApiGateway::VpcLink' }); }
exports.vpcLink = vpcLink;
