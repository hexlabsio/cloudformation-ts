"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  The <code>AWS::ApiGateway::ApiKey</code> resource creates a unique key that you can distribute to clients who are executing API Gateway <code>Method</code> resources that require an API key. To specify which API key clients must use, map the API key with the <code>RestApi</code> and <code>Stage</code> resources that include the methods that require a key.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-apikey.html">the AWS Docs</a>
*/
function apiKey(apiKeyProps) { return ({ ...apiKeyProps, _logicalType: 'AWS::ApiGateway::ApiKey', attributes: { APIKeyId: 'APIKeyId' } }); }
exports.apiKey = apiKey;
