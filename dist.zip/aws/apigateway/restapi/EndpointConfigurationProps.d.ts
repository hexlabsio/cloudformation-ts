import { Value } from '../../../kloudformation/Value';
/**
  The <code>EndpointConfiguration</code> property type specifies the endpoint types of a REST API.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigateway-restapi-endpointconfiguration.html">the AWS Docs</a>
*/
export interface EndpointConfigurationProps {
    /** <p> */
    types?: Value<Value<string>[]>;
    /** <code>VpcEndpointIds</code>  <a name="cfn-apigateway-restapi-endpointconfiguration-vpcendpointids"></a>
  A list of VPC endpoint IDs of an API (<a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-restapi.html">AWS::ApiGateway::RestApi</a>) against which to create Route53 ALIASes. It is only supported for <code>PRIVATE</code> endpoint type.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    vpcEndpointIds?: Value<Value<string>[]>;
}
