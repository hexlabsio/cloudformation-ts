import { Value } from '../../../kloudformation/Value';
/**
  <code>S3Location</code> is a property of the <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-restapi.html">AWS::ApiGateway::RestApi</a> resource that specifies the Amazon S3 location of a OpenAPI (formerly Swagger) file that defines a set of RESTful APIs in JSON or YAML.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigateway-restapi-s3location.html">the AWS Docs</a>
*/
export interface S3LocationProps {
    /** <code>Bucket</code>  <a name="cfn-apigateway-restapi-s3location-bucket"></a>
  The name of the S3 bucket where the OpenAPI file is stored.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    bucket?: Value<string>;
    /** <code>ETag</code>  <a name="cfn-apigateway-restapi-s3location-etag"></a>
  The Amazon S3 ETag (a file checksum) of the OpenAPI file. If you don’t specify a value, API Gateway skips ETag validation of your OpenAPI file.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    eTag?: Value<string>;
    /** <code>Key</code>  <a name="cfn-apigateway-restapi-s3location-key"></a>
  The file name of the OpenAPI file (Amazon S3 object name).<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    key?: Value<string>;
    /** <code>Version</code>  <a name="cfn-apigateway-restapi-s3location-version"></a>
  For versioning-enabled buckets, a specific version of the OpenAPI file.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    version?: Value<string>;
}
