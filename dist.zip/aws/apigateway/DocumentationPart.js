"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function documentationPart(documentationPartProps) { return ({ ...documentationPartProps, _logicalType: 'AWS::ApiGateway::DocumentationPart' }); }
exports.documentationPart = documentationPart;
