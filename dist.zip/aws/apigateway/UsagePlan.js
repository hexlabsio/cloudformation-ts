"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function usagePlan(usagePlanProps) { return ({ ...usagePlanProps, _logicalType: 'AWS::ApiGateway::UsagePlan' }); }
exports.usagePlan = usagePlan;
