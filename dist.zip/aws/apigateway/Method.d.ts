import { Value } from '../../kloudformation/Value';
import { IntegrationProps } from './method/IntegrationProps';
import { MethodResponseProps } from './method/MethodResponseProps';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGateway::Method</code> resource creates API Gateway methods that define the parameters and body that clients must send in their requests.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-method.html">the AWS Docs</a>
*/
export declare type Method = MethodProperties;
export declare function method(methodProps: MethodProperties): Method;
/**
  The <code>AWS::ApiGateway::Method</code> resource creates API Gateway methods that define the parameters and body that clients must send in their requests.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-method.html">the AWS Docs</a>
*/
export interface MethodProperties extends KloudResource {
    /** <code>ApiKeyRequired</code>  <a name="cfn-apigateway-method-apikeyrequired"></a>
  Indicates whether the method requires clients to submit a valid API key.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    apiKeyRequired?: Value<boolean>;
    /** <code>AuthorizationScopes</code>  <a name="cfn-apigateway-method-authorizationscopes"></a>
  A list of authorization scopes configured on the method. The scopes are used with a <code>COGNITO_USER_POOLS</code> authorizer to authorize the method invocation. The authorization works by matching the method scopes against the scopes parsed from the access token in the incoming request. The method invocation is authorized if any method scopes match a claimed scope in the access token. Otherwise, the invocation is not authorized. When the method scope is configured, the client must provide an access token instead of an identity token for authorization purposes.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    authorizationScopes?: Value<Value<string>[]>;
    /** <code>AuthorizationType</code>  <a name="cfn-apigateway-method-authorizationtype"></a>
  The method’s authorization type. This parameter is required. For valid values, see <a href="https://docs.aws.amazon.com/apigateway/api-reference/resource/method/">Method</a> in the
  API Gateway API Reference: br />
  If you specify the <code>AuthorizerId</code> property, specify <code>CUSTOM</code> or <code>COGNITO_USER_POOLS</code> for this property.
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    authorizationType?: Value<string>;
    /** <code>AuthorizerId</code>  <a name="cfn-apigateway-method-authorizerid"></a>
  The identifier of the <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-authorizer.html">authorizer</a> to use on this method. If you specify this property, specify <code>CUSTOM</code> or <code>COGNITO_USER_POOLS</code> for the <code>AuthorizationType</code> property.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    authorizerId?: Value<string>;
    /** <code>HttpMethod</code>  <a name="cfn-apigateway-method-httpmethod"></a>
  The HTTP method that clients use to call this method.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    httpMethod: Value<string>;
    /** <code>Integration</code>  <a name="cfn-apigateway-method-integration"></a>
  The backend system that the method calls when it receives a request.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    integration?: IntegrationProps;
    /** <code>MethodResponses</code>  <a name="cfn-apigateway-method-methodresponses"></a>
  The responses that can be sent to the client who calls the method.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    methodResponses?: MethodResponseProps[];
    /** <code>OperationName</code>  <a name="cfn-apigateway-method-operationname"></a>
  A friendly operation name for the method. For example, you can assign the <code>OperationName</code> of <code>ListPets</code> for the <code>GET /pets</code> method.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    operationName?: Value<string>;
    /** <code>RequestModels</code>  <a name="cfn-apigateway-method-requestmodels"></a>
  The resources that are used for the request’s content type. Specify request models as key-value pairs (string-to-string mapping), with a content type as the key and a <code>Model</code> resource name as the value. To use the same model regardless of the content type, specify <code>$default</code> as the key.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    requestModels?: Value<{
        [key: string]: Value<string>;
    }>;
    /** <code>RequestParameters</code>  <a name="cfn-apigateway-method-requestparameters"></a>
  The request parameters that API Gateway accepts. Specify request parameters as key-value pairs (string-to-Boolean mapping), with a source as the key and a Boolean as the value. The Boolean specifies whether a parameter is required. A source must match the format <code>method.request.location.name</code>, where the location is querystring, path, or header, and
  name: s a valid, unique parameter name.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    requestParameters?: Value<{
        [key: string]: Value<boolean>;
    }>;
    /** <code>RequestValidatorId</code>  <a name="cfn-apigateway-method-requestvalidatorid"></a>
  The ID of the associated request validator.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    requestValidatorId?: Value<string>;
    /** <code>ResourceId</code>  <a name="cfn-apigateway-method-resourceid"></a>
  The ID of an API Gateway <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-resource.html">resource</a>. For root resource methods, specify the <code>RestApi</code> root resource ID, such as <code>{ &quot;Fn::GetAtt&quot;: [&quot;MyRestApi&quot;, &quot;RootResourceId&quot;] }</code>.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    resourceId: Value<string>;
    /** <code>RestApiId</code>  <a name="cfn-apigateway-method-restapiid"></a>
  The ID of the <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-restapi.html">RestApi</a> resource in which API Gateway creates the method.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    restApiId: Value<string>;
}
