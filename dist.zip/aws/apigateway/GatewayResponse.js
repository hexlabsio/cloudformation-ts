"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function gatewayResponse(gatewayResponseProps) { return ({ ...gatewayResponseProps, _logicalType: 'AWS::ApiGateway::GatewayResponse' }); }
exports.gatewayResponse = gatewayResponse;
