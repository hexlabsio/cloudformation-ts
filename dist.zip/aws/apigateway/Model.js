"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function model(modelProps) { return ({ ...modelProps, _logicalType: 'AWS::ApiGateway::Model' }); }
exports.model = model;
