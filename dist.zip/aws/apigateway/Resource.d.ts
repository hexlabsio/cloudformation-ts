import { Value } from '../../kloudformation/Value';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGateway::Resource</code> resource creates a resource in an API.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-resource.html">the AWS Docs</a>
*/
export declare type Resource = ResourceProperties;
export declare function resource(resourceProps: ResourceProperties): Resource;
/**
  The <code>AWS::ApiGateway::Resource</code> resource creates a resource in an API.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-resource.html">the AWS Docs</a>
*/
export interface ResourceProperties extends KloudResource {
    /** <code>ParentId</code>  <a name="cfn-apigateway-resource-parentid"></a>
  If you want to create a child resource, the ID of the parent resource. For resources without a parent, specify the <code>RestApi</code> root resource ID, such as <code>{ &quot;Fn::GetAtt&quot;: [&quot;MyRestApi&quot;, &quot;RootResourceId&quot;] }</code>.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    parentId: Value<string>;
    /** <code>PathPart</code>  <a name="cfn-apigateway-resource-pathpart"></a>
  A path name for the resource.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    pathPart: Value<string>;
    /** <code>RestApiId</code>  <a name="cfn-apigateway-resource-restapiid"></a>
  The ID of the <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-restapi.html">RestApi</a> resource in which you want to create this resource.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    restApiId: Value<string>;
}
