"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function requestValidator(requestValidatorProps) { return ({ ...requestValidatorProps, _logicalType: 'AWS::ApiGateway::RequestValidator' }); }
exports.requestValidator = requestValidator;
