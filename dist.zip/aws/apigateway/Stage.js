"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function stage(stageProps) { return ({ ...stageProps, _logicalType: 'AWS::ApiGateway::Stage' }); }
exports.stage = stage;
