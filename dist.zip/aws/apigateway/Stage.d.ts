import { AccessLogSettingProps } from './stage/AccessLogSettingProps';
import { Value } from '../../kloudformation/Value';
import { CanarySettingProps } from './stage/CanarySettingProps';
import { MethodSettingProps } from './stage/MethodSettingProps';
import { Tag } from '../Tag';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGateway::Stage</code> resource creates a stage for a deployment.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-stage.html">the AWS Docs</a>
*/
export declare type Stage = StageProperties;
export declare function stage(stageProps: StageProperties): Stage;
/**
  The <code>AWS::ApiGateway::Stage</code> resource creates a stage for a deployment.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-stage.html">the AWS Docs</a>
*/
export interface StageProperties extends KloudResource {
    /** <code>AccessLogSetting</code>  <a name="cfn-apigateway-stage-accesslogsetting"></a>
  Specifies settings for logging access in this stage.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    accessLogSetting?: AccessLogSettingProps;
    /** <code>CacheClusterEnabled</code>  <a name="cfn-apigateway-stage-cacheclusterenabled"></a>
  Indicates whether cache clustering is enabled for the stage.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    cacheClusterEnabled?: Value<boolean>;
    /** <code>CacheClusterSize</code>  <a name="cfn-apigateway-stage-cacheclustersize"></a>
  The stage’s cache cluster size.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    cacheClusterSize?: Value<string>;
    /** <code>CanarySetting</code>  <a name="cfn-apigateway-stage-canarysetting"></a>
  Specifies settings for the canary deployment in this stage.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    canarySetting?: CanarySettingProps;
    /** <code>ClientCertificateId</code>  <a name="cfn-apigateway-stage-clientcertificateid"></a>
  The ID of the client certificate that API Gateway uses to call your integration endpoints in the stage.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    clientCertificateId?: Value<string>;
    /** <code>DeploymentId</code>  <a name="cfn-apigateway-stage-deploymentid"></a>
  The ID of the deployment that the stage is associated with. This parameter is required to create a stage.<br />
  
  Required: Conditional<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    deploymentId?: Value<string>;
    /** <code>Description</code>  <a name="cfn-apigateway-stage-description"></a>
  A description of the stage.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>DocumentationVersion</code>  <a name="cfn-apigateway-stage-documentationversion"></a>
  The version ID of the API documentation snapshot.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    documentationVersion?: Value<string>;
    /** <code>MethodSettings</code>  <a name="cfn-apigateway-stage-methodsettings"></a>
  Settings for all methods in the stage.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    methodSettings?: MethodSettingProps[];
    /** <code>RestApiId</code>  <a name="cfn-apigateway-stage-restapiid"></a>
  The ID of the <code>RestApi</code> resource that you’re deploying with this stage.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    restApiId: Value<string>;
    /** <code>StageName</code>  <a name="cfn-apigateway-stage-stagename"></a>
  The name of the stage, which API Gateway uses as the first path segment in the invoked Uniform Resource Identifier (URI).<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    stageName?: Value<string>;
    /** <code>Tags</code>  <a name="cfn-apigateway-stage-tags"></a>
  An array of arbitrary tags (key-value pairs) to associate with the stage.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: Tag[];
    /** <code>TracingEnabled</code>  <a name="cfn-apigateway-stage-tracingenabled"></a>
  Specifies whether active X-Ray tracing is enabled for this stage.<br />
  For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-xray.html">Trace API Gateway API Execution with AWS X-Ray</a> in the
  API Gateway Developer Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tracingEnabled?: Value<boolean>;
    /** <code>Variables</code>  <a name="cfn-apigateway-stage-variables"></a>
  A map (string-to-string map) that defines the stage variables, where the variable name is the key and the variable value is the value. Variable names are limited to alphanumeric characters. Values must match the following regular expression: <code>[A-Za-z0-9-._~:/?#&amp;=,]+</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    variables?: Value<{
        [key: string]: Value<string>;
    }>;
}
