import { Value } from '../../kloudformation/Value';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGateway::Model</code> resource defines the structure of a request or response payload for an API method.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-model.html">the AWS Docs</a>
*/
export declare type Model = ModelProperties;
export declare function model(modelProps: ModelProperties): Model;
/**
  The <code>AWS::ApiGateway::Model</code> resource defines the structure of a request or response payload for an API method.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-model.html">the AWS Docs</a>
*/
export interface ModelProperties extends KloudResource {
    /** <code>ContentType</code>  <a name="cfn-apigateway-model-contenttype"></a>
  The content type for the model.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    contentType?: Value<string>;
    /** <code>Description</code>  <a name="cfn-apigateway-model-description"></a>
  A description that identifies this model.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>Name</code>  <a name="cfn-apigateway-model-name"></a>
  A name for the model. If you don’t specify a name, AWS CloudFormation generates a unique physical ID and uses that ID for the model name. For more information, see <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-name.html">Name Type</a>.<br />
  If you specify a name, you cannot perform updates that require replacement of this resource. You can perform updates that require no or some interruption. If you must replace the resource, specify a new name.
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    name?: Value<string>;
    /** <code>RestApiId</code>  <a name="cfn-apigateway-model-restapiid"></a>
  The ID of a REST API with which to associate this model.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    restApiId: Value<string>;
    /** <code>Schema</code>  <a name="cfn-apigateway-model-schema"></a>
  The schema to use to transform data to one or more output formats. Specify null (<code>{}</code>) if you don’t want to specify a schema.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    schema?: Value<any>;
}
