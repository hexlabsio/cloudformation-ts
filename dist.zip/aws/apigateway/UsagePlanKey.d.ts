import { Value } from '../../kloudformation/Value';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGateway::UsagePlanKey</code> resource associates an API key with a usage plan. This association determines which users the usage plan is applied to.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-usageplankey.html">the AWS Docs</a>
*/
export declare type UsagePlanKey = UsagePlanKeyProperties;
export declare function usagePlanKey(usagePlanKeyProps: UsagePlanKeyProperties): UsagePlanKey;
/**
  The <code>AWS::ApiGateway::UsagePlanKey</code> resource associates an API key with a usage plan. This association determines which users the usage plan is applied to.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-usageplankey.html">the AWS Docs</a>
*/
export interface UsagePlanKeyProperties extends KloudResource {
    /** <code>KeyId</code>  <a name="cfn-apigateway-usageplankey-keyid"></a>
  The ID of the usage plan key.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    keyId: Value<string>;
    /** <code>KeyType</code>  <a name="cfn-apigateway-usageplankey-keytype"></a>
  The type of usage plan key. Currently, the only valid key type is <code>API_KEY</code>.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    keyType: Value<string>;
    /** <code>UsagePlanId</code>  <a name="cfn-apigateway-usageplankey-usageplanid"></a>
  The ID of the usage plan.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    usagePlanId: Value<string>;
}
