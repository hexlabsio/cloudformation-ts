"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  The <code>AWS::ApiGateway::DomainName</code> resource specifies a custom domain name for your API in API Gateway.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-domainname.html">the AWS Docs</a>
*/
function domainName(domainNameProps) { return ({ ...domainNameProps, _logicalType: 'AWS::ApiGateway::DomainName', attributes: { DistributionDomainName: 'DistributionDomainName', DistributionHostedZoneId: 'DistributionHostedZoneId', RegionalDomainName: 'RegionalDomainName', RegionalHostedZoneId: 'RegionalHostedZoneId' } }); }
exports.domainName = domainName;
