"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function account(accountProps) { return ({ ...accountProps, _logicalType: 'AWS::ApiGateway::Account' }); }
exports.account = account;
