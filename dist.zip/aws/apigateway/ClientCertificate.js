"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  The <code>AWS::ApiGateway::ClientCertificate</code> resource creates a client certificate that API Gateway uses to configure client-side SSL authentication for sending requests to the integration endpoint.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-clientcertificate.html">the AWS Docs</a>
*/
function clientCertificate(clientCertificateProps) { return ({ ...clientCertificateProps, _logicalType: 'AWS::ApiGateway::ClientCertificate', attributes: { ClientCertificateId: 'ClientCertificateId' } }); }
exports.clientCertificate = clientCertificate;
