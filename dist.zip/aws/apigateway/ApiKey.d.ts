import { Value } from '../../kloudformation/Value';
import { StageKeyProps } from './apikey/StageKeyProps';
import { Tag } from '../Tag';
import { Attribute } from '../../kloudformation/Attribute';
import { KloudResource } from '../../kloudformation/KloudResource';
export declare type ApiKeyAttributes = {
    APIKeyId: Attribute<string>;
};
export declare type ApiKey = ApiKeyProperties & {
    attributes: ApiKeyAttributes;
};
/**
  The <code>AWS::ApiGateway::ApiKey</code> resource creates a unique key that you can distribute to clients who are executing API Gateway <code>Method</code> resources that require an API key. To specify which API key clients must use, map the API key with the <code>RestApi</code> and <code>Stage</code> resources that include the methods that require a key.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-apikey.html">the AWS Docs</a>
*/
export declare function apiKey(apiKeyProps: ApiKeyProperties): ApiKey;
/**
  The <code>AWS::ApiGateway::ApiKey</code> resource creates a unique key that you can distribute to clients who are executing API Gateway <code>Method</code> resources that require an API key. To specify which API key clients must use, map the API key with the <code>RestApi</code> and <code>Stage</code> resources that include the methods that require a key.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-apikey.html">the AWS Docs</a>
*/
export interface ApiKeyProperties extends KloudResource {
    /** <code>CustomerId</code>  <a name="cfn-apigateway-apikey-customerid"></a>
  An AWS Marketplace customer identifier to use when integrating with the AWS SaaS Marketplace.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    customerId?: Value<string>;
    /** <code>Description</code>  <a name="cfn-apigateway-apikey-description"></a>
  A description of the purpose of the API key.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>Enabled</code>  <a name="cfn-apigateway-apikey-enabled"></a>
  Indicates whether the API key can be used by clients.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    enabled?: Value<boolean>;
    /** <code>GenerateDistinctId</code>  <a name="cfn-apigateway-apikey-generatedistinctid"></a>
  Specifies whether the key identifier is distinct from the created API key value. This parameter is deprecated and should not be used.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    generateDistinctId?: Value<boolean>;
    /** <code>Name</code>  <a name="cfn-apigateway-apikey-name"></a>
  A name for the API key. If you don’t specify a name, AWS CloudFormation generates a unique physical ID and uses that ID for the API key name. For more information, see <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-name.html">Name Type</a>.<br />
  If you specify a name, you cannot perform updates that require replacement of this resource. You can perform updates that require no or some interruption. If you must replace the resource, specify a new name.
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    name?: Value<string>;
    /** <code>StageKeys</code>  <a name="cfn-apigateway-apikey-stagekeys"></a>
  A list of stages to associate with this API key.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    stageKeys?: StageKeyProps[];
    /** <code>Tags</code>  <a name="cfn-apigateway-apikey-tags"></a>
  An array of arbitrary tags (key-value pairs) to associate with the API key.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: Tag[];
    /** <code>Value</code>  <a name="cfn-apigateway-apikey-value"></a>
  The value of the API key. Must be at least 20 characters long.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    value?: Value<string>;
}
