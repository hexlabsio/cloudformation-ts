import { Value } from '../../../kloudformation/Value';
/**
  The <code>CanarySetting</code> property type specifies settings for the canary deployment in this stage.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigateway-deployment-canarysetting.html">the AWS Docs</a>
*/
export interface CanarySettingProps {
    /** <code>PercentTraffic</code>  <a name="cfn-apigateway-deployment-canarysetting-percenttraffic"></a>
  The percent (0-100) of traffic diverted to a canary deployment.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    percentTraffic?: Value<number>;
    /** <code>StageVariableOverrides</code>  <a name="cfn-apigateway-deployment-canarysetting-stagevariableoverrides"></a>
  Stage variables overridden for a canary release deployment, including new stage variables introduced in the canary. These stage variables are represented as a string-to-string map between stage variable names and their values.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    stageVariableOverrides?: Value<{
        [key: string]: Value<string>;
    }>;
    /** <code>UseStageCache</code>  <a name="cfn-apigateway-deployment-canarysetting-usestagecache"></a>
  Whether the canary deployment uses the stage cache or not.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    useStageCache?: Value<boolean>;
}
