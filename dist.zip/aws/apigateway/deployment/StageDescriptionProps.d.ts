import { AccessLogSettingProps } from './AccessLogSettingProps';
import { Value } from '../../../kloudformation/Value';
import { CanarySettingProps } from './CanarySettingProps';
import { MethodSettingProps } from './MethodSettingProps';
import { Tag } from '../../Tag';
/**
  <code>StageDescription</code> is a property of the <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-deployment.html">AWS::ApiGateway::Deployment</a> resource that configures a deployment stage.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigateway-deployment-stagedescription.html">the AWS Docs</a>
*/
export interface StageDescriptionProps {
    /** <code>AccessLogSetting</code>  <a name="cfn-apigateway-deployment-stagedescription-accesslogsetting"></a>
  Specifies settings for logging access in this stage.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    accessLogSetting?: AccessLogSettingProps;
    /** <code>CacheClusterEnabled</code>  <a name="cfn-apigateway-deployment-stagedescription-cacheclusterenabled"></a>
  Indicates whether cache clustering is enabled for the stage.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    cacheClusterEnabled?: Value<boolean>;
    /** <code>CacheClusterSize</code>  <a name="cfn-apigateway-deployment-stagedescription-cacheclustersize"></a>
  The size of the stage’s cache cluster.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    cacheClusterSize?: Value<string>;
    /** <code>CacheDataEncrypted</code>  <a name="cfn-apigateway-deployment-stagedescription-cachedataencrypted"></a>
  Indicates whether the cached responses are encrypted.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    cacheDataEncrypted?: Value<boolean>;
    /** <code>CacheTtlInSeconds</code>  <a name="cfn-apigateway-deployment-stagedescription-cachettlinseconds"></a>
  The time-to-live (TTL) period, in seconds, that specifies how long API Gateway caches responses.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    cacheTtlInSeconds?: Value<number>;
    /** <code>CachingEnabled</code>  <a name="cfn-apigateway-deployment-stagedescription-cachingenabled"></a>
  Indicates whether responses are cached and returned for requests. You must enable a cache cluster on the stage to cache responses. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-caching.html">Enable API Gateway Caching in a Stage to Enhance API Performance</a> in the
  API Gateway Developer Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    cachingEnabled?: Value<boolean>;
    /** <code>CanarySetting</code>  <a name="cfn-apigateway-deployment-stagedescription-canarysetting"></a>
  Specifies settings for the canary deployment in this stage.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    canarySetting?: CanarySettingProps;
    /** <code>ClientCertificateId</code>  <a name="cfn-apigateway-deployment-stagedescription-clientcertificateid"></a>
  The identifier of the client certificate that API Gateway uses to call your integration endpoints in the stage.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    clientCertificateId?: Value<string>;
    /** <code>DataTraceEnabled</code>  <a name="cfn-apigateway-deployment-stagedescription-datatraceenabled"></a>
  Indicates whether data trace logging is enabled for methods in the stage. API Gateway pushes these logs to Amazon CloudWatch Logs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    dataTraceEnabled?: Value<boolean>;
    /** <code>Description</code>  <a name="cfn-apigateway-deployment-stagedescription-description"></a>
  A description of the purpose of the stage.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>DocumentationVersion</code>  <a name="cfn-apigateway-deployment-stagedescription-documentationversion"></a>
  The version identifier of the API documentation snapshot.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    documentationVersion?: Value<string>;
    /** <code>LoggingLevel</code>  <a name="cfn-apigateway-deployment-stagedescription-logginglevel"></a>
  The logging level for this method. For valid values, see the <code>loggingLevel</code> property of the <a href="https://docs.aws.amazon.com/apigateway/api-reference/resource/stage/#loggingLevel">Stage</a> resource in the
  Amazon API Gateway API Reference: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    loggingLevel?: Value<string>;
    /** <code>MethodSettings</code>  <a name="cfn-apigateway-deployment-stagedescription-methodsettings"></a>
  Configures settings for all of the stage’s methods.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    methodSettings?: MethodSettingProps[];
    /** <code>MetricsEnabled</code>  <a name="cfn-apigateway-deployment-stagedescription-metricsenabled"></a>
  Indicates whether Amazon CloudWatch metrics are enabled for methods in the stage.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    metricsEnabled?: Value<boolean>;
    /** <code>Tags</code>  <a name="cfn-apigateway-deployment-tags"></a>
  An array of arbitrary tags (key-value pairs) to associate with the stage.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: Tag[];
    /** <code>ThrottlingBurstLimit</code>  <a name="cfn-apigateway-deployment-stagedescription-throttlingburstlimit"></a>
  The number of burst requests per second that API Gateway permits across all APIs, stages, and methods in your AWS account. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-request-throttling.html">Manage API Request Throttling</a> in the
  API Gateway Developer Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    throttlingBurstLimit?: Value<number>;
    /** <code>ThrottlingRateLimit</code>  <a name="cfn-apigateway-deployment-stagedescription-throttlingratelimit"></a>
  The number of steady-state requests per second that API Gateway permits across all APIs, stages, and methods in your AWS account. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-request-throttling.html">Manage API Request Throttling</a> in the
  API Gateway Developer Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    throttlingRateLimit?: Value<number>;
    /** <code>TracingEnabled</code>  <a name="cfn-apigateway-deployment-stagedescription-tracingenabled"></a>
  Specifies whether active tracing with X-ray is enabled for this stage.<br />
  For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-xray.html">Trace API Gateway API Execution with AWS X-Ray</a> in the
  API Gateway Developer Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tracingEnabled?: Value<boolean>;
    /** <code>Variables</code>  <a name="cfn-apigateway-deployment-stagedescription-variables"></a>
  A map that defines the stage variables. Variable names must consist of alphanumeric characters, and the values must match the following regular expression: <code>[A-Za-z0-9-._~:/?#&amp;=,]+</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    variables?: Value<{
        [key: string]: Value<string>;
    }>;
}
