import { Value } from '../../../kloudformation/Value';
/**
  The <code>DeploymentCanarySettings</code> property type specifies settings for the canary deployment.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigateway-deployment-deploymentcanarysettings.html">the AWS Docs</a>
*/
export interface DeploymentCanarySettingsProps {
    /** <code>PercentTraffic</code>  <a name="cfn-apigateway-deployment-deploymentcanarysettings-percenttraffic"></a>
  The percentage (0-100) of traffic diverted to a canary deployment.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    percentTraffic?: Value<number>;
    /** <code>StageVariableOverrides</code>  <a name="cfn-apigateway-deployment-deploymentcanarysettings-stagevariableoverrides"></a>
  Stage variables overridden for a canary release deployment, including new stage variables introduced in the canary. These stage variables are represented as a string-to-string map between stage variable names and their values.<br />
  Duplicates are not allowed.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    stageVariableOverrides?: Value<{
        [key: string]: Value<string>;
    }>;
    /** <code>UseStageCache</code>  <a name="cfn-apigateway-deployment-deploymentcanarysettings-usestagecache"></a>
  Whether the canary deployment uses the stage cache.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    useStageCache?: Value<boolean>;
}
