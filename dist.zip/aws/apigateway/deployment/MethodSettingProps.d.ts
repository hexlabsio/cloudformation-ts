import { Value } from '../../../kloudformation/Value';
/**
  The <code>MethodSetting</code> property type configures settings for all methods in a stage.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigateway-deployment-stagedescription-methodsetting.html">the AWS Docs</a>
*/
export interface MethodSettingProps {
    /** <code>CacheDataEncrypted</code>  <a name="cfn-apigateway-deployment-stagedescription-methodsetting-cachedataencrypted"></a>
  Indicates whether the cached responses are encrypted.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    cacheDataEncrypted?: Value<boolean>;
    /** <code>CacheTtlInSeconds</code>  <a name="cfn-apigateway-deployment-stagedescription-methodsetting-cachettlinseconds"></a>
  The time-to-live (TTL) period, in seconds, that specifies how long API Gateway caches responses.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    cacheTtlInSeconds?: Value<number>;
    /** <code>CachingEnabled</code>  <a name="cfn-apigateway-deployment-stagedescription-methodsetting-cachingenabled"></a>
  Indicates whether responses are cached and returned for requests. You must enable a cache cluster on the stage to cache responses. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-caching.html">Enable API Gateway Caching in a Stage to Enhance API Performance</a> in the
  API Gateway Developer Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    cachingEnabled?: Value<boolean>;
    /** <code>DataTraceEnabled</code>  <a name="cfn-apigateway-deployment-stagedescription-methodsetting-datatraceenabled"></a>
  Indicates whether data trace logging is enabled for methods in the stage. API Gateway pushes these logs to Amazon CloudWatch Logs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    dataTraceEnabled?: Value<boolean>;
    /** <code>HttpMethod</code>  <a name="cfn-apigateway-deployment-stagedescription-methodsetting-httpmethod"></a>
  The HTTP method.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    httpMethod?: Value<string>;
    /** <code>LoggingLevel</code>  <a name="cfn-apigateway-deployment-stagedescription-methodsetting-logginglevel"></a>
  The logging level for this method. For valid values, see the <code>loggingLevel</code> property of the <a href="https://docs.aws.amazon.com/apigateway/api-reference/resource/stage/#loggingLevel">Stage</a> resource in the
  Amazon API Gateway API Reference: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    loggingLevel?: Value<string>;
    /** <code>MetricsEnabled</code>  <a name="cfn-apigateway-deployment-stagedescription-methodsetting-metricsenabled"></a>
  Indicates whether Amazon CloudWatch metrics are enabled for methods in the stage.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    metricsEnabled?: Value<boolean>;
    /** <code>ResourcePath</code>  <a name="cfn-apigateway-deployment-stagedescription-methodsetting-resourcepath"></a>
  The resource path for this method. Forward slashes (<code>/</code>) are encoded as <code>~1</code> and the initial slash must include a forward slash. For example, the path value <code>/resource/subresource</code> must be encoded as <code>/~1resource~1subresource</code>. To specify the root path, use only a slash (<code>/</code>).<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    resourcePath?: Value<string>;
    /** <code>ThrottlingBurstLimit</code>  <a name="cfn-apigateway-deployment-stagedescription-methodsetting-throttlingburstlimit"></a>
  The number of burst requests per second that API Gateway permits across all APIs, stages, and methods in your AWS account. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-request-throttling.html">Manage API Request Throttling</a> in the
  API Gateway Developer Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    throttlingBurstLimit?: Value<number>;
    /** <code>ThrottlingRateLimit</code>  <a name="cfn-apigateway-deployment-stagedescription-methodsetting-throttlingratelimit"></a>
  The number of steady-state requests per second that API Gateway permits across all APIs, stages, and methods in your AWS account. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-request-throttling.html">Manage API Request Throttling</a> in the
  API Gateway Developer Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    throttlingRateLimit?: Value<number>;
}
