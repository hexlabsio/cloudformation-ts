import { Value } from '../../../kloudformation/Value';
/**
  The <code>AccessLogSetting</code> property type specifies settings for logging access in this stage.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigateway-deployment-accesslogsetting.html">the AWS Docs</a>
*/
export interface AccessLogSettingProps {
    /** <code>DestinationArn</code>  <a name="cfn-apigateway-deployment-accesslogsetting-destinationarn"></a>
  The Amazon Resource Name (ARN) of the CloudWatch Logs log group or Kinesis Data Firehose delivery stream to receive access logs. If you specify a Kinesis Data Firehose delivery stream, the stream name must begin with <code>amazon-apigateway-</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    destinationArn?: Value<string>;
    /** <code>Format</code>  <a name="cfn-apigateway-deployment-accesslogsetting-format"></a>
  A single line format of the access logs of data, as specified by selected <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-mapping-template-reference.html#context-variable-reference">$context variables</a>. The format must include at least <code>$context.requestId</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    format?: Value<string>;
}
