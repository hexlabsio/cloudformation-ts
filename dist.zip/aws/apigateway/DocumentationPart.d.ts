import { LocationProps } from './documentationpart/LocationProps';
import { Value } from '../../kloudformation/Value';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGateway::DocumentationPart</code> resource creates a documentation part for an API. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-documenting-api-content-representation.html">Representation of API Documentation in API Gateway</a> in the <em>API Gateway Developer Guide</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-documentationpart.html">the AWS Docs</a>
*/
export declare type DocumentationPart = DocumentationPartProperties;
export declare function documentationPart(documentationPartProps: DocumentationPartProperties): DocumentationPart;
/**
  The <code>AWS::ApiGateway::DocumentationPart</code> resource creates a documentation part for an API. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-documenting-api-content-representation.html">Representation of API Documentation in API Gateway</a> in the <em>API Gateway Developer Guide</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-documentationpart.html">the AWS Docs</a>
*/
export interface DocumentationPartProperties extends KloudResource {
    /** <code>Location</code>  <a name="cfn-apigateway-documentationpart-location"></a>
  The location of the API entity that the documentation applies to.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    location: LocationProps;
    /** <code>Properties</code>  <a name="cfn-apigateway-documentationpart-properties"></a>
  The documentation content map of the targeted API entity.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    properties: Value<string>;
    /** <code>RestApiId</code>  <a name="cfn-apigateway-documentationpart-restapiid"></a>
  The identifier of the targeted API entity.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    restApiId: Value<string>;
}
