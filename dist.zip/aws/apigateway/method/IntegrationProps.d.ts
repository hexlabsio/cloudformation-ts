import { Value } from '../../../kloudformation/Value';
import { IntegrationResponseProps } from './IntegrationResponseProps';
/**
  <code>Integration</code> is a property of the <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-method.html">AWS::ApiGateway::Method</a> resource that specifies information about the target backend that a method calls.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apitgateway-method-integration.html">the AWS Docs</a>
*/
export interface IntegrationProps {
    /** <code>CacheKeyParameters</code>  <a name="cfn-apigateway-method-integration-cachekeyparameters"></a>
  A list of request parameters whose values API Gateway caches. For cases where the integration type allows for RequestParameters to be set, these parameters must also be specified in <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-method.html#cfn-apigateway-method-requestparameters">RequestParameters</a> to be supported in <code>CacheKeyParameters</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    cacheKeyParameters?: Value<Value<string>[]>;
    /** <code>CacheNamespace</code>  <a name="cfn-apigateway-method-integration-cachenamespace"></a>
  An API-specific tag group of related cached parameters.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    cacheNamespace?: Value<string>;
    /** <code>ConnectionId</code>  <a name="cfn-apigateway-method-integration-connectionid"></a>
  The ID of the <code>VpcLink</code> used for the integration when <code>connectionType=VPC_LINK</code>, otherwise undefined.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    connectionId?: Value<string>;
    /** <code>ConnectionType</code>  <a name="cfn-apigateway-method-integration-connectiontype"></a>
  The type of the network connection to the integration endpoint. The valid value is <code>INTERNET</code> for connections through the public routable internet or <code>VPC_LINK</code> for private connections between API Gateway and a network load balancer in a VPC. The default value is <code>INTERNET</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    connectionType?: Value<string>;
    /** <p> */
    contentHandling?: Value<string>;
    /** <code>Credentials</code>  <a name="cfn-apigateway-method-integration-credentials"></a>
  The credentials that are required for the integration. To specify an AWS Identity and Access Management (IAM) role that API Gateway assumes, specify the role’s Amazon Resource Name (ARN). To require that the caller’s identity be passed through from the request, specify arn:aws:iam::*:user/*.<br />
  To use resource-based permissions on the AWS Lambda (Lambda) function, don’t specify this property. Use the <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-lambda-permission.html">AWS::Lambda::Permission</a> resource to permit API Gateway to call the function. For more information, see <a href="https://docs.aws.amazon.com/lambda/latest/dg/access-control-resource-based.html#access-control-resource-based-example-apigateway-invoke-function">Allow Amazon API Gateway to Invoke a Lambda Function</a> in the
  AWS Lambda Developer Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    credentials?: Value<string>;
    /** <code>IntegrationHttpMethod</code>  <a name="cfn-apigateway-method-integration-integrationhttpmethod"></a>
  The integration’s HTTP method type.<br />
  For the <code>Type</code> property, if you specify <code>MOCK</code>, this property is optional. For all other types, you must specify this property.<br />
  
  Required: Conditional<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    integrationHttpMethod?: Value<string>;
    /** <code>IntegrationResponses</code>  <a name="cfn-apigateway-method-integration-integrationresponses"></a>
  The response that API Gateway provides after a method’s backend completes processing a request. API Gateway intercepts the response from the backend so that you can control how API Gateway surfaces backend responses. For example, you can map the backend status codes to codes that you define.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    integrationResponses?: IntegrationResponseProps[];
    /** <code>PassthroughBehavior</code>  <a name="cfn-apigateway-method-integration-passthroughbehavior"></a>
  Indicates when API Gateway passes requests to the targeted backend. This behavior depends on the request’s <code>Content-Type</code> header and whether you defined a mapping template for it.<br />
  For more information and valid values, see the <a href="https://docs.aws.amazon.com/apigateway/api-reference/link-relation/integration-put/#passthroughBehavior">passthroughBehavior</a> field in the
  API Gateway API Reference: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    passthroughBehavior?: Value<string>;
    /** <code>RequestParameters</code>  <a name="cfn-apigateway-method-integration-requestparameters"></a>
  The request parameters that API Gateway sends with the backend request. Specify request parameters as key-value pairs (string-to-string mappings), with a destination as the key and a source as the value.<br />
  Specify the destination by using the following pattern <code>integration.request.location.name</code>, where
  location: s query string, path, or header, and
  name: s a valid, unique parameter name.<br />
  The source must be an existing method request parameter or a static value. You must enclose static values in single quotation marks and pre-encode these values based on their destination in the request.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    requestParameters?: Value<{
        [key: string]: Value<string>;
    }>;
    /** <code>RequestTemplates</code>  <a name="cfn-apigateway-method-integration-requesttemplates"></a>
  A map of Apache Velocity templates that are applied on the request payload. The template that API Gateway uses is based on the value of the <code>Content-Type</code> header that’s sent by the client. The content type value is the key, and the template is the value (specified as a string), such as the following snippet:<br />
  <code>&quot;application/json&quot;: &quot;{\n \&quot;statusCode\&quot;: 200\n}&quot;</code><br />
  For more information about templates, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-mapping-template-reference.html">API Gateway Mapping Template and Access Logging Variable Reference</a> in the
  API Gateway Developer Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    requestTemplates?: Value<{
        [key: string]: Value<string>;
    }>;
    /** <code>TimeoutInMillis</code>  <a name="cfn-apigateway-method-integration-timeoutinmillis"></a>
  Custom timeout between 50 and 29,000 milliseconds. The default value is 29,000 milliseconds or 29 seconds.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    timeoutInMillis?: Value<number>;
    /** <code>Type</code>  <a name="cfn-apigateway-method-integration-type"></a>
  The type of backend that your method is running, such as <code>HTTP</code> or <code>MOCK</code>. For all of the valid values, see the <a href="https://docs.aws.amazon.com/apigateway/api-reference/resource/integration/#type">type</a> property for the <code>Integration</code> resource in the
  Amazon API Gateway REST API Reference: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    type?: Value<string>;
    /** <code>Uri</code>  <a name="cfn-apigateway-method-integration-uri"></a>
  The Uniform Resource Identifier (URI) for the integration.<br />
  If you specify <code>HTTP</code> for the <code>Type</code> property, specify the API endpoint URL.<br />
  If you specify <code>MOCK</code> for the <code>Type</code> property, don’t specify this property.<br />
  If you specify <code>AWS</code> for the <code>Type</code> property, specify an AWS service that follows this form: arn:aws:apigateway:
  region: ambda:path/
  subdomain: <
  service|service: <
  path|action: <
  service_api: For example, a Lambda function URI follows this form: arn:aws:apigateway:
  path: The path is usually in the form /2015-03-31/functions/
  LambdaFunctionARN: nvocations. For more information, see the <code>uri</code> property of the <a href="https://docs.aws.amazon.com/apigateway/api-reference/resource/integration/">Integration</a> resource in the Amazon API Gateway REST API Reference.<br />
  If you specified <code>HTTP</code> or <code>AWS</code> for the <code>Type</code> property, you must specify this property.<br />
  
  Required: Conditional<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    uri?: Value<string>;
}
