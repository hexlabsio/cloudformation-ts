import { Value } from '../../../kloudformation/Value';
/**
  <code>IntegrationResponse</code> is a property of the <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apitgateway-method-integration.html">Amazon API Gateway Method Integration</a> property type that specifies the response that API Gateway sends after a method’s backend finishes processing a request.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apitgateway-method-integration-integrationresponse.html">the AWS Docs</a>
*/
export interface IntegrationResponseProps {
    /** <p> */
    contentHandling?: Value<string>;
    /** <p> */
    responseParameters?: Value<{
        [key: string]: Value<string>;
    }>;
    /** <code>ResponseTemplates</code>  <a name="cfn-apigateway-method-integration-integrationresponse-responsetemplates"></a>
  The templates that are used to transform the integration response body. Specify templates as key-value pairs (string-to-string mappings), with a content type as the key and a template as the value. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-mapping-template-reference.html">API Gateway Mapping Template and Access Logging Variable Reference</a> in the
  API Gateway Developer Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    responseTemplates?: Value<{
        [key: string]: Value<string>;
    }>;
    /** <code>SelectionPattern</code>  <a name="cfn-apigateway-method-integration-integrationresponse-selectionpattern"></a>
  A <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/cfn-regexes.html">regular expression</a> that specifies which error strings or status codes from the backend map to the integration response.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    selectionPattern?: Value<string>;
    /** <code>StatusCode</code>  <a name="cfn-apigateway-method-integration-integrationresponse-statuscode"></a>
  The status code that API Gateway uses to map the integration response to a <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apitgateway-method-methodresponse.html">MethodResponse</a> status code.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    statusCode: Value<string>;
}
