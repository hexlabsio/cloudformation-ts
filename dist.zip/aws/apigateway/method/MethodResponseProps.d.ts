import { Value } from '../../../kloudformation/Value';
/**
  <code>MethodResponse</code> is a property of the <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-method.html">AWS::ApiGateway::Method</a> resource that defines the responses that can be sent to the client that calls a method.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apitgateway-method-methodresponse.html">the AWS Docs</a>
*/
export interface MethodResponseProps {
    /** <code>ResponseModels</code>  <a name="cfn-apigateway-method-methodresponse-responsemodels"></a>
  The resources used for the response’s content type. Specify response models as key-value pairs (string-to-string maps), with a content type as the key and a <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-model.html">Model</a> resource name as the value.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    responseModels?: Value<{
        [key: string]: Value<string>;
    }>;
    /** <code>ResponseParameters</code>  <a name="cfn-apigateway-method-methodresponse-responseparameters"></a>
  Response parameters that API Gateway sends to the client that called a method. Specify response parameters as key-value pairs (string-to-Boolean maps), with a destination as the key and a Boolean as the value. Specify the destination using the following pattern: <code>method.response.header.name</code>, where
  name: s a valid, unique header name. The Boolean specifies whether a parameter is required.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    responseParameters?: Value<{
        [key: string]: Value<boolean>;
    }>;
    /** <code>StatusCode</code>  <a name="cfn-apigateway-method-methodresponse-statuscode"></a>
  The method response’s status code, which you map to an <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apitgateway-method-integration-integrationresponse.html">IntegrationResponse</a>.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    statusCode: Value<string>;
}
