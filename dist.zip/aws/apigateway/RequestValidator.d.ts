import { Value } from '../../kloudformation/Value';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGateway::RequestValidator</code> resource sets up basic validation rules for incoming requests to your API. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-method-request-validation.html">Enable Basic Request Validation for an API in API Gateway</a> in the <em>API Gateway Developer Guide</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-requestvalidator.html">the AWS Docs</a>
*/
export declare type RequestValidator = RequestValidatorProperties;
export declare function requestValidator(requestValidatorProps: RequestValidatorProperties): RequestValidator;
/**
  The <code>AWS::ApiGateway::RequestValidator</code> resource sets up basic validation rules for incoming requests to your API. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-method-request-validation.html">Enable Basic Request Validation for an API in API Gateway</a> in the <em>API Gateway Developer Guide</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-requestvalidator.html">the AWS Docs</a>
*/
export interface RequestValidatorProperties extends KloudResource {
    /** <code>Name</code>  <a name="cfn-apigateway-requestvalidator-name"></a>
  The name of this request validator.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    name?: Value<string>;
    /** <code>RestApiId</code>  <a name="cfn-apigateway-requestvalidator-restapiid"></a>
  The identifier of the targeted API entity.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    restApiId: Value<string>;
    /** <code>ValidateRequestBody</code>  <a name="cfn-apigateway-requestvalidator-validaterequestbody"></a>
  Indicates whether to validate the request body according to the configured schema for the targeted API and method.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    validateRequestBody?: Value<boolean>;
    /** <code>ValidateRequestParameters</code>  <a name="cfn-apigateway-requestvalidator-validaterequestparameters"></a>
  Indicates whether to validate request parameters.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    validateRequestParameters?: Value<boolean>;
}
