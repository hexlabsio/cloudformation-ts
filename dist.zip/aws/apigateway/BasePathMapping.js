"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function basePathMapping(basePathMappingProps) { return ({ ...basePathMappingProps, _logicalType: 'AWS::ApiGateway::BasePathMapping' }); }
exports.basePathMapping = basePathMapping;
