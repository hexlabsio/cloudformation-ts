import { Value } from '../../kloudformation/Value';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGateway::Account</code> resource specifies the IAM role that Amazon API Gateway uses to write API logs to Amazon CloudWatch Logs.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-account.html">the AWS Docs</a>
*/
export declare type Account = AccountProperties;
export declare function account(accountProps: AccountProperties): Account;
/**
  The <code>AWS::ApiGateway::Account</code> resource specifies the IAM role that Amazon API Gateway uses to write API logs to Amazon CloudWatch Logs.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-account.html">the AWS Docs</a>
*/
export interface AccountProperties extends KloudResource {
    /** <code>CloudWatchRoleArn</code>  <a name="cfn-apigateway-account-cloudwatchrolearn"></a>
  The Amazon Resource Name (ARN) of an IAM role that has write access to CloudWatch Logs in your account.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    cloudWatchRoleArn?: Value<string>;
}
