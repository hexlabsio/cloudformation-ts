"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  The <code>AWS::ApiGateway::RestApi</code> resource creates a REST API. For more information, see <a href="https://docs.aws.amazon.com/apigateway/api-reference/link-relation/restapi-create/">restapi:create</a> in the <em>Amazon API Gateway REST API Reference</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-restapi.html">the AWS Docs</a>
*/
function restApi(restApiProps) { return ({ ...restApiProps, _logicalType: 'AWS::ApiGateway::RestApi', attributes: { RootResourceId: 'RootResourceId' } }); }
exports.restApi = restApi;
