import { Value } from '../../kloudformation/Value';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGateway::GatewayResponse</code> resource creates a gateway response for your API. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/customize-gateway-responses.html#api-gateway-gatewayResponse-definition">API Gateway Responses</a> in the <em>API Gateway Developer Guide</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-gatewayresponse.html">the AWS Docs</a>
*/
export declare type GatewayResponse = GatewayResponseProperties;
export declare function gatewayResponse(gatewayResponseProps: GatewayResponseProperties): GatewayResponse;
/**
  The <code>AWS::ApiGateway::GatewayResponse</code> resource creates a gateway response for your API. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/customize-gateway-responses.html#api-gateway-gatewayResponse-definition">API Gateway Responses</a> in the <em>API Gateway Developer Guide</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-gatewayresponse.html">the AWS Docs</a>
*/
export interface GatewayResponseProperties extends KloudResource {
    /** <code>ResponseParameters</code>  <a name="cfn-apigateway-gatewayresponse-responseparameters"></a>
  The response parameters (paths, query strings, and headers) for the response. Duplicates not allowed.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    responseParameters?: Value<{
        [key: string]: Value<string>;
    }>;
    /** <code>ResponseTemplates</code>  <a name="cfn-apigateway-gatewayresponse-responsetemplates"></a>
  The response templates for the response. Duplicates not allowed.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    responseTemplates?: Value<{
        [key: string]: Value<string>;
    }>;
    /** <code>ResponseType</code>  <a name="cfn-apigateway-gatewayresponse-responsetype"></a>
  The response type. For valid values, see <a href="https://docs.aws.amazon.com/apigateway/api-reference/resource/gateway-response/">GatewayResponse</a> in the
  API Gateway API Reference: br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    responseType: Value<string>;
    /** <code>RestApiId</code>  <a name="cfn-apigateway-gatewayresponse-restapiid"></a>
  The identifier of the API.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    restApiId: Value<string>;
    /** <code>StatusCode</code>  <a name="cfn-apigateway-gatewayresponse-statuscode"></a>
  The HTTP status code for the response.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    statusCode?: Value<string>;
}
