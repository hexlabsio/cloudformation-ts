import { DeploymentCanarySettingsProps } from './deployment/DeploymentCanarySettingsProps';
import { Value } from '../../kloudformation/Value';
import { StageDescriptionProps } from './deployment/StageDescriptionProps';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGateway::Deployment</code> resource deploys an API Gateway <code>RestApi</code> resource to a stage so that clients can call the API over the internet. The stage acts as an environment.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-deployment.html">the AWS Docs</a>
*/
export declare type Deployment = DeploymentProperties;
export declare function deployment(deploymentProps: DeploymentProperties): Deployment;
/**
  The <code>AWS::ApiGateway::Deployment</code> resource deploys an API Gateway <code>RestApi</code> resource to a stage so that clients can call the API over the internet. The stage acts as an environment.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-deployment.html">the AWS Docs</a>
*/
export interface DeploymentProperties extends KloudResource {
    /** <code>DeploymentCanarySettings</code>  <a name="cfn-apigateway-deployment-deploymentcanarysettings"></a>
  Specifies settings for the canary deployment.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    deploymentCanarySettings?: DeploymentCanarySettingsProps;
    /** <code>Description</code>  <a name="cfn-apigateway-deployment-description"></a>
  A description of the purpose of the API Gateway deployment.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>RestApiId</code>  <a name="cfn-apigateway-deployment-restapiid"></a>
  The ID of the <code>RestApi</code> resource to deploy.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    restApiId: Value<string>;
    /** <code>StageDescription</code>  <a name="cfn-apigateway-deployment-stagedescription"></a>
  Configures the stage that API Gateway creates with this deployment.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    stageDescription?: StageDescriptionProps;
    /** <code>StageName</code>  <a name="cfn-apigateway-deployment-stagename"></a>
  A name for the stage that API Gateway creates with this deployment. Use only alphanumeric characters.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    stageName?: Value<string>;
}
