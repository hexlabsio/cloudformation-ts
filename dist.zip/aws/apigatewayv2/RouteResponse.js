"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function routeResponse(routeResponseProps) { return ({ ...routeResponseProps, _logicalType: 'AWS::ApiGatewayV2::RouteResponse' }); }
exports.routeResponse = routeResponse;
