"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function deployment(deploymentProps) { return ({ ...deploymentProps, _logicalType: 'AWS::ApiGatewayV2::Deployment' }); }
exports.deployment = deployment;
