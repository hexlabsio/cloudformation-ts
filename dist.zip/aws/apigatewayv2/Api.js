"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  The <code>AWS::ApiGatewayV2::Api</code> resource creates an API. WebSocket APIs and HTTP APIs are supported. For more information about WebSocket APIs, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-websocket-api-overview.html">About WebSocket APIs in API Gateway</a> in the <em>API Gateway Developer Guide</em>. For more information about HTTP APIs, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api.html">HTTP APIs</a> in the <em>API Gateway Developer Guide.</em>
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html">the AWS Docs</a>
*/
function api(apiProps) { return ({ ...apiProps, _logicalType: 'AWS::ApiGatewayV2::Api', attributes: { ApiEndpoint: 'ApiEndpoint' } }); }
exports.api = api;
