import { Value } from '../../kloudformation/Value';
import { JWTConfigurationProps } from './authorizer/JWTConfigurationProps';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGatewayV2::Authorizer</code> resource creates an authorizer for a WebSocket API or an HTTP API. To learn more, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-websocket-api-control-access.html">Controlling and managing access to a WebSocket API in API Gateway</a> and <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-access-control.html">Controlling and managing access to an HTTP API in API Gateway</a> in the <em>API Gateway Developer Guide</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html">the AWS Docs</a>
*/
export declare type Authorizer = AuthorizerProperties;
export declare function authorizer(authorizerProps: AuthorizerProperties): Authorizer;
/**
  The <code>AWS::ApiGatewayV2::Authorizer</code> resource creates an authorizer for a WebSocket API or an HTTP API. To learn more, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-websocket-api-control-access.html">Controlling and managing access to a WebSocket API in API Gateway</a> and <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-access-control.html">Controlling and managing access to an HTTP API in API Gateway</a> in the <em>API Gateway Developer Guide</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html">the AWS Docs</a>
*/
export interface AuthorizerProperties extends KloudResource {
    /** <code>IdentityValidationExpression</code>  <a name="cfn-apigatewayv2-authorizer-identityvalidationexpression"></a>
  This parameter is not used.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    identityValidationExpression?: Value<string>;
    /** <code>AuthorizerUri</code>  <a name="cfn-apigatewayv2-authorizer-authorizeruri"></a>
  The authorizer’s Uniform Resource Identifier (URI). For <code>REQUEST</code> authorizers, this must be a well-formed Lambda function URI, for example, <code>arn:aws:apigateway:us-west-2:lambda:path/2015-03-31/functions/arn:aws:lambda:us-west-2:{account_id}:function:{lambda_function_name}/invocations</code>. In general, the URI has this form: <code>arn:aws:apigateway:{region}:lambda:path/{service_api} </code>, where
  {region}: s the same as the region hosting the Lambda function, path indicates that the remaining substring in the URI should be treated as the path to the resource, including the initial <code>/</code>. For Lambda functions, this is usually of the form <code>/2015-03-31/functions/[FunctionARN]/invocations</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    authorizerUri?: Value<string>;
    /** <code>AuthorizerCredentialsArn</code>  <a name="cfn-apigatewayv2-authorizer-authorizercredentialsarn"></a>
  Specifies the required credentials as an IAM role for API Gateway to invoke the authorizer. To specify an IAM role for API Gateway to assume, use the role’s Amazon Resource Name (ARN). To use resource-based permissions on the Lambda function, specify null. Supported only for <code>REQUEST</code> authorizers.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    authorizerCredentialsArn?: Value<string>;
    /** <code>AuthorizerType</code>  <a name="cfn-apigatewayv2-authorizer-authorizertype"></a>
  The authorizer type. Specify <code>REQUEST</code> for a Lambda function using incoming request parameters. Specify <code>JWT</code> to use JSON Web Tokens (supported only for HTTP APIs).<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    authorizerType: Value<string>;
    /** <code>JwtConfiguration</code>  <a name="cfn-apigatewayv2-authorizer-jwtconfiguration"></a>
  The <code>JWTConfiguration</code> property specifies the configuration of a JWT authorizer. Required for the <code>JWT</code> authorizer type. Supported only for HTTP APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    jwtConfiguration?: JWTConfigurationProps;
    /** <code>AuthorizerResultTtlInSeconds</code>  <a name="cfn-apigatewayv2-authorizer-authorizerresultttlinseconds"></a>
  The time to live (TTL) for cached authorizer results, in seconds. If it equals 0, authorization caching is disabled. If it is greater than 0, API Gateway caches authorizer responses. The maximum value is 3600, or 1 hour. Supported only for HTTP API Lambda authorizers.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    authorizerResultTtlInSeconds?: Value<number>;
    /** <code>IdentitySource</code>  <a name="cfn-apigatewayv2-authorizer-identitysource"></a>
  The identity source for which authorization is requested.<br />
  For a <code>REQUEST</code> authorizer, this is optional. The value is a set of one or more mapping expressions of the specified request parameters. The identity source can be headers, query string parameters, stage variables, and context parameters. For example, if an Auth header and a Name query string parameter are defined as identity sources, this value is route.request.header.Auth, route.request.querystring.Name for WebSocket APIs. For HTTP APIs, use selection expressions prefixed with <code>$</code>, for example, <code>$request.header.Auth</code>, <code>$request.querystring.Name</code>. These parameters are used to perform runtime validation for Lambda-based authorizers by verifying all of the identity-related request parameters are present in the request, not null, and non-empty. Only when this is true does the authorizer invoke the authorizer Lambda function. Otherwise, it returns a 401 Unauthorized response without calling the Lambda function. For HTTP APIs, identity sources are also used as the cache key when caching is enabled. To learn more, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-lambda-authorizer.html">Working with AWS Lambda authorizers for HTTP APIs</a>.<br />
  For <code>JWT</code>, a single entry that specifies where to extract the JSON Web Token (JWT) from inbound requests. Currently only header-based and query parameter-based selections are supported, for example <code>$request.header.Authorization</code>.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    identitySource: Value<Value<string>[]>;
    /** <code>AuthorizerPayloadFormatVersion</code>  <a name="cfn-apigatewayv2-authorizer-authorizerpayloadformatversion"></a>
  Specifies the format of the payload sent to an HTTP API Lambda authorizer. Required for HTTP API Lambda authorizers. Supported values are <code>1.0</code> and <code>2.0</code>. To learn more, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-lambda-authorizer.html">Working with AWS Lambda authorizers for HTTP APIs</a>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    authorizerPayloadFormatVersion?: Value<string>;
    /** <code>EnableSimpleResponses</code>  <a name="cfn-apigatewayv2-authorizer-enablesimpleresponses"></a>
  Specifies whether a Lambda authorizer returns a response in a simple format. By default, a Lambda authorizer must return an IAM policy. If enabled, the Lambda authorizer can return a boolean value instead of an IAM policy. Supported only for HTTP APIs. To learn more, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-lambda-authorizer.html">Working with AWS Lambda authorizers for HTTP APIs</a>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    enableSimpleResponses?: Value<boolean>;
    /** <code>ApiId</code>  <a name="cfn-apigatewayv2-authorizer-apiid"></a>
  The API identifier.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    apiId: Value<string>;
    /** <code>Name</code>  <a name="cfn-apigatewayv2-authorizer-name"></a>
  The name of the authorizer.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    name: Value<string>;
}
