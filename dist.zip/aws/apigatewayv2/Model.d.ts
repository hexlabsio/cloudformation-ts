import { Value } from '../../kloudformation/Value';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGatewayV2::Model</code> resource updates data model for a WebSocket API. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-websocket-api-selection-expressions.html#apigateway-websocket-api-model-selection-expressions">Model Selection Expressions</a> in the <em>API Gateway Developer Guide</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-model.html">the AWS Docs</a>
*/
export declare type Model = ModelProperties;
export declare function model(modelProps: ModelProperties): Model;
/**
  The <code>AWS::ApiGatewayV2::Model</code> resource updates data model for a WebSocket API. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-websocket-api-selection-expressions.html#apigateway-websocket-api-model-selection-expressions">Model Selection Expressions</a> in the <em>API Gateway Developer Guide</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-model.html">the AWS Docs</a>
*/
export interface ModelProperties extends KloudResource {
    /** <code>Description</code>  <a name="cfn-apigatewayv2-model-description"></a>
  The description of the model.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>ContentType</code>  <a name="cfn-apigatewayv2-model-contenttype"></a>
  The content-type for the model, for example, “application/json”.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    contentType?: Value<string>;
    /** <code>Schema</code>  <a name="cfn-apigatewayv2-model-schema"></a>
  The schema for the model. For application/json models, this should be JSON schema draft 4 model.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    schema: Value<any>;
    /** <code>ApiId</code>  <a name="cfn-apigatewayv2-model-apiid"></a>
  The API identifier.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    apiId: Value<string>;
    /** <code>Name</code>  <a name="cfn-apigatewayv2-model-name"></a>
  The name of the model.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    name: Value<string>;
}
