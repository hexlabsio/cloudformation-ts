"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function model(modelProps) { return ({ ...modelProps, _logicalType: 'AWS::ApiGatewayV2::Model' }); }
exports.model = model;
