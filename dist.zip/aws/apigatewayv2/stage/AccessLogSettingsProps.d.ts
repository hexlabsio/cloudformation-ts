import { Value } from '../../../kloudformation/Value';
/**
  Settings for logging access in a stage.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-stage-accesslogsettings.html">the AWS Docs</a>
*/
export interface AccessLogSettingsProps {
    /** <code>Format</code>  <a name="cfn-apigatewayv2-stage-accesslogsettings-format"></a>
  A single line format of the access logs of data, as specified by selected $context variables. The format must include at least $context.requestId. This parameter is required to enable access logging.<br />
  
  Required: Conditional<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    format?: Value<string>;
    /** <code>DestinationArn</code>  <a name="cfn-apigatewayv2-stage-accesslogsettings-destinationarn"></a>
  The ARN of the CloudWatch Logs log group to receive access logs. This parameter is required to enable access logging.<br />
  
  Required: Conditional<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    destinationArn?: Value<string>;
}
