import { Value } from '../../../kloudformation/Value';
/**
  Represents a collection of route settings.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-stage-routesettings.html">the AWS Docs</a>
*/
export interface RouteSettingsProps {
    /** <code>LoggingLevel</code>  <a name="cfn-apigatewayv2-stage-routesettings-logginglevel"></a>
  Specifies the logging level for this route: <code>INFO</code>, <code>ERROR</code>, or <code>OFF</code>. This property affects the log entries pushed to Amazon CloudWatch Logs. Supported only for WebSocket APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    loggingLevel?: Value<string>;
    /** <code>DataTraceEnabled</code>  <a name="cfn-apigatewayv2-stage-routesettings-datatraceenabled"></a>
  Specifies whether (<code>true</code>) or not (<code>false</code>) data trace logging is enabled for this route. This property affects the log entries pushed to Amazon CloudWatch Logs. Supported only for WebSocket APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    dataTraceEnabled?: Value<boolean>;
    /** <code>ThrottlingBurstLimit</code>  <a name="cfn-apigatewayv2-stage-routesettings-throttlingburstlimit"></a>
  Specifies the throttling burst limit.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    throttlingBurstLimit?: Value<number>;
    /** <code>DetailedMetricsEnabled</code>  <a name="cfn-apigatewayv2-stage-routesettings-detailedmetricsenabled"></a>
  Specifies whether detailed metrics are enabled.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    detailedMetricsEnabled?: Value<boolean>;
    /** <code>ThrottlingRateLimit</code>  <a name="cfn-apigatewayv2-stage-routesettings-throttlingratelimit"></a>
  Specifies the throttling rate limit.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    throttlingRateLimit?: Value<number>;
}
