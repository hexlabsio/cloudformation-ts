import { Value } from '../../kloudformation/Value';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGatewayV2::Deployment</code> resource creates a deployment for an API.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-deployment.html">the AWS Docs</a>
*/
export declare type Deployment = DeploymentProperties;
export declare function deployment(deploymentProps: DeploymentProperties): Deployment;
/**
  The <code>AWS::ApiGatewayV2::Deployment</code> resource creates a deployment for an API.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-deployment.html">the AWS Docs</a>
*/
export interface DeploymentProperties extends KloudResource {
    /** <code>Description</code>  <a name="cfn-apigatewayv2-deployment-description"></a>
  The description for the deployment resource.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>StageName</code>  <a name="cfn-apigatewayv2-deployment-stagename"></a>
  The name of an existing stage to associate with the deployment.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    stageName?: Value<string>;
    /** <code>ApiId</code>  <a name="cfn-apigatewayv2-deployment-apiid"></a>
  The API identifier.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    apiId: Value<string>;
}
