import { Value } from '../../kloudformation/Value';
import { TlsConfigProps } from './integration/TlsConfigProps';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGatewayV2::Integration</code> resource creates an integration for an API.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html">the AWS Docs</a>
*/
export declare type Integration = IntegrationProperties;
export declare function integration(integrationProps: IntegrationProperties): Integration;
/**
  The <code>AWS::ApiGatewayV2::Integration</code> resource creates an integration for an API.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html">the AWS Docs</a>
*/
export interface IntegrationProperties extends KloudResource {
    /** <code>Description</code>  <a name="cfn-apigatewayv2-integration-description"></a>
  The description of the integration.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>TemplateSelectionExpression</code>  <a name="cfn-apigatewayv2-integration-templateselectionexpression"></a>
  The template selection expression for the integration. Supported only for WebSocket APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    templateSelectionExpression?: Value<string>;
    /** <code>ConnectionType</code>  <a name="cfn-apigatewayv2-integration-connectiontype"></a>
  The type of the network connection to the integration endpoint. Specify <code>INTERNET</code> for connections through the public routable internet or <code>VPC_LINK</code> for private connections between API Gateway and resources in a VPC. The default value is <code>INTERNET</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    connectionType?: Value<string>;
    /** <code>ResponseParameters</code>  <a name="cfn-apigatewayv2-integration-responseparameters"></a>
  Supported only for HTTP APIs. You use response parameters to transform the HTTP response from a backend integration before returning the response to clients. Specify a key-value map from a selection key to response parameters. The selection key must be a valid HTTP status code within the range of 200-599. The value is of type <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-integration-responseparameterlist.html">https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-integration-responseparameterlist.html</a>. To learn more, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-parameter-mapping.html">Transforming API requests and responses</a>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    responseParameters?: Value<any>;
    /** <code>IntegrationMethod</code>  <a name="cfn-apigatewayv2-integration-integrationmethod"></a>
  Specifies the integration’s HTTP method type.<br />
  
  Required: Conditional<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    integrationMethod?: Value<string>;
    /** <code>PassthroughBehavior</code>  <a name="cfn-apigatewayv2-integration-passthroughbehavior"></a>
  Specifies the pass-through behavior for incoming requests based on the <code>Content-Type</code> header in the request, and the available mapping templates specified as the <code>requestTemplates</code> property on the <code>Integration</code> resource. There are three valid values: <code>WHEN_NO_MATCH</code>, <code>WHEN_NO_TEMPLATES</code>, and <code>NEVER</code>. Supported only for WebSocket APIs.<br />
  <code>WHEN_NO_MATCH</code> passes the request body for unmapped content types through to the integration backend without transformation.<br />
  <code>NEVER</code> rejects unmapped content types with an <code>HTTP 415 Unsupported Media Type</code> response.<br />
  <code>WHEN_NO_TEMPLATES</code> allows pass-through when the integration has no content types mapped to templates. However, if there is at least one content type defined, unmapped content types will be rejected with the same <code>HTTP 415 Unsupported Media Type</code> response.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    passthroughBehavior?: Value<string>;
    /** <code>RequestParameters</code>  <a name="cfn-apigatewayv2-integration-requestparameters"></a>
  For WebSocket APIs, a key-value map specifying request parameters that are passed from the method request to the backend. The key is an integration request parameter name and the associated value is a method request parameter value or static value that must be enclosed within single quotes and pre-encoded as required by the backend. The method request parameter value must match the pattern of <code>method.request.{location}.{name} </code>, where <code>{location}</code> is <code>querystring</code>, <code>path</code>, or <code>header</code>; and <code>{name}</code> must be a valid and unique method request parameter name.<br />
  For HTTP API integrations with a specified <code>integrationSubtype</code>, request parameters are a key-value map specifying parameters that are passed to <code>AWS_PROXY</code> integrations. You can provide static values, or map request data, stage variables, or context variables that are evaluated at runtime. To learn more, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-develop-integrations-aws-services.html">Working with AWS service integrations for HTTP APIs</a>.<br />
  For HTTP API integrations without a specified <code>integrationSubtype</code> request parameters are a key-value map specifying how to transform HTTP requests before sending them to the backend. The key should follow the pattern <action>:&lt;header|querystring|path&gt;.<location> where action can be <code>append</code>, <code>overwrite</code> or<code> remove</code>. For values, you can provide static values, or map request data, stage variables, or context variables that are evaluated at runtime. To learn more, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-parameter-mapping.html">Transforming API requests and responses</a>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    requestParameters?: Value<any>;
    /** <code>ConnectionId</code>  <a name="cfn-apigatewayv2-integration-connectionid"></a>
  The ID of the VPC link for a private integration. Supported only for HTTP APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    connectionId?: Value<string>;
    /** <code>IntegrationUri</code>  <a name="cfn-apigatewayv2-integration-integrationuri"></a>
  For a Lambda integration, specify the URI of a Lambda function.<br />
  For an HTTP integration, specify a fully-qualified URL.<br />
  For an HTTP API private integration, specify the ARN of an Application Load Balancer listener, Network Load Balancer listener, or AWS Cloud Map service. If you specify the ARN of an AWS Cloud Map service, API Gateway uses <code>DiscoverInstances</code> to identify resources. You can use query parameters to target specific resources. To learn more, see <a href="https://docs.aws.amazon.com/cloud-map/latest/api/API_DiscoverInstances.html">DiscoverInstances</a>. For private integrations, all resources must be owned by the same AWS account.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    integrationUri?: Value<string>;
    /** <code>PayloadFormatVersion</code>  <a name="cfn-apigatewayv2-integration-payloadformatversion"></a>
  Specifies the format of the payload sent to an integration. Required for HTTP APIs. For HTTP APIs, supported values for Lambda proxy integrations are <code>1.0</code> and <code>2.0</code>. For all other integrations, <code>1.0</code> is the only supported value. To learn more, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-develop-integrations-lambda.html">Working with AWS Lambda proxy integrations for HTTP APIs</a>.<br />
  
  Required: Conditional<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    payloadFormatVersion?: Value<string>;
    /** <code>CredentialsArn</code>  <a name="cfn-apigatewayv2-integration-credentialsarn"></a>
  Specifies the credentials required for the integration, if any. For AWS integrations, three options are available. To specify an IAM Role for API Gateway to assume, use the role’s Amazon Resource Name (ARN). To require that the caller’s identity be passed through from the request, specify the string <code>arn:aws:iam::*:user/*</code>. To use resource-based permissions on supported AWS services, don’t specify this parameter.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    credentialsArn?: Value<string>;
    /** <code>RequestTemplates</code>  <a name="cfn-apigatewayv2-integration-requesttemplates"></a>
  Represents a map of Velocity templates that are applied on the request payload based on the value of the Content-Type header sent by the client. The content type value is the key in this map, and the template (as a String) is the value. Supported only for WebSocket APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    requestTemplates?: Value<any>;
    /** <code>TimeoutInMillis</code>  <a name="cfn-apigatewayv2-integration-timeoutinmillis"></a>
  Custom timeout between 50 and 29,000 milliseconds for WebSocket APIs and between 50 and 30,000 milliseconds for HTTP APIs. The default timeout is 29 seconds for WebSocket APIs and 30 seconds for HTTP APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    timeoutInMillis?: Value<number>;
    /** <code>TlsConfig</code>  <a name="cfn-apigatewayv2-integration-tlsconfig"></a>
  The TLS configuration for a private integration. If you specify a TLS configuration, private integration traffic uses the HTTPS protocol. Supported only for HTTP APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tlsConfig?: TlsConfigProps;
    /** <code>ContentHandlingStrategy</code>  <a name="cfn-apigatewayv2-integration-contenthandlingstrategy"></a>
  Supported only for WebSocket APIs. Specifies how to handle response payload content type conversions. Supported values are <code>CONVERT_TO_BINARY</code> and <code>CONVERT_TO_TEXT</code>, with the following behaviors:<br />
  <code>CONVERT_TO_BINARY</code>: Converts a response payload from a Base64-encoded string to the corresponding binary blob.<br />
  <code>CONVERT_TO_TEXT</code>: Converts a response payload from a binary blob to a Base64-encoded string.<br />
  If this property is not defined, the response payload will be passed through from the integration response to the route response or method response without modification.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    contentHandlingStrategy?: Value<string>;
    /** <code>IntegrationSubtype</code>  <a name="cfn-apigatewayv2-integration-integrationsubtype"></a>
  Supported only for HTTP API <code>AWS_PROXY</code> integrations. Specifies the AWS service action to invoke. To learn more, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-develop-integrations-aws-services-reference.html">Integration subtype reference</a>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    integrationSubtype?: Value<string>;
    /** <code>ApiId</code>  <a name="cfn-apigatewayv2-integration-apiid"></a>
  The API identifier.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    apiId: Value<string>;
    /** <code>IntegrationType</code>  <a name="cfn-apigatewayv2-integration-integrationtype"></a>
  The integration type of an integration. One of the following:<br />
  <code>AWS</code>: for integrating the route or method request with an AWS service action, including the Lambda function-invoking action. With the Lambda function-invoking action, this is referred to as the Lambda custom integration. With any other AWS service action, this is known as AWS integration. Supported only for WebSocket APIs.<br />
  <code>AWS_PROXY</code>: for integrating the route or method request with a Lambda function or other AWS service action. This integration is also referred to as a Lambda proxy integration.<br />
  <code>HTTP</code>: for integrating the route or method request with an HTTP endpoint. This integration is also referred to as the HTTP custom integration. Supported only for WebSocket APIs.<br />
  <code>HTTP_PROXY</code>: for integrating the route or method request with an HTTP endpoint, with the client request passed through as-is. This is also referred to as HTTP proxy integration. For HTTP API private integrations, use an <code>HTTP_PROXY</code> integration.<br />
  <code>MOCK</code>: for integrating the route or method request with API Gateway as a “loopback” endpoint without invoking any backend. Supported only for WebSocket APIs.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    integrationType: Value<string>;
}
