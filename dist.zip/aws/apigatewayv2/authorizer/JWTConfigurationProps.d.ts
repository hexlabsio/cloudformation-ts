import { Value } from '../../../kloudformation/Value';
/**
  The <code>JWTConfiguration</code> property specifies the configuration of a JWT authorizer. Required for the <code>JWT</code> authorizer type. Supported only for HTTP APIs.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-authorizer-jwtconfiguration.html">the AWS Docs</a>
*/
export interface JWTConfigurationProps {
    /** <code>Issuer</code>  <a name="cfn-apigatewayv2-authorizer-jwtconfiguration-issuer"></a>
  The base domain of the identity provider that issues JSON Web Tokens. For example, an Amazon Cognito user pool has the following format: <code>https://cognito-idp.{region}.amazonaws.com/{userPoolId} </code>. Required for the <code>JWT</code> authorizer type. Supported only for HTTP APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    issuer?: Value<string>;
    /** <code>Audience</code>  <a name="cfn-apigatewayv2-authorizer-jwtconfiguration-audience"></a>
  A list of the intended recipients of the JWT. A valid JWT must provide an <code>aud</code> that matches at least one entry in this list. See <a href="https://tools.ietf.org/html/rfc7519#section-4.1.3">RFC 7519</a>. Required for the <code>JWT</code> authorizer type. Supported only for HTTP APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    audience?: Value<Value<string>[]>;
}
