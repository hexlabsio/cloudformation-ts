import { Value } from '../../../kloudformation/Value';
/**
  Specifies whether the parameter is required.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-routeresponse-parameterconstraints.html">the AWS Docs</a>
*/
export interface ParameterConstraintsProps {
    /** <code>Required</code>  <a name="cfn-apigatewayv2-routeresponse-parameterconstraints-required"></a>
  Specifies whether the parameter is required.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    required: Value<boolean>;
}
