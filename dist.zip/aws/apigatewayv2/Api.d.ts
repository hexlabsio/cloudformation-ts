import { Value } from '../../kloudformation/Value';
import { BodyS3LocationProps } from './api/BodyS3LocationProps';
import { CorsProps } from './api/CorsProps';
import { Attribute } from '../../kloudformation/Attribute';
import { KloudResource } from '../../kloudformation/KloudResource';
export declare type ApiAttributes = {
    ApiEndpoint: Attribute<string>;
};
export declare type Api = ApiProperties & {
    attributes: ApiAttributes;
};
/**
  The <code>AWS::ApiGatewayV2::Api</code> resource creates an API. WebSocket APIs and HTTP APIs are supported. For more information about WebSocket APIs, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-websocket-api-overview.html">About WebSocket APIs in API Gateway</a> in the <em>API Gateway Developer Guide</em>. For more information about HTTP APIs, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api.html">HTTP APIs</a> in the <em>API Gateway Developer Guide.</em>
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html">the AWS Docs</a>
*/
export declare function api(apiProps: ApiProperties): Api;
/**
  The <code>AWS::ApiGatewayV2::Api</code> resource creates an API. WebSocket APIs and HTTP APIs are supported. For more information about WebSocket APIs, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-websocket-api-overview.html">About WebSocket APIs in API Gateway</a> in the <em>API Gateway Developer Guide</em>. For more information about HTTP APIs, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api.html">HTTP APIs</a> in the <em>API Gateway Developer Guide.</em>
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html">the AWS Docs</a>
*/
export interface ApiProperties extends KloudResource {
    /** <code>RouteSelectionExpression</code>  <a name="cfn-apigatewayv2-api-routeselectionexpression"></a>
  The route selection expression for the API. For HTTP APIs, the <code>routeSelectionExpression</code> must be <code>${request.method} ${request.path}</code>. If not provided, this will be the default for HTTP APIs. This property is required for WebSocket APIs.<br />
  
  Required: Conditional<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    routeSelectionExpression?: Value<string>;
    /** <code>BodyS3Location</code>  <a name="cfn-apigatewayv2-api-bodys3location"></a>
  The S3 location of an OpenAPI definition. Supported only for HTTP APIs. To import an HTTP API, you must specify a <code>Body</code> or <code>BodyS3Location</code>.<br />
  
  Required: Conditional<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    bodyS3Location?: BodyS3LocationProps;
    /** <code>Description</code>  <a name="cfn-apigatewayv2-api-description"></a>
  The description of the API.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>BasePath</code>  <a name="cfn-apigatewayv2-api-basepath"></a>
  Specifies how to interpret the base path of the API during import. Valid values are <code>ignore</code>, <code>prepend</code>, and <code>split</code>. The default value is <code>ignore</code>. To learn more, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-import-api-basePath.html">Set the OpenAPI basePath Property</a>. Supported only for HTTP APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    basePath?: Value<string>;
    /** <code>FailOnWarnings</code>  <a name="cfn-apigatewayv2-api-failonwarnings"></a>
  Specifies whether to rollback the API creation when a warning is encountered. By default, API creation continues if a warning is encountered.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    failOnWarnings?: Value<boolean>;
    /** <code>DisableExecuteApiEndpoint</code>  <a name="cfn-apigatewayv2-api-disableexecuteapiendpoint"></a>
  Specifies whether clients can invoke your API by using the default <code>execute-api</code> endpoint. By default, clients can invoke your API with the default https://{api_id}.execute-api.{region}.amazonaws.com endpoint. To require that clients use a custom domain name to invoke your API, disable the default endpoint.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    disableExecuteApiEndpoint?: Value<boolean>;
    /** <code>DisableSchemaValidation</code>  <a name="cfn-apigatewayv2-api-disableschemavalidation"></a>
  Avoid validating models when creating a deployment. Supported only for WebSocket APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    disableSchemaValidation?: Value<boolean>;
    /** <code>Name</code>  <a name="cfn-apigatewayv2-api-name"></a>
  The name of the API. Required unless you specify an OpenAPI definition for <code>Body</code> or <code>S3BodyLocation</code>.<br />
  
  Required: Conditional<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    name?: Value<string>;
    /** <code>Target</code>  <a name="cfn-apigatewayv2-api-target"></a>
  This property is part of quick create. Quick create produces an API with an integration, a default catch-all route, and a default stage which is configured to automatically deploy changes. For HTTP integrations, specify a fully qualified URL. For Lambda integrations, specify a function ARN. The type of the integration will be HTTP_PROXY or AWS_PROXY, respectively. Supported only for HTTP APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    target?: Value<string>;
    /** <code>CredentialsArn</code>  <a name="cfn-apigatewayv2-api-credentialsarn"></a>
  This property is part of quick create. It specifies the credentials required for the integration, if any. For a Lambda integration, three options are available. To specify an IAM Role for API Gateway to assume, use the role’s Amazon Resource Name (ARN). To require that the caller’s identity be passed through from the request, specify <code>arn:aws:iam::*:user/*</code>. To use resource-based permissions on supported AWS services, specify <code>null</code>. Currently, this property is not used for HTTP integrations. Supported only for HTTP APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    credentialsArn?: Value<string>;
    /** <code>CorsConfiguration</code>  <a name="cfn-apigatewayv2-api-corsconfiguration"></a>
  A CORS configuration. Supported only for HTTP APIs. See <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-cors.html">Configuring CORS</a> for more information.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    corsConfiguration?: CorsProps;
    /** <code>Version</code>  <a name="cfn-apigatewayv2-api-version"></a>
  A version identifier for the API.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    version?: Value<string>;
    /** <code>ProtocolType</code>  <a name="cfn-apigatewayv2-api-protocoltype"></a>
  The API protocol. Valid values are <code>WEBSOCKET</code> or <code>HTTP</code>. Required unless you specify an OpenAPI definition for <code>Body</code> or <code>S3BodyLocation</code>.<br />
  
  Required: Conditional<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    protocolType?: Value<string>;
    /** <code>RouteKey</code>  <a name="cfn-apigatewayv2-api-routekey"></a>
  This property is part of quick create. If you don’t specify a <code>routeKey</code>, a default route of <code>$default</code> is created. The <code>$default</code> route acts as a catch-all for any request made to your API, for a particular stage. The <code>$default</code> route key can’t be modified. You can add routes after creating the API, and you can update the route keys of additional routes. Supported only for HTTP APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    routeKey?: Value<string>;
    /** <code>Body</code>  <a name="cfn-apigatewayv2-api-body"></a>
  The OpenAPI definition. Supported only for HTTP APIs. To import an HTTP API, you must specify a <code>Body</code> or <code>BodyS3Location</code>.<br />
  
  Required: Conditional<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    body?: Value<any>;
    /** <code>Tags</code>  <a name="cfn-apigatewayv2-api-tags"></a>
  The collection of tags. Each tag element is associated with a given resource.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: Value<any>;
    /** <code>ApiKeySelectionExpression</code>  <a name="cfn-apigatewayv2-api-apikeyselectionexpression"></a>
  An API key selection expression. Supported only for WebSocket APIs. See <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-websocket-api-selection-expressions.html#apigateway-websocket-api-apikey-selection-expressions">API Key Selection Expressions</a>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    apiKeySelectionExpression?: Value<string>;
}
