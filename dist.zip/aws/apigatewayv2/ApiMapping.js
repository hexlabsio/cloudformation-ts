"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function apiMapping(apiMappingProps) { return ({ ...apiMappingProps, _logicalType: 'AWS::ApiGatewayV2::ApiMapping' }); }
exports.apiMapping = apiMapping;
