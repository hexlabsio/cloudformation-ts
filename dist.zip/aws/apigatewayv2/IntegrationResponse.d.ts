import { Value } from '../../kloudformation/Value';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGatewayV2::IntegrationResponse</code> resource updates an integration response for an WebSocket API. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-websocket-api-integration-responses.html">Set up WebSocket API Integration Responses in API Gateway</a> in the <em>API Gateway Developer Guide</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integrationresponse.html">the AWS Docs</a>
*/
export declare type IntegrationResponse = IntegrationResponseProperties;
export declare function integrationResponse(integrationResponseProps: IntegrationResponseProperties): IntegrationResponse;
/**
  The <code>AWS::ApiGatewayV2::IntegrationResponse</code> resource updates an integration response for an WebSocket API. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-websocket-api-integration-responses.html">Set up WebSocket API Integration Responses in API Gateway</a> in the <em>API Gateway Developer Guide</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integrationresponse.html">the AWS Docs</a>
*/
export interface IntegrationResponseProperties extends KloudResource {
    /** <code>ResponseTemplates</code>  <a name="cfn-apigatewayv2-integrationresponse-responsetemplates"></a>
  The collection of response templates for the integration response as a string-to-string map of key-value pairs. Response templates are represented as a key/value map, with a content-type as the key and a template as the value.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    responseTemplates?: Value<any>;
    /** <code>TemplateSelectionExpression</code>  <a name="cfn-apigatewayv2-integrationresponse-templateselectionexpression"></a>
  The template selection expression for the integration response. Supported only for WebSocket APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    templateSelectionExpression?: Value<string>;
    /** <code>ResponseParameters</code>  <a name="cfn-apigatewayv2-integrationresponse-responseparameters"></a>
  A key-value map specifying response parameters that are passed to the method response from the backend. The key is a method response header parameter name and the mapped value is an integration response header value, a static value enclosed within a pair of single quotes, or a JSON expression from the integration response body. The mapping key must match the pattern of <code>method.response.header.{name} </code>, where name is a valid and unique header name. The mapped non-static value must match the pattern of <code>integration.response.header.{name} </code> or <code>integration.response.body.{JSON-expression} </code>, where <code>{name}</code> is a valid and unique response header name and <code>{JSON-expression}</code> is a valid JSON expression without the <code>$</code> prefix.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    responseParameters?: Value<any>;
    /** <code>ContentHandlingStrategy</code>  <a name="cfn-apigatewayv2-integrationresponse-contenthandlingstrategy"></a>
  Supported only for WebSocket APIs. Specifies how to handle response payload content type conversions. Supported values are <code>CONVERT_TO_BINARY</code> and <code>CONVERT_TO_TEXT</code>, with the following behaviors:<br />
  <code>CONVERT_TO_BINARY</code>: Converts a response payload from a Base64-encoded string to the corresponding binary blob.<br />
  <code>CONVERT_TO_TEXT</code>: Converts a response payload from a binary blob to a Base64-encoded string.<br />
  If this property is not defined, the response payload will be passed through from the integration response to the route response or method response without modification.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    contentHandlingStrategy?: Value<string>;
    /** <code>IntegrationId</code>  <a name="cfn-apigatewayv2-integrationresponse-integrationid"></a>
  The integration ID.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    integrationId: Value<string>;
    /** <code>IntegrationResponseKey</code>  <a name="cfn-apigatewayv2-integrationresponse-integrationresponsekey"></a>
  The integration response key.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    integrationResponseKey: Value<string>;
    /** <code>ApiId</code>  <a name="cfn-apigatewayv2-integrationresponse-apiid"></a>
  The API identifier.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    apiId: Value<string>;
}
