import { Value } from '../../../kloudformation/Value';
/**
  The <code>TlsConfig</code> property specifies the TLS configuration for a private integration. If you specify a TLS configuration, private integration traffic uses the HTTPS protocol. Supported only for HTTP APIs.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-integration-tlsconfig.html">the AWS Docs</a>
*/
export interface TlsConfigProps {
    /** <code>ServerNameToVerify</code>  <a name="cfn-apigatewayv2-integration-tlsconfig-servernametoverify"></a>
  If you specify a server name, API Gateway uses it to verify the hostname on the integration’s certificate. The server name is also included in the TLS handshake to support Server Name Indication (SNI) or virtual hosting.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    serverNameToVerify?: Value<string>;
}
