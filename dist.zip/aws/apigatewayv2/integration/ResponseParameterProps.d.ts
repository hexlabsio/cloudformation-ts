import { Value } from '../../../kloudformation/Value';
/**
  Supported only for HTTP APIs. You use response parameters to transform the HTTP response from a backend integration before returning the response to clients. Specify a key-value map from a selection key to response parameters. The selection key must be a valid HTTP status code within the range of 200-599. Response parameters are a key-value map. The key must match the pattern <code>&lt;action&gt;:&lt;header&gt;.&lt;location&gt;</code> or <code>overwrite.statuscode</code>. The action can be <code>append</code>, <code>overwrite</code> or <code>remove</code>. The value can be a static value, or map to response data, stage variables, or context variables that are evaluated at runtime. To learn more, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-parameter-mapping.html">Transforming API requests and responses</a>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-integration-responseparameter.html">the AWS Docs</a>
*/
export interface ResponseParameterProps {
    /** <code>Destination</code>  <a name="cfn-apigatewayv2-integration-responseparameter-destination"></a>
  Specifies the location of the response to modify, and how to modify it. To learn more, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-parameter-mapping.html">Transforming API requests and responses</a>.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    destination: Value<string>;
    /** <code>Source</code>  <a name="cfn-apigatewayv2-integration-responseparameter-source"></a>
  Specifies the data to update the parameter with. To learn more, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-parameter-mapping.html">Transforming API requests and responses</a>.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    source: Value<string>;
}
