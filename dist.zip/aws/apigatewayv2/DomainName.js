"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  The <code>AWS::ApiGatewayV2::DomainName</code> resource specifies a custom domain name for your API in Amazon API Gateway (API Gateway).
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-domainname.html">the AWS Docs</a>
*/
function domainName(domainNameProps) { return ({ ...domainNameProps, _logicalType: 'AWS::ApiGatewayV2::DomainName', attributes: { RegionalHostedZoneId: 'RegionalHostedZoneId', RegionalDomainName: 'RegionalDomainName' } }); }
exports.domainName = domainName;
