"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function integration(integrationProps) { return ({ ...integrationProps, _logicalType: 'AWS::ApiGatewayV2::Integration' }); }
exports.integration = integration;
