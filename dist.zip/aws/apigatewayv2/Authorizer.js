"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function authorizer(authorizerProps) { return ({ ...authorizerProps, _logicalType: 'AWS::ApiGatewayV2::Authorizer' }); }
exports.authorizer = authorizer;
