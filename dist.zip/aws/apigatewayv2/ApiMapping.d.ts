import { Value } from '../../kloudformation/Value';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGatewayV2::ApiMapping</code> resource contains an API mapping. An API mapping relates a path of your custom domain name to a stage of your API. A custom domain name can have multiple API mappings, but the paths can’t overlap. A custom domain can map only to APIs of the same protocol type. For more information, see <a href="https://docs.aws.amazon.com/apigatewayv2/latest/api-reference/domainnames-domainname-apimappings.html#CreateApiMapping">CreateApiMapping</a> in the <em>Amazon API Gateway V2 API Reference</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-apimapping.html">the AWS Docs</a>
*/
export declare type ApiMapping = ApiMappingProperties;
export declare function apiMapping(apiMappingProps: ApiMappingProperties): ApiMapping;
/**
  The <code>AWS::ApiGatewayV2::ApiMapping</code> resource contains an API mapping. An API mapping relates a path of your custom domain name to a stage of your API. A custom domain name can have multiple API mappings, but the paths can’t overlap. A custom domain can map only to APIs of the same protocol type. For more information, see <a href="https://docs.aws.amazon.com/apigatewayv2/latest/api-reference/domainnames-domainname-apimappings.html#CreateApiMapping">CreateApiMapping</a> in the <em>Amazon API Gateway V2 API Reference</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-apimapping.html">the AWS Docs</a>
*/
export interface ApiMappingProperties extends KloudResource {
    /** <code>DomainName</code>  <a name="cfn-apigatewayv2-apimapping-domainname"></a>
  The domain name.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    domainName: Value<string>;
    /** <code>Stage</code>  <a name="cfn-apigatewayv2-apimapping-stage"></a>
  The API stage.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    stage: Value<string>;
    /** <code>ApiMappingKey</code>  <a name="cfn-apigatewayv2-apimapping-apimappingkey"></a>
  The API mapping key.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    apiMappingKey?: Value<string>;
    /** <code>ApiId</code>  <a name="cfn-apigatewayv2-apimapping-apiid"></a>
  The identifier of the API.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    apiId: Value<string>;
}
