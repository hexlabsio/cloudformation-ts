import { Value } from '../../../kloudformation/Value';
/**
  The <code>DomainNameConfiguration</code> property type specifies the configuration for a an API’s domain name.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-domainname-domainnameconfiguration.html">the AWS Docs</a>
*/
export interface DomainNameConfigurationProps {
    /** <code>SecurityPolicy</code>  <a name="cfn-apigatewayv2-domainname-domainnameconfiguration-securitypolicy"></a>
  The Transport Layer Security (TLS) version of the security policy for this domain name. The valid values are <code>TLS_1_0</code> and <code>TLS_1_2</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    securityPolicy?: Value<string>;
    /** <code>EndpointType</code>  <a name="cfn-apigatewayv2-domainname-domainnameconfiguration-endpointtype"></a>
  The endpoint type.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    endpointType?: Value<string>;
    /** <code>CertificateName</code>  <a name="cfn-apigatewayv2-domainname-domainnameconfiguration-certificatename"></a>
  The user-friendly name of the certificate that will be used by the edge-optimized endpoint for this domain name.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    certificateName?: Value<string>;
    /** <code>CertificateArn</code>  <a name="cfn-apigatewayv2-domainname-domainnameconfiguration-certificatearn"></a>
  An AWS-managed certificate that will be used by the edge-optimized endpoint for this domain name. AWS Certificate Manager is the only supported source.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    certificateArn?: Value<string>;
}
