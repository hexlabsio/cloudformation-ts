import { Value } from '../../../kloudformation/Value';
/**
  If specified, API Gateway performs two-way authentication between the client and the server. Clients must present a trusted certificate to access your API.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-domainname-mutualtlsauthentication.html">the AWS Docs</a>
*/
export interface MutualTlsAuthenticationProps {
    /** <code>TruststoreVersion</code>  <a name="cfn-apigatewayv2-domainname-mutualtlsauthentication-truststoreversion"></a>
  The version of the S3 object that contains your truststore. To specify a version, you must have versioning enabled for the S3 bucket.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    truststoreVersion?: Value<string>;
    /** <code>TruststoreUri</code>  <a name="cfn-apigatewayv2-domainname-mutualtlsauthentication-truststoreuri"></a>
  An Amazon S3 URL that specifies the truststore for mutual TLS authentication, for example, <code>s3://bucket-name/key-name </code>. The truststore can contain certificates from public or private certificate authorities. To update the truststore, upload a new version to S3, and then update your custom domain name to use the new version. To update the truststore, you must have permissions to access the S3 object.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    truststoreUri?: Value<string>;
}
