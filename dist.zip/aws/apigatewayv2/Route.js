"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function route(routeProps) { return ({ ...routeProps, _logicalType: 'AWS::ApiGatewayV2::Route' }); }
exports.route = route;
