import { Value } from '../../kloudformation/Value';
import { AccessLogSettingsProps } from './stage/AccessLogSettingsProps';
import { RouteSettingsProps } from './stage/RouteSettingsProps';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGatewayV2::Stage</code> resource updates a stage for an API.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html">the AWS Docs</a>
*/
export declare type Stage = StageProperties;
export declare function stage(stageProps: StageProperties): Stage;
/**
  The <code>AWS::ApiGatewayV2::Stage</code> resource updates a stage for an API.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html">the AWS Docs</a>
*/
export interface StageProperties extends KloudResource {
    /** <code>ClientCertificateId</code>  <a name="cfn-apigatewayv2-stage-clientcertificateid"></a>
  The identifier of a client certificate for a <code>Stage</code>. Supported only for WebSocket APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    clientCertificateId?: Value<string>;
    /** <code>DeploymentId</code>  <a name="cfn-apigatewayv2-stage-deploymentid"></a>
  The deployment identifier for the API stage. Can’t be updated if <code>autoDeploy</code> is enabled.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    deploymentId?: Value<string>;
    /** <code>Description</code>  <a name="cfn-apigatewayv2-stage-description"></a>
  The description for the API stage.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>AccessLogSettings</code>  <a name="cfn-apigatewayv2-stage-accesslogsettings"></a>
  Settings for logging access in this stage.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    accessLogSettings?: AccessLogSettingsProps;
    /** <code>AutoDeploy</code>  <a name="cfn-apigatewayv2-stage-autodeploy"></a>
  Specifies whether updates to an API automatically trigger a new deployment. The default value is <code>false</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    autoDeploy?: Value<boolean>;
    /** <code>RouteSettings</code>  <a name="cfn-apigatewayv2-stage-routesettings"></a>
  Route settings for the stage.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    routeSettings?: Value<any>;
    /** <code>StageName</code>  <a name="cfn-apigatewayv2-stage-stagename"></a>
  The stage name. Stage names can contain only alphanumeric characters, hyphens, and underscores, or be <code>$default</code>. Maximum length is 128 characters.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    stageName: Value<string>;
    /** <code>StageVariables</code>  <a name="cfn-apigatewayv2-stage-stagevariables"></a>
  A map that defines the stage variables for a <code>Stage</code>. Variable names can have alphanumeric and underscore characters, and the values must match [A-Za-z0-9-._~:/?#&amp;=,]+.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    stageVariables?: Value<any>;
    /** <code>AccessPolicyId</code>  <a name="cfn-apigatewayv2-stage-accesspolicyid"></a>
  This parameter is not currently supported.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    accessPolicyId?: Value<string>;
    /** <code>ApiId</code>  <a name="cfn-apigatewayv2-stage-apiid"></a>
  The API identifier.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    apiId: Value<string>;
    /** <code>DefaultRouteSettings</code>  <a name="cfn-apigatewayv2-stage-defaultroutesettings"></a>
  The default route settings for the stage.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    defaultRouteSettings?: RouteSettingsProps;
    /** <code>Tags</code>  <a name="cfn-apigatewayv2-stage-tags"></a>
  The collection of tags. Each tag element is associated with a given resource.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: Value<any>;
}
