import { Value } from '../../../kloudformation/Value';
/**
  The <code>Cors</code> property specifies a CORS configuration for an API. Supported only for HTTP APIs. See <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-cors.html">Configuring CORS</a> for more information.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-api-cors.html">the AWS Docs</a>
*/
export interface CorsProps {
    /** <code>AllowOrigins</code>  <a name="cfn-apigatewayv2-api-cors-alloworigins"></a>
  Represents a collection of allowed origins. Supported only for HTTP APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    allowOrigins?: Value<Value<string>[]>;
    /** <code>AllowCredentials</code>  <a name="cfn-apigatewayv2-api-cors-allowcredentials"></a>
  Specifies whether credentials are included in the CORS request. Supported only for HTTP APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    allowCredentials?: Value<boolean>;
    /** <code>ExposeHeaders</code>  <a name="cfn-apigatewayv2-api-cors-exposeheaders"></a>
  Represents a collection of exposed headers. Supported only for HTTP APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    exposeHeaders?: Value<Value<string>[]>;
    /** <code>AllowHeaders</code>  <a name="cfn-apigatewayv2-api-cors-allowheaders"></a>
  Represents a collection of allowed headers. Supported only for HTTP APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    allowHeaders?: Value<Value<string>[]>;
    /** <code>MaxAge</code>  <a name="cfn-apigatewayv2-api-cors-maxage"></a>
  The number of seconds that the browser should cache preflight request results. Supported only for HTTP APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    maxAge?: Value<number>;
    /** <code>AllowMethods</code>  <a name="cfn-apigatewayv2-api-cors-allowmethods"></a>
  Represents a collection of allowed HTTP methods. Supported only for HTTP APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    allowMethods?: Value<Value<string>[]>;
}
