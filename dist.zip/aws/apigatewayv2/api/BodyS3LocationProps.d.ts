import { Value } from '../../../kloudformation/Value';
/**
  The <code>BodyS3Location</code> property specifies an S3 location from which to import an OpenAPI definition. Supported only for HTTP APIs.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-api-bodys3location.html">the AWS Docs</a>
*/
export interface BodyS3LocationProps {
    /** <code>Etag</code>  <a name="cfn-apigatewayv2-api-bodys3location-etag"></a>
  The Etag of the S3 object.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    etag?: Value<string>;
    /** <code>Bucket</code>  <a name="cfn-apigatewayv2-api-bodys3location-bucket"></a>
  The S3 bucket that contains the OpenAPI definition to import. Required if you specify a <code>BodyS3Location</code> for an API.<br />
  
  Required: Conditional<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    bucket?: Value<string>;
    /** <code>Version</code>  <a name="cfn-apigatewayv2-api-bodys3location-version"></a>
  The version of the S3 object.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    version?: Value<string>;
    /** <code>Key</code>  <a name="cfn-apigatewayv2-api-bodys3location-key"></a>
  The key of the S3 object. Required if you specify a <code>BodyS3Location</code> for an API.<br />
  
  Required: Conditional<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    key?: Value<string>;
}
