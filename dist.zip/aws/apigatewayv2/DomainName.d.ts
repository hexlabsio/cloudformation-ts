import { MutualTlsAuthenticationProps } from './domainname/MutualTlsAuthenticationProps';
import { Value } from '../../kloudformation/Value';
import { DomainNameConfigurationProps } from './domainname/DomainNameConfigurationProps';
import { Attribute } from '../../kloudformation/Attribute';
import { KloudResource } from '../../kloudformation/KloudResource';
export declare type DomainNameAttributes = {
    RegionalHostedZoneId: Attribute<string>;
    RegionalDomainName: Attribute<string>;
};
export declare type DomainName = DomainNameProperties & {
    attributes: DomainNameAttributes;
};
/**
  The <code>AWS::ApiGatewayV2::DomainName</code> resource specifies a custom domain name for your API in Amazon API Gateway (API Gateway).
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-domainname.html">the AWS Docs</a>
*/
export declare function domainName(domainNameProps: DomainNameProperties): DomainName;
/**
  The <code>AWS::ApiGatewayV2::DomainName</code> resource specifies a custom domain name for your API in Amazon API Gateway (API Gateway).
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-domainname.html">the AWS Docs</a>
*/
export interface DomainNameProperties extends KloudResource {
    /** <code>MutualTlsAuthentication</code>  <a name="cfn-apigatewayv2-domainname-mutualtlsauthentication"></a>
  The mutual TLS authentication configuration for a custom domain name.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    mutualTlsAuthentication?: MutualTlsAuthenticationProps;
    /** <code>DomainName</code>  <a name="cfn-apigatewayv2-domainname-domainname"></a>
  The custom domain name for your API in Amazon API Gateway. Uppercase letters are not supported.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    domainName: Value<string>;
    /** <code>DomainNameConfigurations</code>  <a name="cfn-apigatewayv2-domainname-domainnameconfigurations"></a>
  The domain name configurations.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    domainNameConfigurations?: DomainNameConfigurationProps[];
    /** <code>Tags</code>  <a name="cfn-apigatewayv2-domainname-tags"></a>
  The collection of tags associated with a domain name.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: Value<any>;
}
