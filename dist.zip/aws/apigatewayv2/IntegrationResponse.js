"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function integrationResponse(integrationResponseProps) { return ({ ...integrationResponseProps, _logicalType: 'AWS::ApiGatewayV2::IntegrationResponse' }); }
exports.integrationResponse = integrationResponse;
