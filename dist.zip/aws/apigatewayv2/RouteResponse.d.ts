import { Value } from '../../kloudformation/Value';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApiGatewayV2::RouteResponse</code> resource creates a route response for a WebSocket API. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-websocket-api-route-response.html">Set up Route Responses for a WebSocket API in API Gateway</a> in the <em>API Gateway Developer Guide</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-routeresponse.html">the AWS Docs</a>
*/
export declare type RouteResponse = RouteResponseProperties;
export declare function routeResponse(routeResponseProps: RouteResponseProperties): RouteResponse;
/**
  The <code>AWS::ApiGatewayV2::RouteResponse</code> resource creates a route response for a WebSocket API. For more information, see <a href="https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-websocket-api-route-response.html">Set up Route Responses for a WebSocket API in API Gateway</a> in the <em>API Gateway Developer Guide</em>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-routeresponse.html">the AWS Docs</a>
*/
export interface RouteResponseProperties extends KloudResource {
    /** <code>RouteResponseKey</code>  <a name="cfn-apigatewayv2-routeresponse-routeresponsekey"></a>
  The route response key.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    routeResponseKey: Value<string>;
    /** <code>ResponseParameters</code>  <a name="cfn-apigatewayv2-routeresponse-responseparameters"></a>
  The route response parameters.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    responseParameters?: Value<any>;
    /** <code>RouteId</code>  <a name="cfn-apigatewayv2-routeresponse-routeid"></a>
  The route ID.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    routeId: Value<string>;
    /** <code>ModelSelectionExpression</code>  <a name="cfn-apigatewayv2-routeresponse-modelselectionexpression"></a>
  The model selection expression for the route response. Supported only for WebSocket APIs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    modelSelectionExpression?: Value<string>;
    /** <code>ApiId</code>  <a name="cfn-apigatewayv2-routeresponse-apiid"></a>
  The API identifier.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    apiId: Value<string>;
    /** <code>ResponseModels</code>  <a name="cfn-apigatewayv2-routeresponse-responsemodels"></a>
  The response models for the route response.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    responseModels?: Value<any>;
}
