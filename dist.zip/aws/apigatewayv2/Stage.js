"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function stage(stageProps) { return ({ ...stageProps, _logicalType: 'AWS::ApiGatewayV2::Stage' }); }
exports.stage = stage;
