import { FilterProps } from './FilterProps';
import { Value } from '../../../kloudformation/Value';
/**
  The criteria for an archive rule.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-archiverule.html">the AWS Docs</a>
*/
export interface ArchiveRuleProps {
    /** <code>Filter</code>  <a name="cfn-accessanalyzer-analyzer-archiverule-filter"></a>
  The criteria for the rule.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    filter: FilterProps[];
    /** <code>RuleName</code>  <a name="cfn-accessanalyzer-analyzer-archiverule-rulename"></a>
  The name of the archive rule.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    ruleName: Value<string>;
}
