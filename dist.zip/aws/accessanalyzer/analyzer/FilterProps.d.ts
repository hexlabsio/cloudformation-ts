import { Value } from '../../../kloudformation/Value';
/**
  The criteria that defines the rule.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-filter.html">the AWS Docs</a>
*/
export interface FilterProps {
    /** <code>Contains</code>  <a name="cfn-accessanalyzer-analyzer-filter-contains"></a>
  A “contains” condition to match for the rule.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    contains?: Value<Value<string>[]>;
    /** <code>Eq</code>  <a name="cfn-accessanalyzer-analyzer-filter-eq"></a>
  An “equals” condition to match for the rule.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    eq?: Value<Value<string>[]>;
    /** <code>Exists</code>  <a name="cfn-accessanalyzer-analyzer-filter-exists"></a>
  An “exists” condition to match for the rule.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    exists?: Value<boolean>;
    /** <code>Property</code>  <a name="cfn-accessanalyzer-analyzer-filter-property"></a>
  The property used to define the criteria in the filter for the rule.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    property: Value<string>;
    /** <code>Neq</code>  <a name="cfn-accessanalyzer-analyzer-filter-neq"></a>
  A “not equal” condition to match for the rule.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    neq?: Value<Value<string>[]>;
}
