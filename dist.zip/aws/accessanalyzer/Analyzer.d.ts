import { Value } from '../../kloudformation/Value';
import { ArchiveRuleProps } from './analyzer/ArchiveRuleProps';
import { Tag } from '../Tag';
import { Attribute } from '../../kloudformation/Attribute';
import { KloudResource } from '../../kloudformation/KloudResource';
export declare type AnalyzerAttributes = {
    Arn: Attribute<string>;
};
export declare type Analyzer = AnalyzerProperties & {
    attributes: AnalyzerAttributes;
};
/**
  The <code>AWS::AccessAnalyzer::Analyzer</code> resource specifies a new analyzer. The analyzer is an object that represents the IAM Access Analyzer feature. An analyzer is required for Access Analyzer to become operational.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-accessanalyzer-analyzer.html">the AWS Docs</a>
*/
export declare function analyzer(analyzerProps: AnalyzerProperties): Analyzer;
/**
  The <code>AWS::AccessAnalyzer::Analyzer</code> resource specifies a new analyzer. The analyzer is an object that represents the IAM Access Analyzer feature. An analyzer is required for Access Analyzer to become operational.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-accessanalyzer-analyzer.html">the AWS Docs</a>
*/
export interface AnalyzerProperties extends KloudResource {
    /** <code>AnalyzerName</code>  <a name="cfn-accessanalyzer-analyzer-analyzername"></a>
  The name of the analyzer.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    analyzerName?: Value<string>;
    /** <code>ArchiveRules</code>  <a name="cfn-accessanalyzer-analyzer-archiverules"></a>
  Specifies the archive rules to add for the analyzer.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    archiveRules?: ArchiveRuleProps[];
    /** <code>Tags</code>  <a name="cfn-accessanalyzer-analyzer-tags"></a>
  The tags to apply to the analyzer.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: Tag[];
    /** <code>Type</code>  <a name="cfn-accessanalyzer-analyzer-type"></a>
  The type represents the zone of trust for the analyzer.<br />
  
  Allowed Values: ACCOUNT | ORGANIZATION<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    type: Value<string>;
}
