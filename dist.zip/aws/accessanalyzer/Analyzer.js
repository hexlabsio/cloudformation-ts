"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  The <code>AWS::AccessAnalyzer::Analyzer</code> resource specifies a new analyzer. The analyzer is an object that represents the IAM Access Analyzer feature. An analyzer is required for Access Analyzer to become operational.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-accessanalyzer-analyzer.html">the AWS Docs</a>
*/
function analyzer(analyzerProps) { return ({ ...analyzerProps, _logicalType: 'AWS::AccessAnalyzer::Analyzer', attributes: { Arn: 'Arn' } }); }
exports.analyzer = analyzer;
