"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function scalableTarget(scalableTargetProps) { return ({ ...scalableTargetProps, _logicalType: 'AWS::ApplicationAutoScaling::ScalableTarget' }); }
exports.scalableTarget = scalableTarget;
