import { Value } from '../../../kloudformation/Value';
import { ScalableTargetActionProps } from './ScalableTargetActionProps';
/**
  <code>ScheduledAction</code> is a property of <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-applicationautoscaling-scalabletarget.html">ScalableTarget</a> that specifies a scheduled action for a scalable target.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationautoscaling-scalabletarget-scheduledaction.html">the AWS Docs</a>
*/
export interface ScheduledActionProps {
    /** <code>EndTime</code>  <a name="cfn-applicationautoscaling-scalabletarget-scheduledaction-endtime"></a>
  The date and time for the recurring schedule to end.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    endTime?: Value<any>;
    /** <code>ScalableTargetAction</code>  <a name="cfn-applicationautoscaling-scalabletarget-scheduledaction-scalabletargetaction"></a>
  The new minimum and maximum capacity. You can set both values or just one. At the scheduled time, if the current capacity is below the minimum capacity, Application Auto Scaling scales out to the minimum capacity. If the current capacity is above the maximum capacity, Application Auto Scaling scales in to the maximum capacity.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    scalableTargetAction?: ScalableTargetActionProps;
    /** <p> */
    schedule: Value<string>;
    /** <code>ScheduledActionName</code>  <a name="cfn-applicationautoscaling-scalabletarget-scheduledaction-scheduledactionname"></a>
  The name of the scheduled action. This name must be unique among all other scheduled actions on the specified scalable target.<br />
  
  Required: Yes<br />
  
  Minimum: <code>1</code><br />
  
  Maximum: <code>256</code><br />
  
  Pattern: <code>(?!((^[ ]+.*)|(.*([\u0000-\u001f]|[\u007f-\u009f]|[:/|])+.*)|(.*[ ]+$))).+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    scheduledActionName: Value<string>;
    /** <code>StartTime</code>  <a name="cfn-applicationautoscaling-scalabletarget-scheduledaction-starttime"></a>
  The date and time that the action is scheduled to start.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    startTime?: Value<any>;
}
