import { Value } from '../../../kloudformation/Value';
/**
  Specifies whether the scaling activities for a scalable target are in a suspended state.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationautoscaling-scalabletarget-suspendedstate.html">the AWS Docs</a>
*/
export interface SuspendedStateProps {
    /** <code>DynamicScalingInSuspended</code>  <a name="cfn-applicationautoscaling-scalabletarget-suspendedstate-dynamicscalinginsuspended"></a>
  Whether scale in by a target tracking scaling policy or a step scaling policy is suspended. Set the value to <code>true</code> if you don’t want Application Auto Scaling to remove capacity when a scaling policy is triggered. The default is <code>false</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    dynamicScalingInSuspended?: Value<boolean>;
    /** <code>DynamicScalingOutSuspended</code>  <a name="cfn-applicationautoscaling-scalabletarget-suspendedstate-dynamicscalingoutsuspended"></a>
  Whether scale out by a target tracking scaling policy or a step scaling policy is suspended. Set the value to <code>true</code> if you don’t want Application Auto Scaling to add capacity when a scaling policy is triggered. The default is <code>false</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    dynamicScalingOutSuspended?: Value<boolean>;
    /** <code>ScheduledScalingSuspended</code>  <a name="cfn-applicationautoscaling-scalabletarget-suspendedstate-scheduledscalingsuspended"></a>
  Whether scheduled scaling is suspended. Set the value to <code>true</code> if you don’t want Application Auto Scaling to add or remove capacity by initiating scheduled actions. The default is <code>false</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    scheduledScalingSuspended?: Value<boolean>;
}
