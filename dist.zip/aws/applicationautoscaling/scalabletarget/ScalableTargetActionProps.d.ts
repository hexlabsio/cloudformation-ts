import { Value } from '../../../kloudformation/Value';
/**
  <code>ScalableTargetAction</code> is a subproperty of <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationautoscaling-scalabletarget-scheduledaction.html">ScheduledAction</a> that represents the minimum and maximum capacity for a scheduled action.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationautoscaling-scalabletarget-scalabletargetaction.html">the AWS Docs</a>
*/
export interface ScalableTargetActionProps {
    /** <code>MaxCapacity</code>  <a name="cfn-applicationautoscaling-scalabletarget-scalabletargetaction-maxcapacity"></a>
  The maximum capacity.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    maxCapacity?: Value<number>;
    /** <code>MinCapacity</code>  <a name="cfn-applicationautoscaling-scalabletarget-scalabletargetaction-mincapacity"></a>
  The minimum capacity.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    minCapacity?: Value<number>;
}
