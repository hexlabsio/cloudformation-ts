"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function scalingPolicy(scalingPolicyProps) { return ({ ...scalingPolicyProps, _logicalType: 'AWS::ApplicationAutoScaling::ScalingPolicy' }); }
exports.scalingPolicy = scalingPolicy;
