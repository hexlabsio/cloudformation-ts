import { Value } from '../../kloudformation/Value';
import { StepScalingPolicyConfigurationProps } from './scalingpolicy/StepScalingPolicyConfigurationProps';
import { TargetTrackingScalingPolicyConfigurationProps } from './scalingpolicy/TargetTrackingScalingPolicyConfigurationProps';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApplicationAutoScaling::ScalingPolicy</code> resource defines a scaling policy that Application Auto Scaling uses to adjust your application resources.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-applicationautoscaling-scalingpolicy.html">the AWS Docs</a>
*/
export declare type ScalingPolicy = ScalingPolicyProperties;
export declare function scalingPolicy(scalingPolicyProps: ScalingPolicyProperties): ScalingPolicy;
/**
  The <code>AWS::ApplicationAutoScaling::ScalingPolicy</code> resource defines a scaling policy that Application Auto Scaling uses to adjust your application resources.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-applicationautoscaling-scalingpolicy.html">the AWS Docs</a>
*/
export interface ScalingPolicyProperties extends KloudResource {
    /** <code>PolicyName</code>  <a name="cfn-applicationautoscaling-scalingpolicy-policyname"></a>
  The name of the scaling policy.<br />
  
  Required: Yes<br />
  
  Minimum: <code>1</code><br />
  
  Maximum: <code>256</code><br />
  
  Pattern: <code>\p{Print}+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    policyName: Value<string>;
    /** <code>PolicyType</code>  <a name="cfn-applicationautoscaling-scalingpolicy-policytype"></a>
  The Application Auto Scaling policy type.<br />
  The following policy types are supported:<br />
  <code>TargetTrackingScaling</code>—Not supported for Amazon EMR<br />
  <code>StepScaling</code>—Not supported for DynamoDB, Amazon Comprehend, Lambda, or Amazon Keyspaces (for Apache Cassandra)<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    policyType: Value<string>;
    /** <p> */
    resourceId?: Value<string>;
    /** <p> */
    scalableDimension?: Value<string>;
    /** <code>ScalingTargetId</code>  <a name="cfn-applicationautoscaling-scalingpolicy-scalingtargetid"></a>
  The AWS CloudFormation-generated ID of an Application Auto Scaling scalable target. For more information about the ID, see the Return Value section of the <code>AWS::ApplicationAutoScaling::ScalableTarget</code> resource.<br />
  You must specify either the <code>ScalingTargetId</code> property, or the <code>ResourceId</code>, <code>ScalableDimension</code>, and <code>ServiceNamespace</code> properties, but not both.
  
  Required: Conditional<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    scalingTargetId?: Value<string>;
    /** <code>ServiceNamespace</code>  <a name="cfn-applicationautoscaling-scalingpolicy-servicenamespace"></a>
  The namespace of the AWS service that provides the resource, or a <code>custom-resource</code>.<br />
  
  Required: No<br />
  
  Allowed values: <code>appstream | cassandra | comprehend | custom-resource | dynamodb | ec2 | ecs | elasticmapreduce | kafka | lambda | rds | sagemaker</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    serviceNamespace?: Value<'appstream' | 'cassandra' | 'comprehend' | 'custom-resource' | 'dynamodb' | 'ec2' | 'ecs' | 'elasticmapreduce' | 'kafka' | 'lambda' | 'rds' | 'sagemaker'>;
    /** <code>StepScalingPolicyConfiguration</code>  <a name="cfn-applicationautoscaling-scalingpolicy-stepscalingpolicyconfiguration"></a>
  A step scaling policy.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    stepScalingPolicyConfiguration?: StepScalingPolicyConfigurationProps;
    /** <code>TargetTrackingScalingPolicyConfiguration</code>  <a name="cfn-applicationautoscaling-scalingpolicy-targettrackingscalingpolicyconfiguration"></a>
  A target tracking scaling policy.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    targetTrackingScalingPolicyConfiguration?: TargetTrackingScalingPolicyConfigurationProps;
}
