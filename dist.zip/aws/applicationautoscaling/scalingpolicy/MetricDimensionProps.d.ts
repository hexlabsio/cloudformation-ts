import { Value } from '../../../kloudformation/Value';
/**
  <code>MetricDimension</code> is a subproperty of <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationautoscaling-scalingpolicy-customizedmetricspecification.html">CustomizedMetricSpecification</a> that specifies the dimensions of a metric for a target tracking scaling policy. Dimensions are arbitrary name/value pairs that can be associated with a CloudWatch metric. Duplicate dimensions are not allowed.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationautoscaling-scalingpolicy-metricdimension.html">the AWS Docs</a>
*/
export interface MetricDimensionProps {
    /** <code>Name</code>  <a name="cfn-applicationautoscaling-scalingpolicy-metricdimension-name"></a>
  The name of the dimension.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    name: Value<string>;
    /** <code>Value</code>  <a name="cfn-applicationautoscaling-scalingpolicy-metricdimension-value"></a>
  The value of the dimension.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    value: Value<string>;
}
