import { Value } from '../../../kloudformation/Value';
import { StepAdjustmentProps } from './StepAdjustmentProps';
/**
  <code>StepScalingPolicyConfiguration</code> is a property of <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-applicationautoscaling-scalingpolicy.html">ScalingPolicy</a> that specifies a step scaling policy configuration to use with Application Auto Scaling.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationautoscaling-scalingpolicy-stepscalingpolicyconfiguration.html">the AWS Docs</a>
*/
export interface StepScalingPolicyConfigurationProps {
    /** <code>AdjustmentType</code>  <a name="cfn-applicationautoscaling-scalingpolicy-stepscalingpolicyconfiguration-adjustmenttype"></a>
  Specifies whether the <code>ScalingAdjustment</code> value in the <code>StepAdjustment</code> property is an absolute number or a percentage of the current capacity.<br />
  
  Required: No<br />
  
  Allowed values: <code>ChangeInCapacity | ExactCapacity | PercentChangeInCapacity</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    adjustmentType?: Value<'ChangeInCapacity' | 'ExactCapacity' | 'PercentChangeInCapacity'>;
    /** <p> */
    cooldown?: Value<number>;
    /** <code>MetricAggregationType</code>  <a name="cfn-applicationautoscaling-scalingpolicy-stepscalingpolicyconfiguration-metricaggregationtype"></a>
  The aggregation type for the CloudWatch metrics. Valid values are <code>Minimum</code>, <code>Maximum</code>, and <code>Average</code>. If the aggregation type is null, the value is treated as <code>Average</code>.<br />
  
  Required: No<br />
  
  Allowed values: <code>Average | Maximum | Minimum</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    metricAggregationType?: Value<'Average' | 'Maximum' | 'Minimum'>;
    /** <code>MinAdjustmentMagnitude</code>  <a name="cfn-applicationautoscaling-scalingpolicy-stepscalingpolicyconfiguration-minadjustmentmagnitude"></a>
  The minimum value to scale by when the adjustment type is <code>PercentChangeInCapacity</code>. For example, suppose that you create a step scaling policy to scale out an Amazon ECS service by 25 percent and you specify a <code>MinAdjustmentMagnitude</code> of 2. If the service has 4 tasks and the scaling policy is performed, 25 percent of 4 is 1. However, because you specified a <code>MinAdjustmentMagnitude</code> of 2, Application Auto Scaling scales out the service by 2 tasks.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    minAdjustmentMagnitude?: Value<number>;
    /** <code>StepAdjustments</code>  <a name="cfn-applicationautoscaling-scalingpolicy-stepscalingpolicyconfiguration-stepadjustments"></a>
  A set of adjustments that enable you to scale based on the size of the alarm breach.<br />
  At least one step adjustment is required if you are adding a new step scaling policy configuration.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    stepAdjustments?: StepAdjustmentProps[];
}
