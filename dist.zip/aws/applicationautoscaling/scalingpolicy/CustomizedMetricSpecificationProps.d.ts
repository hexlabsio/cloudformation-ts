import { MetricDimensionProps } from './MetricDimensionProps';
import { Value } from '../../../kloudformation/Value';
/**
  <code>CustomizedMetricSpecification</code> is a subproperty of <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationautoscaling-scalingpolicy-targettrackingscalingpolicyconfiguration.html">TargetTrackingScalingPolicyConfiguration</a> that configures a customized metric for a target tracking scaling policy to use with Application Auto Scaling.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationautoscaling-scalingpolicy-customizedmetricspecification.html">the AWS Docs</a>
*/
export interface CustomizedMetricSpecificationProps {
    /** <code>Dimensions</code>  <a name="cfn-applicationautoscaling-scalingpolicy-customizedmetricspecification-dimensions"></a>
  The dimensions of the metric.<br />
  Conditional: If you published your metric with dimensions, you must specify the same dimensions in your scaling policy.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    dimensions?: MetricDimensionProps[];
    /** <code>MetricName</code>  <a name="cfn-applicationautoscaling-scalingpolicy-customizedmetricspecification-metricname"></a>
  The name of the metric.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    metricName: Value<string>;
    /** <code>Namespace</code>  <a name="cfn-applicationautoscaling-scalingpolicy-customizedmetricspecification-namespace"></a>
  The namespace of the metric.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    namespace: Value<string>;
    /** <code>Statistic</code>  <a name="cfn-applicationautoscaling-scalingpolicy-customizedmetricspecification-statistic"></a>
  The statistic of the metric.<br />
  
  Required: Yes<br />
  
  Allowed values: <code>Average | Maximum | Minimum | SampleCount | Sum</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    statistic: Value<'Average' | 'Maximum' | 'Minimum' | 'SampleCount' | 'Sum'>;
    /** <code>Unit</code>  <a name="cfn-applicationautoscaling-scalingpolicy-customizedmetricspecification-unit"></a>
  The unit of the metric.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    unit?: Value<string>;
}
