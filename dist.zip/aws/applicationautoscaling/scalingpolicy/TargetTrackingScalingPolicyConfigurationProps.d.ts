import { CustomizedMetricSpecificationProps } from './CustomizedMetricSpecificationProps';
import { Value } from '../../../kloudformation/Value';
import { PredefinedMetricSpecificationProps } from './PredefinedMetricSpecificationProps';
/**
  <code>TargetTrackingScalingPolicyConfiguration</code> is a property of <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-applicationautoscaling-scalingpolicy.html">ScalingPolicy</a> that specifies a target tracking scaling policy to use with Application Auto Scaling. Use a target tracking scaling policy to adjust the capacity of the specified scalable target in response to actual workloads, so that resource utilization remains at or near the target utilization value.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationautoscaling-scalingpolicy-targettrackingscalingpolicyconfiguration.html">the AWS Docs</a>
*/
export interface TargetTrackingScalingPolicyConfigurationProps {
    /** <code>CustomizedMetricSpecification</code>  <a name="cfn-applicationautoscaling-scalingpolicy-targettrackingscalingpolicyconfiguration-customizedmetricspecification"></a>
  A customized metric. You can specify either a predefined metric or a customized metric.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    customizedMetricSpecification?: CustomizedMetricSpecificationProps;
    /** <code>DisableScaleIn</code>  <a name="cfn-applicationautoscaling-scalingpolicy-targettrackingscalingpolicyconfiguration-disablescalein"></a>
  Indicates whether scale in by the target tracking scaling policy is disabled. If the value is <code>true</code>, scale in is disabled and the target tracking scaling policy won’t remove capacity from the scalable target. Otherwise, scale in is enabled and the target tracking scaling policy can remove capacity from the scalable target. The default value is <code>false</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    disableScaleIn?: Value<boolean>;
    /** <code>PredefinedMetricSpecification</code>  <a name="cfn-applicationautoscaling-scalingpolicy-targettrackingscalingpolicyconfiguration-predefinedmetricspecification"></a>
  A predefined metric. You can specify either a predefined metric or a customized metric.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    predefinedMetricSpecification?: PredefinedMetricSpecificationProps;
    /** <code>ScaleInCooldown</code>  <a name="cfn-applicationautoscaling-scalingpolicy-targettrackingscalingpolicyconfiguration-scaleincooldown"></a>
  The amount of time, in seconds, after a scale-in activity completes before another scale-in activity can start.<br />
  With the
  scale-in cooldown period: the intention is to scale in conservatively to protect your application’s availability, so scale-in activities are blocked until the cooldown period has expired. However, if another alarm triggers a scale-out activity during the scale-in cooldown period, Application Auto Scaling scales out the target immediately. In this case, the scale-in cooldown period stops and doesn’t complete.<br />
  Application Auto Scaling provides a default value of 300 for the following scalable targets: */
    scaleInCooldown?: Value<number>;
    /** <code>ScaleOutCooldown</code>  <a name="cfn-applicationautoscaling-scalingpolicy-targettrackingscalingpolicyconfiguration-scaleoutcooldown"></a>
  The amount of time, in seconds, to wait for a previous scale-out activity to take effect.<br />
  With the
  scale-out cooldown period: the intention is to continuously (but not excessively) scale out. After Application Auto Scaling successfully scales out using a target tracking scaling policy, it starts to calculate the cooldown time. The scaling policy won’t increase the desired capacity again unless either a larger scale out is triggered or the cooldown period ends. While the cooldown period is in effect, the capacity added by the initiating scale-out activity is calculated as part of the desired capacity for the next scale-out activity.<br />
  Application Auto Scaling provides a default value of 300 for the following scalable targets: */
    scaleOutCooldown?: Value<number>;
    /** <code>TargetValue</code>  <a name="cfn-applicationautoscaling-scalingpolicy-targettrackingscalingpolicyconfiguration-targetvalue"></a>
  The target value for the metric.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    targetValue: Value<number>;
}
