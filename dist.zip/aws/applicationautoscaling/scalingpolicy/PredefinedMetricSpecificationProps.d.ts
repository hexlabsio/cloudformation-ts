import { Value } from '../../../kloudformation/Value';
/**
  <code>PredefinedMetricSpecification</code> is a subproperty of <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationautoscaling-scalingpolicy-targettrackingscalingpolicyconfiguration.html">TargetTrackingScalingPolicyConfiguration</a> that configures a predefined metric for a target tracking scaling policy to use with Application Auto Scaling.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-applicationautoscaling-scalingpolicy-predefinedmetricspecification.html">the AWS Docs</a>
*/
export interface PredefinedMetricSpecificationProps {
    /** <code>PredefinedMetricType</code>  <a name="cfn-applicationautoscaling-scalingpolicy-predefinedmetricspecification-predefinedmetrictype"></a>
  The metric type. The <code>ALBRequestCountPerTarget</code> metric type applies only to Spot fleet requests and ECS services.<br />
  
  Required: Yes<br />
  
  Allowed values: <code>ALBRequestCountPerTarget | AppStreamAverageCapacityUtilization | CassandraReadCapacityUtilization | CassandraWriteCapacityUtilization | ComprehendInferenceUtilization | DynamoDBReadCapacityUtilization | DynamoDBWriteCapacityUtilization | EC2SpotFleetRequestAverageCPUUtilization | EC2SpotFleetRequestAverageNetworkIn | EC2SpotFleetRequestAverageNetworkOut | ECSServiceAverageCPUUtilization | ECSServiceAverageMemoryUtilization | KafkaBrokerStorageUtilization | LambdaProvisionedConcurrencyUtilization | RDSReaderAverageCPUUtilization | RDSReaderAverageDatabaseConnections | SageMakerVariantInvocationsPerInstance</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    predefinedMetricType: Value<'ALBRequestCountPerTarget' | 'AppStreamAverageCapacityUtilization' | 'CassandraReadCapacityUtilization' | 'CassandraWriteCapacityUtilization' | 'ComprehendInferenceUtilization' | 'DynamoDBReadCapacityUtilization' | 'DynamoDBWriteCapacityUtilization' | 'EC2SpotFleetRequestAverageCPUUtilization' | 'EC2SpotFleetRequestAverageNetworkIn' | 'EC2SpotFleetRequestAverageNetworkOut' | 'ECSServiceAverageCPUUtilization' | 'ECSServiceAverageMemoryUtilization' | 'KafkaBrokerStorageUtilization' | 'LambdaProvisionedConcurrencyUtilization' | 'RDSReaderAverageCPUUtilization' | 'RDSReaderAverageDatabaseConnections' | 'SageMakerVariantInvocationsPerInstance'>;
    /** <p> */
    resourceLabel?: Value<string>;
}
