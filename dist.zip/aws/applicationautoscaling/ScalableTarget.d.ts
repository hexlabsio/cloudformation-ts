import { Value } from '../../kloudformation/Value';
import { ScheduledActionProps } from './scalabletarget/ScheduledActionProps';
import { SuspendedStateProps } from './scalabletarget/SuspendedStateProps';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::ApplicationAutoScaling::ScalableTarget</code> resource specifies a resource that Application Auto Scaling can scale, such as an AWS::DynamoDB::Table or AWS::ECS::Service resource.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-applicationautoscaling-scalabletarget.html">the AWS Docs</a>
*/
export declare type ScalableTarget = ScalableTargetProperties;
export declare function scalableTarget(scalableTargetProps: ScalableTargetProperties): ScalableTarget;
/**
  The <code>AWS::ApplicationAutoScaling::ScalableTarget</code> resource specifies a resource that Application Auto Scaling can scale, such as an AWS::DynamoDB::Table or AWS::ECS::Service resource.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-applicationautoscaling-scalabletarget.html">the AWS Docs</a>
*/
export interface ScalableTargetProperties extends KloudResource {
    /** <code>MaxCapacity</code>  <a name="cfn-applicationautoscaling-scalabletarget-maxcapacity"></a>
  The maximum value that you plan to scale out to. When a scaling policy is in effect, Application Auto Scaling can scale out (expand) as needed to the maximum capacity limit in response to changing demand.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    maxCapacity: Value<number>;
    /** <code>MinCapacity</code>  <a name="cfn-applicationautoscaling-scalabletarget-mincapacity"></a>
  The minimum value that you plan to scale in to. When a scaling policy is in effect, Application Auto Scaling can scale in (contract) as needed to the minimum capacity limit in response to changing demand.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    minCapacity: Value<number>;
    /** <p> */
    resourceId: Value<string>;
    /** <code>RoleARN</code>  <a name="cfn-applicationautoscaling-scalabletarget-rolearn"></a>
  Specify the Amazon Resource Name (ARN) of an AWS Identity and Access Management (IAM) role that allows Application Auto Scaling to modify the scalable target on your behalf. This can be either an IAM service role that Application Auto Scaling can assume to make calls to other AWS resources on your behalf, or a service-linked role for the specified service. For more information, see <a href="https://docs.aws.amazon.com/autoscaling/application/userguide/security_iam_service-with-iam.html">How Application Auto Scaling works with IAM</a> in the
  Application Auto Scaling User Guide: Look for the ARN in the table at the bottom of the page.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    roleARN: Value<string>;
    /** <p> */
    scalableDimension: Value<string>;
    /** <code>ScheduledActions</code>  <a name="cfn-applicationautoscaling-scalabletarget-scheduledactions"></a>
  The scheduled actions for the scalable target. Duplicates aren’t allowed.<br />
  For more information about using scheduled scaling, see <a href="https://docs.aws.amazon.com/autoscaling/application/userguide/application-auto-scaling-scheduled-scaling.html">Scheduled scaling</a> in the
  Application Auto Scaling User Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    scheduledActions?: ScheduledActionProps[];
    /** <code>ServiceNamespace</code>  <a name="cfn-applicationautoscaling-scalabletarget-servicenamespace"></a>
  The namespace of the AWS service that provides the resource, or a <code>custom-resource</code>.<br />
  
  Required: Yes<br />
  
  Allowed values: <code>appstream | cassandra | comprehend | custom-resource | dynamodb | ec2 | ecs | elasticmapreduce | kafka | lambda | rds | sagemaker</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    serviceNamespace: Value<'appstream' | 'cassandra' | 'comprehend' | 'custom-resource' | 'dynamodb' | 'ec2' | 'ecs' | 'elasticmapreduce' | 'kafka' | 'lambda' | 'rds' | 'sagemaker'>;
    /** <p> */
    suspendedState?: SuspendedStateProps;
}
