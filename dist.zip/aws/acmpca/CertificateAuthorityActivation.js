"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  The <code>AWS::ACMPCA::CertificateAuthorityActivation</code> resource creates and installs a CA certificate on a CA. If no status is specified, the <code>AWS::ACMPCA::CertificateAuthorityActivation</code> resource status defaults to ACTIVE. Once the CA has a CA certificate installed, you can use the resource to toggle the CA status field between ACTIVE and DISABLED.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-acmpca-certificateauthorityactivation.html">the AWS Docs</a>
*/
function certificateAuthorityActivation(certificateAuthorityActivationProps) { return ({ ...certificateAuthorityActivationProps, _logicalType: 'AWS::ACMPCA::CertificateAuthorityActivation', attributes: { CompleteCertificateChain: 'CompleteCertificateChain' } }); }
exports.certificateAuthorityActivation = certificateAuthorityActivation;
