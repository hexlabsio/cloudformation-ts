"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  The <code>AWS::ACMPCA::Certificate</code> resource is used to issue a certificate using your private certificate authority. For more information, see the <a href="https://docs.aws.amazon.com/acm-pca/latest/APIReference/API_IssueCertificate.html">IssueCertificate</a> action.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-acmpca-certificate.html">the AWS Docs</a>
*/
function certificate(certificateProps) { return ({ ...certificateProps, _logicalType: 'AWS::ACMPCA::Certificate', attributes: { Certificate: 'Certificate', Arn: 'Arn' } }); }
exports.certificate = certificate;
