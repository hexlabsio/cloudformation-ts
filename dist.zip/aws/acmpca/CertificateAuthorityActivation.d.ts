import { Value } from '../../kloudformation/Value';
import { Attribute } from '../../kloudformation/Attribute';
import { KloudResource } from '../../kloudformation/KloudResource';
export declare type CertificateAuthorityActivationAttributes = {
    CompleteCertificateChain: Attribute<string>;
};
export declare type CertificateAuthorityActivation = CertificateAuthorityActivationProperties & {
    attributes: CertificateAuthorityActivationAttributes;
};
/**
  The <code>AWS::ACMPCA::CertificateAuthorityActivation</code> resource creates and installs a CA certificate on a CA. If no status is specified, the <code>AWS::ACMPCA::CertificateAuthorityActivation</code> resource status defaults to ACTIVE. Once the CA has a CA certificate installed, you can use the resource to toggle the CA status field between ACTIVE and DISABLED.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-acmpca-certificateauthorityactivation.html">the AWS Docs</a>
*/
export declare function certificateAuthorityActivation(certificateAuthorityActivationProps: CertificateAuthorityActivationProperties): CertificateAuthorityActivation;
/**
  The <code>AWS::ACMPCA::CertificateAuthorityActivation</code> resource creates and installs a CA certificate on a CA. If no status is specified, the <code>AWS::ACMPCA::CertificateAuthorityActivation</code> resource status defaults to ACTIVE. Once the CA has a CA certificate installed, you can use the resource to toggle the CA status field between ACTIVE and DISABLED.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-acmpca-certificateauthorityactivation.html">the AWS Docs</a>
*/
export interface CertificateAuthorityActivationProperties extends KloudResource {
    /** <code>CertificateAuthorityArn</code>  <a name="cfn-acmpca-certificateauthorityactivation-certificateauthorityarn"></a>
  The Amazon Resource Name (ARN) of your private CA.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    certificateAuthorityArn: Value<string>;
    /** <code>Certificate</code>  <a name="cfn-acmpca-certificateauthorityactivation-certificate"></a>
  The Base64 PEM-encoded certificate authority certificate.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    certificate: Value<string>;
    /** <code>CertificateChain</code>  <a name="cfn-acmpca-certificateauthorityactivation-certificatechain"></a>
  The Base64 PEM-encoded certificate chain that chains up to the root CA certificate that you used to sign your private CA certificate.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    certificateChain?: Value<string>;
    /** <code>Status</code>  <a name="cfn-acmpca-certificateauthorityactivation-status"></a>
  Status of your private CA.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    status?: Value<string>;
}
