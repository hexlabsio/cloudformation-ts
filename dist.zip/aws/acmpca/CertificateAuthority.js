"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  Use the <code>AWS::ACMPCA::CertificateAuthority</code> resource to create a private CA. Once the CA exists, you can use the <code>AWS::ACMPCA::Certificate</code> resource to issue a new CA certificate. Alternatively, you can issue a CA certificate using an on-premises CA, and then use the <code>AWS::ACMPCA::CertificateAuthorityActivation</code> resource to import the new CA certificate and activate the CA.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-acmpca-certificateauthority.html">the AWS Docs</a>
*/
function certificateAuthority(certificateAuthorityProps) { return ({ ...certificateAuthorityProps, _logicalType: 'AWS::ACMPCA::CertificateAuthority', attributes: { Arn: 'Arn', CertificateSigningRequest: 'CertificateSigningRequest' } }); }
exports.certificateAuthority = certificateAuthority;
