import { Value } from '../../kloudformation/Value';
import { SubjectProps } from './certificateauthority/SubjectProps';
import { RevocationConfigurationProps } from './certificateauthority/RevocationConfigurationProps';
import { Tag } from '../Tag';
import { CsrExtensionsProps } from './certificateauthority/CsrExtensionsProps';
import { Attribute } from '../../kloudformation/Attribute';
import { KloudResource } from '../../kloudformation/KloudResource';
export declare type CertificateAuthorityAttributes = {
    Arn: Attribute<string>;
    CertificateSigningRequest: Attribute<string>;
};
export declare type CertificateAuthority = CertificateAuthorityProperties & {
    attributes: CertificateAuthorityAttributes;
};
/**
  Use the <code>AWS::ACMPCA::CertificateAuthority</code> resource to create a private CA. Once the CA exists, you can use the <code>AWS::ACMPCA::Certificate</code> resource to issue a new CA certificate. Alternatively, you can issue a CA certificate using an on-premises CA, and then use the <code>AWS::ACMPCA::CertificateAuthorityActivation</code> resource to import the new CA certificate and activate the CA.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-acmpca-certificateauthority.html">the AWS Docs</a>
*/
export declare function certificateAuthority(certificateAuthorityProps: CertificateAuthorityProperties): CertificateAuthority;
/**
  Use the <code>AWS::ACMPCA::CertificateAuthority</code> resource to create a private CA. Once the CA exists, you can use the <code>AWS::ACMPCA::Certificate</code> resource to issue a new CA certificate. Alternatively, you can issue a CA certificate using an on-premises CA, and then use the <code>AWS::ACMPCA::CertificateAuthorityActivation</code> resource to import the new CA certificate and activate the CA.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-acmpca-certificateauthority.html">the AWS Docs</a>
*/
export interface CertificateAuthorityProperties extends KloudResource {
    /** <code>Type</code>  <a name="cfn-acmpca-certificateauthority-type"></a>
  Type of your private CA.<br />
  
  Required: Yes<br />
  
  Allowed values: <code>ROOT | SUBORDINATE</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    type: Value<'ROOT' | 'SUBORDINATE'>;
    /** <code>KeyAlgorithm</code>  <a name="cfn-acmpca-certificateauthority-keyalgorithm"></a>
  Type of the public key algorithm and size, in bits, of the key pair that your CA creates when it issues a certificate. When you create a subordinate CA, you must use a key algorithm supported by the parent CA.<br />
  
  Required: Yes<br />
  
  Allowed values: <code>EC_prime256v1 | EC_secp384r1 | RSA_2048 | RSA_4096</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    keyAlgorithm: Value<'EC_prime256v1' | 'EC_secp384r1' | 'RSA_2048' | 'RSA_4096'>;
    /** <code>SigningAlgorithm</code>  <a name="cfn-acmpca-certificateauthority-signingalgorithm"></a>
  Name of the algorithm your private CA uses to sign certificate requests.<br />
  This parameter should not be confused with the <code>SigningAlgorithm</code> parameter used to sign certificates when they are issued.<br />
  
  Required: Yes<br />
  
  Allowed values: <code>SHA256WITHECDSA | SHA256WITHRSA | SHA384WITHECDSA | SHA384WITHRSA | SHA512WITHECDSA | SHA512WITHRSA</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    signingAlgorithm: Value<'SHA256WITHECDSA' | 'SHA256WITHRSA' | 'SHA384WITHECDSA' | 'SHA384WITHRSA' | 'SHA512WITHECDSA' | 'SHA512WITHRSA'>;
    /** <code>Subject</code>  <a name="cfn-acmpca-certificateauthority-subject"></a>
  Structure that contains X.500 distinguished name information for your private CA.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    subject: SubjectProps;
    /** <code>RevocationConfiguration</code>  <a name="cfn-acmpca-certificateauthority-revocationconfiguration"></a>
  Information about the certificate revocation list (CRL) created and maintained by your private CA. Certificate revocation information used by the CreateCertificateAuthority and UpdateCertificateAuthority actions. Your certificate authority can create and maintain a certificate revocation list (CRL). A CRL contains information about certificates that have been revoked.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    revocationConfiguration?: RevocationConfigurationProps;
    /** <code>Tags</code>  <a name="cfn-acmpca-certificateauthority-tags"></a>
  Key-value pairs that will be attached to the new private CA. You can associate up to 50 tags with a private CA. For information using tags with IAM to manage permissions, see <a href="https://docs.aws.amazon.com/IAM/latest/UserGuide/access_iam-tags.html">Controlling Access Using IAM Tags</a>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: Tag[];
    /** <code>CsrExtensions</code>  <a name="cfn-acmpca-certificateauthority-csrextensions"></a>
  Specifies information to be added to the extension section of the certificate signing request (CSR).<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    csrExtensions?: CsrExtensionsProps;
}
