import { ApiPassthroughProps } from './certificate/ApiPassthroughProps';
import { Value } from '../../kloudformation/Value';
import { ValidityProps } from './certificate/ValidityProps';
import { Attribute } from '../../kloudformation/Attribute';
import { KloudResource } from '../../kloudformation/KloudResource';
export declare type CertificateAttributes = {
    Certificate: Attribute<string>;
    Arn: Attribute<string>;
};
export declare type Certificate = CertificateProperties & {
    attributes: CertificateAttributes;
};
/**
  The <code>AWS::ACMPCA::Certificate</code> resource is used to issue a certificate using your private certificate authority. For more information, see the <a href="https://docs.aws.amazon.com/acm-pca/latest/APIReference/API_IssueCertificate.html">IssueCertificate</a> action.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-acmpca-certificate.html">the AWS Docs</a>
*/
export declare function certificate(certificateProps: CertificateProperties): Certificate;
/**
  The <code>AWS::ACMPCA::Certificate</code> resource is used to issue a certificate using your private certificate authority. For more information, see the <a href="https://docs.aws.amazon.com/acm-pca/latest/APIReference/API_IssueCertificate.html">IssueCertificate</a> action.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-acmpca-certificate.html">the AWS Docs</a>
*/
export interface CertificateProperties extends KloudResource {
    /** <code>ApiPassthrough</code>  <a name="cfn-acmpca-certificate-apipassthrough"></a>
  Specifies X.509 certificate information to be included in the issued certificate. An <code>APIPassthrough</code> or <code>APICSRPassthrough</code> template variant must be selected, or else this parameter is ignored.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    apiPassthrough?: ApiPassthroughProps;
    /** <code>CertificateAuthorityArn</code>  <a name="cfn-acmpca-certificate-certificateauthorityarn"></a>
  The Amazon Resource Name (ARN) for the private CA used to issue the certificate.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    certificateAuthorityArn: Value<string>;
    /** <code>CertificateSigningRequest</code>  <a name="cfn-acmpca-certificate-certificatesigningrequest"></a>
  The certificate signing request (CSR) for the certificate.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    certificateSigningRequest: Value<string>;
    /** <code>SigningAlgorithm</code>  <a name="cfn-acmpca-certificate-signingalgorithm"></a>
  The name of the algorithm that will be used to sign the certificate to be issued.<br />
  This parameter should not be confused with the <code>SigningAlgorithm</code> parameter used to sign a CSR in the <code>CreateCertificateAuthority</code> action.<br />
  
  Required: Yes<br />
  
  Allowed values: <code>SHA256WITHECDSA | SHA256WITHRSA | SHA384WITHECDSA | SHA384WITHRSA | SHA512WITHECDSA | SHA512WITHRSA</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    signingAlgorithm: Value<'SHA256WITHECDSA' | 'SHA256WITHRSA' | 'SHA384WITHECDSA' | 'SHA384WITHRSA' | 'SHA512WITHECDSA' | 'SHA512WITHRSA'>;
    /** <code>TemplateArn</code>  <a name="cfn-acmpca-certificate-templatearn"></a>
  Specifies a custom configuration template to use when issuing a certificate. If this parameter is not provided, ACM Private CA defaults to the <code>EndEntityCertificate/V1</code> template. For more information about ACM Private CA templates, see <a href="https://docs.aws.amazon.com/acm-pca/latest/userguide/UsingTemplates.html">Using Templates</a>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    templateArn?: Value<string>;
    /** <code>Validity</code>  <a name="cfn-acmpca-certificate-validity"></a>
  The period of time during which the certificate will be valid.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    validity: ValidityProps;
    /** <code>ValidityNotBefore</code>  <a name="cfn-acmpca-certificate-validitynotbefore"></a>
  Information describing the start of the validity period of the certificate. This parameter sets the “Not Before” date for the certificate.<br />
  By default, when issuing a certificate, ACM Private CA sets the “Not Before” date to the issuance time minus 60 minutes. This compensates for clock inconsistencies across computer systems. The <code>ValidityNotBefore</code> parameter can be used to customize the “Not Before” value.<br />
  Unlike the <code>Validity</code> parameter, the <code>ValidityNotBefore</code> parameter is optional.<br />
  The <code>ValidityNotBefore</code> value is expressed as an explicit date and time, using the <code>Validity</code> type value <code>ABSOLUTE</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    validityNotBefore?: ValidityProps;
}
