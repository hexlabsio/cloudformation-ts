import { Value } from '../../../kloudformation/Value';
/**
  Contains configuration information for a certificate revocation list (CRL). Your private certificate authority (CA) creates base CRLs. Delta CRLs are not supported. You can enable CRLs for your new or an existing private CA by setting the <strong>Enabled</strong> parameter to <code>true</code>. Your private CA writes CRLs to an S3 bucket that you specify in the <strong>S3BucketName</strong> parameter. You can hide the name of your bucket by specifying a value for the <strong>CustomCname</strong> parameter. Your private CA copies the CNAME or the S3 bucket name to the <strong>CRL Distribution Points</strong> extension of each certificate it issues. Your S3 bucket policy must give write permission to ACM Private CA.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-acmpca-certificateauthority-crlconfiguration.html">the AWS Docs</a>
*/
export interface CrlConfigurationProps {
    /** <code>Enabled</code>  <a name="cfn-acmpca-certificateauthority-crlconfiguration-enabled"></a>
  Boolean value that specifies whether certificate revocation lists (CRLs) are enabled. You can use this value to enable certificate revocation for a new CA when you call the <code>CreateCertificateAuthority</code> operation or for an existing CA when you call the <code>UpdateCertificateAuthority</code> operation.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    enabled?: Value<boolean>;
    /** <code>ExpirationInDays</code>  <a name="cfn-acmpca-certificateauthority-crlconfiguration-expirationindays"></a>
  Validity period of the CRL in days.<br />
  
  Required: No<br />
  
  Minimum: <code>1</code><br />
  
  Maximum: <code>5000</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    expirationInDays?: Value<number>;
    /** <code>CustomCname</code>  <a name="cfn-acmpca-certificateauthority-crlconfiguration-customcname"></a>
  Name inserted into the certificate <strong>CRL Distribution Points</strong> extension that enables the use of an alias for the CRL distribution point. Use this value if you don’t want the name of your S3 bucket to be public.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>253</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    customCname?: Value<string>;
    /** <code>S3BucketName</code>  <a name="cfn-acmpca-certificateauthority-crlconfiguration-s3bucketname"></a>
  Name of the S3 bucket that contains the CRL. If you do not provide a value for the <strong>CustomCname</strong> argument, the name of your S3 bucket is placed into the <strong>CRL Distribution Points</strong> extension of the issued certificate. You can change the name of your bucket by calling the <code>UpdateCertificateAuthority</code> operation. You must specify a bucket policy that allows ACM PCA to write the CRL to your bucket.<br />
  
  Required: No<br />
  
  Minimum: <code>3</code><br />
  
  Maximum: <code>255</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    s3BucketName?: Value<string>;
}
