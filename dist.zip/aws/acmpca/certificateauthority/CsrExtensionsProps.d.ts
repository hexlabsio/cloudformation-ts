import { KeyUsageProps } from './KeyUsageProps';
import { AccessDescriptionProps } from './AccessDescriptionProps';
/**
  Describes the certificate extensions to be added to the certificate signing request (CSR).
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-acmpca-certificateauthority-csrextensions.html">the AWS Docs</a>
*/
export interface CsrExtensionsProps {
    /** <code>KeyUsage</code>  <a name="cfn-acmpca-certificateauthority-csrextensions-keyusage"></a>
  Indicates the purpose of the certificate and of the key contained in the certificate.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    keyUsage?: KeyUsageProps;
    /** <code>SubjectInformationAccess</code>  <a name="cfn-acmpca-certificateauthority-csrextensions-subjectinformationaccess"></a>
  For CA certificates, provides a path to additional information pertaining to the CA, such as revocation and policy. For more information, see <a href="https://tools.ietf.org/html/rfc5280#section-4.2.2.2">Subject Information Access</a> in RFC 5280.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    subjectInformationAccess?: AccessDescriptionProps[];
}
