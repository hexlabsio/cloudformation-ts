import { Value } from '../../../kloudformation/Value';
/**
  Defines a custom ASN.1 X.400 <code>GeneralName</code> using an object identifier (OID) and value. The OID must satisfy the regular expression shown below. For more information, see NIST’s definition of <a href="https://csrc.nist.gov/glossary/term/Object_Identifier">Object Identifier (OID)</a>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-acmpca-certificateauthority-othername.html">the AWS Docs</a>
*/
export interface OtherNameProps {
    /** <code>TypeId</code>  <a name="cfn-acmpca-certificateauthority-othername-typeid"></a>
  Specifies an OID.<br />
  
  Required: Yes<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>64</code><br />
  
  Pattern: <code>^([0-2])\.([0-9]|([0-3][0-9]))((\.([0-9]+)){0,126})$</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    typeId: Value<string>;
    /** <code>Value</code>  <a name="cfn-acmpca-certificateauthority-othername-value"></a>
  Specifies an OID value.<br />
  
  Required: Yes<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>256</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    value: Value<string>;
}
