import { Value } from '../../../kloudformation/Value';
/**
  Describes an Electronic Data Interchange (EDI) entity as described in as defined in <a href="https://tools.ietf.org/html/rfc5280">Subject Alternative Name</a> in RFC 5280.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-acmpca-certificateauthority-edipartyname.html">the AWS Docs</a>
*/
export interface EdiPartyNameProps {
    /** <code>PartyName</code>  <a name="cfn-acmpca-certificateauthority-edipartyname-partyname"></a>
  Specifies the party name.<br />
  
  Required: Yes<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>256</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    partyName: Value<string>;
    /** <code>NameAssigner</code>  <a name="cfn-acmpca-certificateauthority-edipartyname-nameassigner"></a>
  Specifies the name assigner.<br />
  
  Required: Yes<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>256</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    nameAssigner: Value<string>;
}
