import { AccessMethodProps } from './AccessMethodProps';
import { GeneralNameProps } from './GeneralNameProps';
/**
  Provides access information used by the <code>authorityInfoAccess</code> and <code>subjectInfoAccess</code> extensions described in <a href="https://tools.ietf.org/html/rfc5280">RFC 5280</a>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-acmpca-certificateauthority-accessdescription.html">the AWS Docs</a>
*/
export interface AccessDescriptionProps {
    /** <code>AccessMethod</code>  <a name="cfn-acmpca-certificateauthority-accessdescription-accessmethod"></a>
  The type and format of <code>AccessDescription</code> information.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    accessMethod: AccessMethodProps;
    /** <code>AccessLocation</code>  <a name="cfn-acmpca-certificateauthority-accessdescription-accesslocation"></a>
  The location of <code>AccessDescription</code> information.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    accessLocation: GeneralNameProps;
}
