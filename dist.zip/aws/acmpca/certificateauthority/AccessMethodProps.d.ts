import { Value } from '../../../kloudformation/Value';
/**
  Describes the type and format of extension access. Only one of <code>CustomObjectIdentifier</code> or <code>AccessMethodType</code> may be provided. Providing both results in <code>InvalidArgsException</code>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-acmpca-certificateauthority-accessmethod.html">the AWS Docs</a>
*/
export interface AccessMethodProps {
    /** <code>CustomObjectIdentifier</code>  <a name="cfn-acmpca-certificateauthority-accessmethod-customobjectidentifier"></a>
  An object identifier (OID) specifying the <code>AccessMethod</code>. The OID must satisfy the regular expression shown below. For more information, see NIST’s definition of <a href="https://csrc.nist.gov/glossary/term/Object_Identifier">Object Identifier (OID)</a>.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>64</code><br />
  
  Pattern: <code>^([0-2])\.([0-9]|([0-3][0-9]))((\.([0-9]+)){0,126})$</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    customObjectIdentifier?: Value<string>;
    /** <code>AccessMethodType</code>  <a name="cfn-acmpca-certificateauthority-accessmethod-accessmethodtype"></a>
  Specifies the <code>AccessMethod</code>.<br />
  
  Required: No<br />
  
  Allowed values: <code>CA_REPOSITORY | RESOURCE_PKI_MANIFEST | RESOURCE_PKI_NOTIFY</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    accessMethodType?: Value<'CA_REPOSITORY' | 'RESOURCE_PKI_MANIFEST' | 'RESOURCE_PKI_NOTIFY'>;
}
