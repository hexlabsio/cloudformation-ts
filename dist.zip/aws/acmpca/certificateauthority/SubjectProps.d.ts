import { Value } from '../../../kloudformation/Value';
/**
  ASN1 subject for the certificate authority.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-acmpca-certificateauthority-subject.html">the AWS Docs</a>
*/
export interface SubjectProps {
    /** <code>Country</code>  <a name="cfn-acmpca-certificateauthority-subject-country"></a>
  Two-digit code that specifies the country in which the certificate subject located.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    country?: Value<string>;
    /** <code>Organization</code>  <a name="cfn-acmpca-certificateauthority-subject-organization"></a>
  Legal name of the organization with which the certificate subject is affiliated.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    organization?: Value<string>;
    /** <code>OrganizationalUnit</code>  <a name="cfn-acmpca-certificateauthority-subject-organizationalunit"></a>
  A subdivision or unit of the organization (such as sales or finance) with which the certificate subject is affiliated.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    organizationalUnit?: Value<string>;
    /** <code>DistinguishedNameQualifier</code>  <a name="cfn-acmpca-certificateauthority-subject-distinguishednamequalifier"></a>
  Disambiguating information for the certificate subject.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    distinguishedNameQualifier?: Value<string>;
    /** <code>State</code>  <a name="cfn-acmpca-certificateauthority-subject-state"></a>
  State in which the subject of the certificate is located.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    state?: Value<string>;
    /** <code>CommonName</code>  <a name="cfn-acmpca-certificateauthority-subject-commonname"></a>
  Fully qualified domain name (FQDN) associated with the certificate subject.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    commonName?: Value<string>;
    /** <code>SerialNumber</code>  <a name="cfn-acmpca-certificateauthority-subject-serialnumber"></a>
  The certificate serial number.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    serialNumber?: Value<string>;
    /** <code>Locality</code>  <a name="cfn-acmpca-certificateauthority-subject-locality"></a>
  The locality (such as a city or town) in which the certificate subject is located.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    locality?: Value<string>;
    /** <code>Title</code>  <a name="cfn-acmpca-certificateauthority-subject-title"></a>
  A personal title such as Mr.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    title?: Value<string>;
    /** <code>Surname</code>  <a name="cfn-acmpca-certificateauthority-subject-surname"></a>
  Family name.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    surname?: Value<string>;
    /** <code>GivenName</code>  <a name="cfn-acmpca-certificateauthority-subject-givenname"></a>
  First name.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    givenName?: Value<string>;
    /** <code>Initials</code>  <a name="cfn-acmpca-certificateauthority-subject-initials"></a>
  Concatenation that typically contains the first letter of the GivenName, the first letter of the middle name if one exists, and the first letter of the SurName.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    initials?: Value<string>;
    /** <code>Pseudonym</code>  <a name="cfn-acmpca-certificateauthority-subject-pseudonym"></a>
  Typically a shortened version of a longer GivenName. For example, Jonathan is often shortened to John. Elizabeth is often shortened to Beth, Liz, or Eliza.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    pseudonym?: Value<string>;
    /** <code>GenerationQualifier</code>  <a name="cfn-acmpca-certificateauthority-subject-generationqualifier"></a>
  Typically a qualifier appended to the name of an individual. Examples include Jr. for junior, Sr. for senior, and III for third.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    generationQualifier?: Value<string>;
}
