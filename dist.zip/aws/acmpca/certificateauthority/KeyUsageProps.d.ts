import { Value } from '../../../kloudformation/Value';
/**
  Defines one or more purposes for which the key contained in the certificate can be used. Default value for each option is false.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-acmpca-certificateauthority-keyusage.html">the AWS Docs</a>
*/
export interface KeyUsageProps {
    /** <code>DigitalSignature</code>  <a name="cfn-acmpca-certificateauthority-keyusage-digitalsignature"></a>
  Key can be used for digital signing.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    digitalSignature?: Value<boolean>;
    /** <code>NonRepudiation</code>  <a name="cfn-acmpca-certificateauthority-keyusage-nonrepudiation"></a>
  Key can be used for non-repudiation.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    nonRepudiation?: Value<boolean>;
    /** <code>KeyEncipherment</code>  <a name="cfn-acmpca-certificateauthority-keyusage-keyencipherment"></a>
  Key can be used to encipher data.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    keyEncipherment?: Value<boolean>;
    /** <code>DataEncipherment</code>  <a name="cfn-acmpca-certificateauthority-keyusage-dataencipherment"></a>
  Key can be used to decipher data.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    dataEncipherment?: Value<boolean>;
    /** <code>KeyAgreement</code>  <a name="cfn-acmpca-certificateauthority-keyusage-keyagreement"></a>
  Key can be used in a key-agreement protocol.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    keyAgreement?: Value<boolean>;
    /** <code>KeyCertSign</code>  <a name="cfn-acmpca-certificateauthority-keyusage-keycertsign"></a>
  Key can be used to sign certificates.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    keyCertSign?: Value<boolean>;
    /** <code>CRLSign</code>  <a name="cfn-acmpca-certificateauthority-keyusage-crlsign"></a>
  Key can be used to sign CRLs.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    cRLSign?: Value<boolean>;
    /** <code>EncipherOnly</code>  <a name="cfn-acmpca-certificateauthority-keyusage-encipheronly"></a>
  Key can be used only to encipher data.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    encipherOnly?: Value<boolean>;
    /** <code>DecipherOnly</code>  <a name="cfn-acmpca-certificateauthority-keyusage-decipheronly"></a>
  Key can be used only to decipher data.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    decipherOnly?: Value<boolean>;
}
