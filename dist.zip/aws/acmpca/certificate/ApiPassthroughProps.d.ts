import { ExtensionsProps } from './ExtensionsProps';
import { SubjectProps } from './SubjectProps';
/**
  Contains X.509 certificate information to be placed in an issued certificate. An <code>APIPassthrough</code> or <code>APICSRPassthrough</code> template variant must be selected, or else this parameter is ignored.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-acmpca-certificate-apipassthrough.html">the AWS Docs</a>
*/
export interface ApiPassthroughProps {
    /** <code>Extensions</code>  <a name="cfn-acmpca-certificate-apipassthrough-extensions"></a>
  Specifies X.509 extension information for a certificate.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    extensions?: ExtensionsProps;
    /** <code>Subject</code>  <a name="cfn-acmpca-certificate-apipassthrough-subject"></a>
  Contains information about the certificate subject. The Subject field in the certificate identifies the entity that owns or controls the public key in the certificate. The entity can be a user, computer, device, or service. The Subject must contain an X.500 distinguished name (DN). A DN is a sequence of relative distinguished names (RDNs). The RDNs are separated by commas in the certificate.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    subject?: SubjectProps;
}
