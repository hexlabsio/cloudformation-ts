import { Value } from '../../../kloudformation/Value';
import { PolicyQualifierInfoProps } from './PolicyQualifierInfoProps';
/**
  Defines the X.509 <code>CertificatePolicies</code> extension.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-acmpca-certificate-policyinformation.html">the AWS Docs</a>
*/
export interface PolicyInformationProps {
    /** <code>CertPolicyId</code>  <a name="cfn-acmpca-certificate-policyinformation-certpolicyid"></a>
  Specifies the object identifier (OID) of the certificate policy under which the certificate was issued. For more information, see NIST’s definition of <a href="https://csrc.nist.gov/glossary/term/Object_Identifier">Object Identifier (OID)</a>.<br />
  
  Required: Yes<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>64</code><br />
  
  Pattern: <code>^([0-2])\.([0-9]|([0-3][0-9]))((\.([0-9]+)){0,126})$</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    certPolicyId: Value<string>;
    /** <code>PolicyQualifiers</code>  <a name="cfn-acmpca-certificate-policyinformation-policyqualifiers"></a>
  Modifies the given <code>CertPolicyId</code> with a qualifier. ACM Private CA supports the certification practice statement (CPS) qualifier.<br />
  
  Required: No<br />
  
  Maximum: <code>20</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    policyQualifiers?: PolicyQualifierInfoProps[];
}
