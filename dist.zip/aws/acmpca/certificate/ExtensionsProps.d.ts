import { PolicyInformationProps } from './PolicyInformationProps';
import { ExtendedKeyUsageProps } from './ExtendedKeyUsageProps';
import { KeyUsageProps } from './KeyUsageProps';
import { GeneralNameProps } from './GeneralNameProps';
/**
  Contains X.509 extension information for a certificate.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-acmpca-certificate-extensions.html">the AWS Docs</a>
*/
export interface ExtensionsProps {
    /** <code>CertificatePolicies</code>  <a name="cfn-acmpca-certificate-extensions-certificatepolicies"></a>
  Contains a sequence of one or more policy information terms, each of which consists of an object identifier (OID) and optional qualifiers. For more information, see NIST’s definition of <a href="https://csrc.nist.gov/glossary/term/Object_Identifier">Object Identifier (OID)</a>.<br />
  In an end-entity certificate, these terms indicate the policy under which the certificate was issued and the purposes for which it may be used. In a CA certificate, these terms limit the set of policies for certification paths that include this certificate.<br />
  
  Required: No<br />
  
  Maximum: <code>20</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    certificatePolicies?: PolicyInformationProps[];
    /** <code>ExtendedKeyUsage</code>  <a name="cfn-acmpca-certificate-extensions-extendedkeyusage"></a>
  Specifies additional purposes for which the certified public key may be used other than basic purposes indicated in the <code>KeyUsage</code> extension.<br />
  
  Required: No<br />
  
  Maximum: <code>20</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    extendedKeyUsage?: ExtendedKeyUsageProps[];
    /** <code>KeyUsage</code>  <a name="cfn-acmpca-certificate-extensions-keyusage"></a>
  Defines one or more purposes for which the key contained in the certificate can be used. Default value for each option is false.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    keyUsage?: KeyUsageProps;
    /** <code>SubjectAlternativeNames</code>  <a name="cfn-acmpca-certificate-extensions-subjectalternativenames"></a>
  The subject alternative name extension allows identities to be bound to the subject of the certificate. These identities may be included in addition to or in place of the identity in the subject field of the certificate.<br />
  
  Required: No<br />
  
  Maximum: <code>20</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    subjectAlternativeNames?: GeneralNameProps[];
}
