import { OtherNameProps } from './OtherNameProps';
import { Value } from '../../../kloudformation/Value';
import { SubjectProps } from './SubjectProps';
import { EdiPartyNameProps } from './EdiPartyNameProps';
/**
  Describes an ASN.1 X.400 <code>GeneralName</code> as defined in <a href="https://tools.ietf.org/html/rfc5280">RFC 5280</a>. Only one of the following naming options should be provided. Providing more than one option results in an <code>InvalidArgsException</code> error.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-acmpca-certificate-generalname.html">the AWS Docs</a>
*/
export interface GeneralNameProps {
    /** <code>OtherName</code>  <a name="cfn-acmpca-certificate-generalname-othername"></a>
  Represents <code>GeneralName</code> using an <code>OtherName</code> object.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    otherName?: OtherNameProps;
    /** <code>Rfc822Name</code>  <a name="cfn-acmpca-certificate-generalname-rfc822name"></a>
  Represents <code>GeneralName</code> as an <a href="https://tools.ietf.org/html/rfc822">RFC 822</a> email address.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>256</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    rfc822Name?: Value<string>;
    /** <code>DnsName</code>  <a name="cfn-acmpca-certificate-generalname-dnsname"></a>
  Represents <code>GeneralName</code> as a DNS name.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>253</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    dnsName?: Value<string>;
    /** <code>DirectoryName</code>  <a name="cfn-acmpca-certificate-generalname-directoryname"></a>
  Contains information about the certificate subject. The certificate can be one issued by your private certificate authority (CA) or it can be your private CA certificate. The Subject field in the certificate identifies the entity that owns or controls the public key in the certificate. The entity can be a user, computer, device, or service. The Subject must contain an X.500 distinguished name (DN). A DN is a sequence of relative distinguished names (RDNs). The RDNs are separated by commas in the certificate. The DN must be unique for each entity, but your private CA can issue more than one certificate with the same DN to the same entity.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    directoryName?: SubjectProps;
    /** <code>EdiPartyName</code>  <a name="cfn-acmpca-certificate-generalname-edipartyname"></a>
  Represents <code>GeneralName</code> as an <code>EdiPartyName</code> object.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    ediPartyName?: EdiPartyNameProps;
    /** <code>UniformResourceIdentifier</code>  <a name="cfn-acmpca-certificate-generalname-uniformresourceidentifier"></a>
  Represents <code>GeneralName</code> as a URI.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>253</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    uniformResourceIdentifier?: Value<string>;
    /** <code>IpAddress</code>  <a name="cfn-acmpca-certificate-generalname-ipaddress"></a>
  Represents <code>GeneralName</code> as an IPv4 or IPv6 address.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>39</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    ipAddress?: Value<string>;
    /** <code>RegisteredId</code>  <a name="cfn-acmpca-certificate-generalname-registeredid"></a>
  Represents <code>GeneralName</code> as an object identifier (OID).<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>64</code><br />
  
  Pattern: <code>^([0-2])\.([0-9]|([0-3][0-9]))((\.([0-9]+)){0,126})$</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    registeredId?: Value<string>;
}
