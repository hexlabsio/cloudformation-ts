import { Value } from '../../../kloudformation/Value';
/**
  Length of time for which the certificate issued by your private certificate authority (CA), or by the private CA itself, is valid in days, months, or years. You can issue a certificate by calling the <code>IssueCertificate</code> operation.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-acmpca-certificate-validity.html">the AWS Docs</a>
*/
export interface ValidityProps {
    /** <code>Value</code>  <a name="cfn-acmpca-certificate-validity-value"></a>
  A long integer interpreted according to the value of <code>Type</code>, below.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    value: Value<number>;
    /** <code>Type</code>  <a name="cfn-acmpca-certificate-validity-type"></a>
  Specifies whether the <code>Value</code> parameter represents days, months, or years.<br />
  
  Required: Yes<br />
  
  Allowed values: <code>ABSOLUTE | DAYS | END_DATE | MONTHS | YEARS</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    type: Value<'ABSOLUTE' | 'DAYS' | 'END_DATE' | 'MONTHS' | 'YEARS'>;
}
