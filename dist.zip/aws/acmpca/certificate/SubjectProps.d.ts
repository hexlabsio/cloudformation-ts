import { Value } from '../../../kloudformation/Value';
/**
  Contains information about the certificate subject. The <code>Subject</code> field in the certificate identifies the entity that owns or controls the public key in the certificate. The entity can be a user, computer, device, or service. The <code>Subject </code>must contain an X.500 distinguished name (DN). A DN is a sequence of relative distinguished names (RDNs). The RDNs are separated by commas in the certificate.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-acmpca-certificate-subject.html">the AWS Docs</a>
*/
export interface SubjectProps {
    /** <code>Country</code>  <a name="cfn-acmpca-certificate-subject-country"></a>
  Two-digit code that specifies the country in which the certificate subject located.<br />
  
  Required: No<br />
  
  Minimum: <code>2</code><br />
  
  Maximum: <code>2</code><br />
  
  Pattern: <code>[A-Za-z]{2}</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    country?: Value<string>;
    /** <code>Organization</code>  <a name="cfn-acmpca-certificate-subject-organization"></a>
  Legal name of the organization with which the certificate subject is affiliated.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>64</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    organization?: Value<string>;
    /** <code>OrganizationalUnit</code>  <a name="cfn-acmpca-certificate-subject-organizationalunit"></a>
  A subdivision or unit of the organization (such as sales or finance) with which the certificate subject is affiliated.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>64</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    organizationalUnit?: Value<string>;
    /** <code>DistinguishedNameQualifier</code>  <a name="cfn-acmpca-certificate-subject-distinguishednamequalifier"></a>
  Disambiguating information for the certificate subject.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>64</code><br />
  
  Pattern: <code>[a-zA-Z0-9'()+-.?:/= ]*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    distinguishedNameQualifier?: Value<string>;
    /** <code>State</code>  <a name="cfn-acmpca-certificate-subject-state"></a>
  State in which the subject of the certificate is located.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>128</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    state?: Value<string>;
    /** <code>CommonName</code>  <a name="cfn-acmpca-certificate-subject-commonname"></a>
  For CA and end-entity certificates in a private PKI, the common name (CN) can be any string within the length limit.<br />
  Note: In publicly trusted certificates, the common name must be a fully qualified domain name (FQDN) associated with the certificate subject.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>64</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    commonName?: Value<string>;
    /** <code>SerialNumber</code>  <a name="cfn-acmpca-certificate-subject-serialnumber"></a>
  The certificate serial number.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>64</code><br />
  
  Pattern: <code>[a-zA-Z0-9'()+-.?:/= ]*</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    serialNumber?: Value<string>;
    /** <code>Locality</code>  <a name="cfn-acmpca-certificate-subject-locality"></a>
  The locality (such as a city or town) in which the certificate subject is located.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>128</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    locality?: Value<string>;
    /** <code>Title</code>  <a name="cfn-acmpca-certificate-subject-title"></a>
  A title such as Mr. or Ms., which is pre-pended to the name to refer formally to the certificate subject.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>64</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    title?: Value<string>;
    /** <code>Surname</code>  <a name="cfn-acmpca-certificate-subject-surname"></a>
  Family name. In the US and the UK, for example, the surname of an individual is ordered last. In Asian cultures the surname is typically ordered first.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>40</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    surname?: Value<string>;
    /** <code>GivenName</code>  <a name="cfn-acmpca-certificate-subject-givenname"></a>
  First name.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>16</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    givenName?: Value<string>;
    /** <code>Initials</code>  <a name="cfn-acmpca-certificate-subject-initials"></a>
  Concatenation that typically contains the first letter of the <strong>GivenName</strong>, the first letter of the middle name if one exists, and the first letter of the <strong>Surname</strong>.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>5</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    initials?: Value<string>;
    /** <code>Pseudonym</code>  <a name="cfn-acmpca-certificate-subject-pseudonym"></a>
  Typically a shortened version of a longer <strong>GivenName</strong>. For example, Jonathan is often shortened to John. Elizabeth is often shortened to Beth, Liz, or Eliza.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>128</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    pseudonym?: Value<string>;
    /** <code>GenerationQualifier</code>  <a name="cfn-acmpca-certificate-subject-generationqualifier"></a>
  Typically a qualifier appended to the name of an individual. Examples include Jr. for junior, Sr. for senior, and III for third.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>3</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    generationQualifier?: Value<string>;
}
