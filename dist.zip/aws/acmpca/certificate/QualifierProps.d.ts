import { Value } from '../../../kloudformation/Value';
/**
  Defines a <code>PolicyInformation</code> qualifier. ACM Private CA supports the <a href="https://tools.ietf.org/html/rfc5280#section-4.2.1.4">certification practice statement (CPS) qualifier</a> defined in RFC 5280.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-acmpca-certificate-qualifier.html">the AWS Docs</a>
*/
export interface QualifierProps {
    /** <code>CpsUri</code>  <a name="cfn-acmpca-certificate-qualifier-cpsuri"></a>
  Contains a pointer to a certification practice statement (CPS) published by the CA.<br />
  
  Required: Yes<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>256</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    cpsUri: Value<string>;
}
