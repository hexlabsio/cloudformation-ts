import { Value } from '../../../kloudformation/Value';
import { QualifierProps } from './QualifierProps';
/**
  Modifies the <code>CertPolicyId</code> of a <code>PolicyInformation</code> object with a qualifier. ACM Private CA supports the certification practice statement (CPS) qualifier.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-acmpca-certificate-policyqualifierinfo.html">the AWS Docs</a>
*/
export interface PolicyQualifierInfoProps {
    /** <code>PolicyQualifierId</code>  <a name="cfn-acmpca-certificate-policyqualifierinfo-policyqualifierid"></a>
  Identifies the qualifier modifying a <code>CertPolicyId</code>.<br />
  
  Required: Yes<br />
  
  Allowed values: <code>CPS</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    policyQualifierId: Value<'CPS'>;
    /** <code>Qualifier</code>  <a name="cfn-acmpca-certificate-policyqualifierinfo-qualifier"></a>
  Defines the qualifier type. ACM Private CA supports the use of a URI for a CPS qualifier in this field.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    qualifier: QualifierProps;
}
