import { Value } from '../../../kloudformation/Value';
/**
  Specifies additional purposes for which the certified public key may be used other than basic purposes indicated in the <code>KeyUsage</code> extension.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-acmpca-certificate-extendedkeyusage.html">the AWS Docs</a>
*/
export interface ExtendedKeyUsageProps {
    /** <code>ExtendedKeyUsageType</code>  <a name="cfn-acmpca-certificate-extendedkeyusage-extendedkeyusagetype"></a>
  Specifies a standard <code>ExtendedKeyUsage</code> as defined as in <a href="https://tools.ietf.org/html/rfc5280#section-4.2.1.12">RFC 5280</a>.<br />
  
  Required: No<br />
  
  Allowed values: <code>CERTIFICATE_TRANSPARENCY | CLIENT_AUTH | CODE_SIGNING | DOCUMENT_SIGNING | EMAIL_PROTECTION | OCSP_SIGNING | SERVER_AUTH | SMART_CARD_LOGIN | TIME_STAMPING</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    extendedKeyUsageType?: Value<'CERTIFICATE_TRANSPARENCY' | 'CLIENT_AUTH' | 'CODE_SIGNING' | 'DOCUMENT_SIGNING' | 'EMAIL_PROTECTION' | 'OCSP_SIGNING' | 'SERVER_AUTH' | 'SMART_CARD_LOGIN' | 'TIME_STAMPING'>;
    /** <code>ExtendedKeyUsageObjectIdentifier</code>  <a name="cfn-acmpca-certificate-extendedkeyusage-extendedkeyusageobjectidentifier"></a>
  Specifies a custom <code>ExtendedKeyUsage</code> with an object identifier (OID).<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>64</code><br />
  
  Pattern: <code>^([0-2])\.([0-9]|([0-3][0-9]))((\.([0-9]+)){0,126})$</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    extendedKeyUsageObjectIdentifier?: Value<string>;
}
