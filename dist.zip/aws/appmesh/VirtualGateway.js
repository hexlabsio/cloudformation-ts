"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  Creates a virtual gateway.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appmesh-virtualgateway.html">the AWS Docs</a>
*/
function virtualGateway(virtualGatewayProps) { return ({ ...virtualGatewayProps, _logicalType: 'AWS::AppMesh::VirtualGateway', attributes: { Uid: 'Uid', VirtualGatewayName: 'VirtualGatewayName', MeshName: 'MeshName', MeshOwner: 'MeshOwner', ResourceOwner: 'ResourceOwner', Arn: 'Arn' } }); }
exports.virtualGateway = virtualGateway;
