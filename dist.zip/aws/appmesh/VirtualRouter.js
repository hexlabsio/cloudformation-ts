"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  Creates a virtual router within a service mesh.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appmesh-virtualrouter.html">the AWS Docs</a>
*/
function virtualRouter(virtualRouterProps) { return ({ ...virtualRouterProps, _logicalType: 'AWS::AppMesh::VirtualRouter', attributes: { Uid: 'Uid', MeshName: 'MeshName', VirtualRouterName: 'VirtualRouterName', MeshOwner: 'MeshOwner', ResourceOwner: 'ResourceOwner', Arn: 'Arn' } }); }
exports.virtualRouter = virtualRouter;
