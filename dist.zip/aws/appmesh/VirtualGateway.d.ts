import { Value } from '../../kloudformation/Value';
import { VirtualGatewaySpecProps } from './virtualgateway/VirtualGatewaySpecProps';
import { Tag } from '../Tag';
import { Attribute } from '../../kloudformation/Attribute';
import { KloudResource } from '../../kloudformation/KloudResource';
export declare type VirtualGatewayAttributes = {
    Uid: Attribute<string>;
    VirtualGatewayName: Attribute<string>;
    MeshName: Attribute<string>;
    MeshOwner: Attribute<string>;
    ResourceOwner: Attribute<string>;
    Arn: Attribute<string>;
};
export declare type VirtualGateway = VirtualGatewayProperties & {
    attributes: VirtualGatewayAttributes;
};
/**
  Creates a virtual gateway.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appmesh-virtualgateway.html">the AWS Docs</a>
*/
export declare function virtualGateway(virtualGatewayProps: VirtualGatewayProperties): VirtualGateway;
/**
  Creates a virtual gateway.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appmesh-virtualgateway.html">the AWS Docs</a>
*/
export interface VirtualGatewayProperties extends KloudResource {
    /** <code>VirtualGatewayName</code>  <a name="cfn-appmesh-virtualgateway-virtualgatewayname"></a>
  The name of the virtual gateway.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    virtualGatewayName?: Value<string>;
    /** <code>MeshName</code>  <a name="cfn-appmesh-virtualgateway-meshname"></a>
  The name of the service mesh that the virtual gateway resides in.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    meshName: Value<string>;
    /** <code>MeshOwner</code>  <a name="cfn-appmesh-virtualgateway-meshowner"></a>
  The AWS IAM account ID of the service mesh owner. If the account ID is not your own, then it’s the ID of the account that shared the mesh with your account. For more information about mesh sharing, see <a href="https://docs.aws.amazon.com/app-mesh/latest/userguide/sharing.html">Working with shared meshes</a>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    meshOwner?: Value<string>;
    /** <code>Spec</code>  <a name="cfn-appmesh-virtualgateway-spec"></a>
  The specifications of the virtual gateway.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    spec: VirtualGatewaySpecProps;
    /** <code>Tags</code>  <a name="cfn-appmesh-virtualgateway-tags"></a>
  Optional metadata that you can apply to the virtual gateway to assist with categorization and organization. Each tag consists of a key and an optional value, both of which you define. Tag keys can have a maximum character length of 128 characters, and tag values can have a maximum length of 256 characters.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: Tag[];
}
