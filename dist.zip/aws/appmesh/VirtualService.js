"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  Creates a virtual service within a service mesh.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appmesh-virtualservice.html">the AWS Docs</a>
*/
function virtualService(virtualServiceProps) { return ({ ...virtualServiceProps, _logicalType: 'AWS::AppMesh::VirtualService', attributes: { Uid: 'Uid', MeshName: 'MeshName', MeshOwner: 'MeshOwner', ResourceOwner: 'ResourceOwner', VirtualServiceName: 'VirtualServiceName', Arn: 'Arn' } }); }
exports.virtualService = virtualService;
