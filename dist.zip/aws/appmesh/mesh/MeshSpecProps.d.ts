import { EgressFilterProps } from './EgressFilterProps';
/**
  An object that represents the specification of a service mesh.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appmesh-mesh-meshspec.html">the AWS Docs</a>
*/
export interface MeshSpecProps {
    /** <code>EgressFilter</code>  <a name="cfn-appmesh-mesh-meshspec-egressfilter"></a>
  The egress filter rules for the service mesh.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    egressFilter?: EgressFilterProps;
}
