"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  Creates a gateway route.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appmesh-gatewayroute.html">the AWS Docs</a>
*/
function gatewayRoute(gatewayRouteProps) { return ({ ...gatewayRouteProps, _logicalType: 'AWS::AppMesh::GatewayRoute', attributes: { Uid: 'Uid', MeshName: 'MeshName', VirtualGatewayName: 'VirtualGatewayName', MeshOwner: 'MeshOwner', ResourceOwner: 'ResourceOwner', GatewayRouteName: 'GatewayRouteName', Arn: 'Arn' } }); }
exports.gatewayRoute = gatewayRoute;
