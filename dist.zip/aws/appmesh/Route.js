"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  Creates a route that is associated with a virtual router.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appmesh-route.html">the AWS Docs</a>
*/
function route(routeProps) { return ({ ...routeProps, _logicalType: 'AWS::AppMesh::Route', attributes: { Uid: 'Uid', MeshName: 'MeshName', VirtualRouterName: 'VirtualRouterName', MeshOwner: 'MeshOwner', ResourceOwner: 'ResourceOwner', RouteName: 'RouteName', Arn: 'Arn' } }); }
exports.route = route;
