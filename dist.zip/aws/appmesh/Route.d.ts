import { Value } from '../../kloudformation/Value';
import { RouteSpecProps } from './route/RouteSpecProps';
import { Tag } from '../Tag';
import { Attribute } from '../../kloudformation/Attribute';
import { KloudResource } from '../../kloudformation/KloudResource';
export declare type RouteAttributes = {
    Uid: Attribute<string>;
    MeshName: Attribute<string>;
    VirtualRouterName: Attribute<string>;
    MeshOwner: Attribute<string>;
    ResourceOwner: Attribute<string>;
    RouteName: Attribute<string>;
    Arn: Attribute<string>;
};
export declare type Route = RouteProperties & {
    attributes: RouteAttributes;
};
/**
  Creates a route that is associated with a virtual router.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appmesh-route.html">the AWS Docs</a>
*/
export declare function route(routeProps: RouteProperties): Route;
/**
  Creates a route that is associated with a virtual router.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appmesh-route.html">the AWS Docs</a>
*/
export interface RouteProperties extends KloudResource {
    /** <code>MeshName</code>  <a name="cfn-appmesh-route-meshname"></a>
  The name of the service mesh to create the route in.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    meshName: Value<string>;
    /** <code>VirtualRouterName</code>  <a name="cfn-appmesh-route-virtualroutername"></a>
  The name of the virtual router in which to create the route. If the virtual router is in a shared mesh, then you must be the owner of the virtual router resource.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    virtualRouterName: Value<string>;
    /** <code>MeshOwner</code>  <a name="cfn-appmesh-route-meshowner"></a>
  The AWS IAM account ID of the service mesh owner. If the account ID is not your own, then the account that you specify must share the mesh with your account before you can create the resource in the service mesh. For more information about mesh sharing, see <a href="https://docs.aws.amazon.com/app-mesh/latest/userguide/sharing.html">Working with shared meshes</a>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    meshOwner?: Value<string>;
    /** <code>RouteName</code>  <a name="cfn-appmesh-route-routename"></a>
  The name to use for the route.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    routeName?: Value<string>;
    /** <code>Spec</code>  <a name="cfn-appmesh-route-spec"></a>
  The route specification to apply.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    spec: RouteSpecProps;
    /** <code>Tags</code>  <a name="cfn-appmesh-route-tags"></a>
  Optional metadata that you can apply to the route to assist with categorization and organization. Each tag consists of a key and an optional value, both of which you define. Tag keys can have a maximum character length of 128 characters, and tag values can have a maximum length of 256 characters.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: Tag[];
}
