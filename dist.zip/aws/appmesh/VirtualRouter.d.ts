import { Value } from '../../kloudformation/Value';
import { VirtualRouterSpecProps } from './virtualrouter/VirtualRouterSpecProps';
import { Tag } from '../Tag';
import { Attribute } from '../../kloudformation/Attribute';
import { KloudResource } from '../../kloudformation/KloudResource';
export declare type VirtualRouterAttributes = {
    Uid: Attribute<string>;
    MeshName: Attribute<string>;
    VirtualRouterName: Attribute<string>;
    MeshOwner: Attribute<string>;
    ResourceOwner: Attribute<string>;
    Arn: Attribute<string>;
};
export declare type VirtualRouter = VirtualRouterProperties & {
    attributes: VirtualRouterAttributes;
};
/**
  Creates a virtual router within a service mesh.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appmesh-virtualrouter.html">the AWS Docs</a>
*/
export declare function virtualRouter(virtualRouterProps: VirtualRouterProperties): VirtualRouter;
/**
  Creates a virtual router within a service mesh.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appmesh-virtualrouter.html">the AWS Docs</a>
*/
export interface VirtualRouterProperties extends KloudResource {
    /** <code>MeshName</code>  <a name="cfn-appmesh-virtualrouter-meshname"></a>
  The name of the service mesh to create the virtual router in.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    meshName: Value<string>;
    /** <code>VirtualRouterName</code>  <a name="cfn-appmesh-virtualrouter-virtualroutername"></a>
  The name to use for the virtual router.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    virtualRouterName?: Value<string>;
    /** <code>MeshOwner</code>  <a name="cfn-appmesh-virtualrouter-meshowner"></a>
  The AWS IAM account ID of the service mesh owner. If the account ID is not your own, then the account that you specify must share the mesh with your account before you can create the resource in the service mesh. For more information about mesh sharing, see <a href="https://docs.aws.amazon.com/app-mesh/latest/userguide/sharing.html">Working with shared meshes</a>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    meshOwner?: Value<string>;
    /** <code>Spec</code>  <a name="cfn-appmesh-virtualrouter-spec"></a>
  The virtual router specification to apply.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    spec: VirtualRouterSpecProps;
    /** <code>Tags</code>  <a name="cfn-appmesh-virtualrouter-tags"></a>
  Optional metadata that you can apply to the virtual router to assist with categorization and organization. Each tag consists of a key and an optional value, both of which you define. Tag keys can have a maximum character length of 128 characters, and tag values can have a maximum length of 256 characters.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: Tag[];
}
