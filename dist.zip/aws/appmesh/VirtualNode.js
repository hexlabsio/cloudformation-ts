"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  Creates a virtual node within a service mesh.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appmesh-virtualnode.html">the AWS Docs</a>
*/
function virtualNode(virtualNodeProps) { return ({ ...virtualNodeProps, _logicalType: 'AWS::AppMesh::VirtualNode', attributes: { Uid: 'Uid', MeshName: 'MeshName', MeshOwner: 'MeshOwner', ResourceOwner: 'ResourceOwner', Arn: 'Arn', VirtualNodeName: 'VirtualNodeName' } }); }
exports.virtualNode = virtualNode;
