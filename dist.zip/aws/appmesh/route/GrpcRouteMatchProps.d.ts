import { Value } from '../../../kloudformation/Value';
import { GrpcRouteMetadataProps } from './GrpcRouteMetadataProps';
/**
  An object that represents the criteria for determining a request match.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appmesh-route-grpcroutematch.html">the AWS Docs</a>
*/
export interface GrpcRouteMatchProps {
    /** <code>ServiceName</code>  <a name="cfn-appmesh-route-grpcroutematch-servicename"></a>
  The fully qualified domain name for the service to match from the request.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    serviceName?: Value<string>;
    /** <code>Metadata</code>  <a name="cfn-appmesh-route-grpcroutematch-metadata"></a>
  An object that represents the data to match from the request.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    metadata?: GrpcRouteMetadataProps[];
    /** <code>MethodName</code>  <a name="cfn-appmesh-route-grpcroutematch-methodname"></a>
  The method name to match from the request. If you specify a name, you must also specify a <code>serviceName</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    methodName?: Value<string>;
}
