import { Value } from '../../../kloudformation/Value';
import { DurationProps } from './DurationProps';
/**
  An object that represents a retry policy. Specify at least one value for at least one of the types of <code>RetryEvents</code>, a value for <code>maxRetries</code>, and a value for <code>perRetryTimeout</code>. Both <code>server-error</code> and <code>gateway-error</code> under <code>httpRetryEvents</code> include the Envoy <code>reset</code> policy. For more information on the <code>reset</code> policy, see the <a href="https://www.envoyproxy.io/docs/envoy/latest/configuration/http/http_filters/router_filter#x-envoy-retry-on">Envoy documentation</a>.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appmesh-route-grpcretrypolicy.html">the AWS Docs</a>
*/
export interface GrpcRetryPolicyProps {
    /** <code>MaxRetries</code>  <a name="cfn-appmesh-route-grpcretrypolicy-maxretries"></a>
  The maximum number of retry attempts.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    maxRetries: Value<number>;
    /** <code>PerRetryTimeout</code>  <a name="cfn-appmesh-route-grpcretrypolicy-perretrytimeout"></a>
  The timeout for each retry attempt.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    perRetryTimeout: DurationProps;
    /** <code>GrpcRetryEvents</code>  <a name="cfn-appmesh-route-grpcretrypolicy-grpcretryevents"></a>
  Specify at least one of the valid values.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    grpcRetryEvents?: Value<Value<string>[]>;
    /** <p> */
    httpRetryEvents?: Value<Value<string>[]>;
    /** <code>TcpRetryEvents</code>  <a name="cfn-appmesh-route-grpcretrypolicy-tcpretryevents"></a>
  Specify a valid value. The event occurs before any processing of a request has started and is encountered when the upstream is temporarily or permanently unavailable.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tcpRetryEvents?: Value<Value<string>[]>;
}
