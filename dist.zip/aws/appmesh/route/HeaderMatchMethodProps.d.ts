import { Value } from '../../../kloudformation/Value';
import { MatchRangeProps } from './MatchRangeProps';
/**
  An object that represents the method and value to match with the header value sent in a request. Specify one match method.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appmesh-route-headermatchmethod.html">the AWS Docs</a>
*/
export interface HeaderMatchMethodProps {
    /** <code>Suffix</code>  <a name="cfn-appmesh-route-headermatchmethod-suffix"></a>
  The value sent by the client must end with the specified characters.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    suffix?: Value<string>;
    /** <code>Regex</code>  <a name="cfn-appmesh-route-headermatchmethod-regex"></a>
  The value sent by the client must include the specified characters.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    regex?: Value<string>;
    /** <code>Exact</code>  <a name="cfn-appmesh-route-headermatchmethod-exact"></a>
  The value sent by the client must match the specified value exactly.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    exact?: Value<string>;
    /** <code>Prefix</code>  <a name="cfn-appmesh-route-headermatchmethod-prefix"></a>
  The value sent by the client must begin with the specified characters.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    prefix?: Value<string>;
    /** <code>Range</code>  <a name="cfn-appmesh-route-headermatchmethod-range"></a>
  An object that represents the range of values to match on.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    range?: MatchRangeProps;
}
