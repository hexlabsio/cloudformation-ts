import { Value } from '../../../kloudformation/Value';
import { GrpcRouteMetadataMatchMethodProps } from './GrpcRouteMetadataMatchMethodProps';
/**
  An object that represents the match metadata for the route.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appmesh-route-grpcroutemetadata.html">the AWS Docs</a>
*/
export interface GrpcRouteMetadataProps {
    /** <code>Invert</code>  <a name="cfn-appmesh-route-grpcroutemetadata-invert"></a>
  Specify <code>True</code> to match anything except the match criteria. The default value is <code>False</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    invert?: Value<boolean>;
    /** <code>Name</code>  <a name="cfn-appmesh-route-grpcroutemetadata-name"></a>
  The name of the route.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    name: Value<string>;
    /** <code>Match</code>  <a name="cfn-appmesh-route-grpcroutemetadata-match"></a>
  An object that represents the data to match from the request.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    match?: GrpcRouteMetadataMatchMethodProps;
}
