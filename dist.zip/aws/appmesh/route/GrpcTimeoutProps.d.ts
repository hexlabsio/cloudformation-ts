import { DurationProps } from './DurationProps';
/**
  An object that represents types of timeouts.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appmesh-route-grpctimeout.html">the AWS Docs</a>
*/
export interface GrpcTimeoutProps {
    /** <code>PerRequest</code>  <a name="cfn-appmesh-route-grpctimeout-perrequest"></a>
  An object that represents a per request timeout. The default value is 15 seconds. If you set a higher timeout, then make sure that the higher value is set for each App Mesh resource in a conversation. For example, if a virtual node backend uses a virtual router provider to route to another virtual node, then the timeout should be greater than 15 seconds for the source and destination virtual node and the route.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    perRequest?: DurationProps;
    /** <code>Idle</code>  <a name="cfn-appmesh-route-grpctimeout-idle"></a>
  An object that represents an idle timeout. An idle timeout bounds the amount of time that a connection may be idle. The default value is none.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    idle?: DurationProps;
}
