import { Value } from '../../../kloudformation/Value';
import { MatchRangeProps } from './MatchRangeProps';
/**
  An object that represents the match method. Specify one of the match values.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appmesh-route-grpcroutemetadatamatchmethod.html">the AWS Docs</a>
*/
export interface GrpcRouteMetadataMatchMethodProps {
    /** <code>Suffix</code>  <a name="cfn-appmesh-route-grpcroutemetadatamatchmethod-suffix"></a>
  The value sent by the client must end with the specified characters.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    suffix?: Value<string>;
    /** <code>Regex</code>  <a name="cfn-appmesh-route-grpcroutemetadatamatchmethod-regex"></a>
  The value sent by the client must include the specified characters.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    regex?: Value<string>;
    /** <code>Exact</code>  <a name="cfn-appmesh-route-grpcroutemetadatamatchmethod-exact"></a>
  The value sent by the client must match the specified value exactly.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    exact?: Value<string>;
    /** <code>Prefix</code>  <a name="cfn-appmesh-route-grpcroutemetadatamatchmethod-prefix"></a>
  The value sent by the client must begin with the specified characters.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    prefix?: Value<string>;
    /** <code>Range</code>  <a name="cfn-appmesh-route-grpcroutemetadatamatchmethod-range"></a>
  An object that represents the range of values to match on.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    range?: MatchRangeProps;
}
