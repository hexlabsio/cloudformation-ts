import { GrpcRouteActionProps } from './GrpcRouteActionProps';
import { GrpcTimeoutProps } from './GrpcTimeoutProps';
import { GrpcRetryPolicyProps } from './GrpcRetryPolicyProps';
import { GrpcRouteMatchProps } from './GrpcRouteMatchProps';
/**
  An object that represents a gRPC route type.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appmesh-route-grpcroute.html">the AWS Docs</a>
*/
export interface GrpcRouteProps {
    /** <code>Action</code>  <a name="cfn-appmesh-route-grpcroute-action"></a>
  An object that represents the action to take if a match is determined.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    action: GrpcRouteActionProps;
    /** <code>Timeout</code>  <a name="cfn-appmesh-route-grpcroute-timeout"></a>
  An object that represents types of timeouts.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    timeout?: GrpcTimeoutProps;
    /** <code>RetryPolicy</code>  <a name="cfn-appmesh-route-grpcroute-retrypolicy"></a>
  An object that represents a retry policy.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    retryPolicy?: GrpcRetryPolicyProps;
    /** <code>Match</code>  <a name="cfn-appmesh-route-grpcroute-match"></a>
  An object that represents the criteria for determining a request match.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    match: GrpcRouteMatchProps;
}
