import { Value } from '../../../kloudformation/Value';
/**
  An object that represents a duration of time.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appmesh-route-duration.html">the AWS Docs</a>
*/
export interface DurationProps {
    /** <code>Value</code>  <a name="cfn-appmesh-route-duration-value"></a>
  A number of time units.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    value: Value<number>;
    /** <code>Unit</code>  <a name="cfn-appmesh-route-duration-unit"></a>
  A unit of time.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    unit: Value<string>;
}
