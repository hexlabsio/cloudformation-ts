import { WeightedTargetProps } from './WeightedTargetProps';
/**
  An object that represents the action to take if a match is determined.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appmesh-route-grpcrouteaction.html">the AWS Docs</a>
*/
export interface GrpcRouteActionProps {
    /** <code>WeightedTargets</code>  <a name="cfn-appmesh-route-grpcrouteaction-weightedtargets"></a>
  An object that represents the targets that traffic is routed to when a request matches the route.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    weightedTargets: WeightedTargetProps[];
}
