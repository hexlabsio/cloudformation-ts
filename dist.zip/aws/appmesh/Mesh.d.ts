import { Value } from '../../kloudformation/Value';
import { MeshSpecProps } from './mesh/MeshSpecProps';
import { Tag } from '../Tag';
import { Attribute } from '../../kloudformation/Attribute';
import { KloudResource } from '../../kloudformation/KloudResource';
export declare type MeshAttributes = {
    Uid: Attribute<string>;
    MeshName: Attribute<string>;
    MeshOwner: Attribute<string>;
    ResourceOwner: Attribute<string>;
    Arn: Attribute<string>;
};
export declare type Mesh = MeshProperties & {
    attributes: MeshAttributes;
};
/**
  Creates a service mesh.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appmesh-mesh.html">the AWS Docs</a>
*/
export declare function mesh(meshProps: MeshProperties): Mesh;
/**
  Creates a service mesh.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appmesh-mesh.html">the AWS Docs</a>
*/
export interface MeshProperties extends KloudResource {
    /** <code>MeshName</code>  <a name="cfn-appmesh-mesh-meshname"></a>
  The name to use for the service mesh.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    meshName?: Value<string>;
    /** <code>Spec</code>  <a name="cfn-appmesh-mesh-spec"></a>
  The service mesh specification to apply.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    spec?: MeshSpecProps;
    /** <code>Tags</code>  <a name="cfn-appmesh-mesh-tags"></a>
  Optional metadata that you can apply to the service mesh to assist with categorization and organization. Each tag consists of a key and an optional value, both of which you define. Tag keys can have a maximum character length of 128 characters, and tag values can have a maximum length of 256 characters.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: Tag[];
}
