"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  Creates a service mesh.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appmesh-mesh.html">the AWS Docs</a>
*/
function mesh(meshProps) { return ({ ...meshProps, _logicalType: 'AWS::AppMesh::Mesh', attributes: { Uid: 'Uid', MeshName: 'MeshName', MeshOwner: 'MeshOwner', ResourceOwner: 'ResourceOwner', Arn: 'Arn' } }); }
exports.mesh = mesh;
