import { Value } from '../../../kloudformation/Value';
/**
  An object that represents the virtual service that traffic is routed to.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appmesh-gatewayroute-gatewayroutevirtualservice.html">the AWS Docs</a>
*/
export interface GatewayRouteVirtualServiceProps {
    /** <code>VirtualServiceName</code>  <a name="cfn-appmesh-gatewayroute-gatewayroutevirtualservice-virtualservicename"></a>
  The name of the virtual service that traffic is routed to.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    virtualServiceName: Value<string>;
}
