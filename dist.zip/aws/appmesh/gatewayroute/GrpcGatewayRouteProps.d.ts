import { GrpcGatewayRouteActionProps } from './GrpcGatewayRouteActionProps';
import { GrpcGatewayRouteMatchProps } from './GrpcGatewayRouteMatchProps';
/**
  An object that represents a gRPC gateway route.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appmesh-gatewayroute-grpcgatewayroute.html">the AWS Docs</a>
*/
export interface GrpcGatewayRouteProps {
    /** <code>Action</code>  <a name="cfn-appmesh-gatewayroute-grpcgatewayroute-action"></a>
  An object that represents the action to take if a match is determined.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    action: GrpcGatewayRouteActionProps;
    /** <code>Match</code>  <a name="cfn-appmesh-gatewayroute-grpcgatewayroute-match"></a>
  An object that represents the criteria for determining a request match.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    match: GrpcGatewayRouteMatchProps;
}
