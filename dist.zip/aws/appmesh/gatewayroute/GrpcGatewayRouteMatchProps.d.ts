import { Value } from '../../../kloudformation/Value';
/**
  An object that represents the criteria for determining a request match.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appmesh-gatewayroute-grpcgatewayroutematch.html">the AWS Docs</a>
*/
export interface GrpcGatewayRouteMatchProps {
    /** <code>ServiceName</code>  <a name="cfn-appmesh-gatewayroute-grpcgatewayroutematch-servicename"></a>
  The fully qualified domain name for the service to match from the request.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    serviceName?: Value<string>;
}
