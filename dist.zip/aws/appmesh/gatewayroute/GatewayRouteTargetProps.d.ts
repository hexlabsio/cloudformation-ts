import { GatewayRouteVirtualServiceProps } from './GatewayRouteVirtualServiceProps';
/**
  An object that represents a gateway route target.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appmesh-gatewayroute-gatewayroutetarget.html">the AWS Docs</a>
*/
export interface GatewayRouteTargetProps {
    /** <code>VirtualService</code>  <a name="cfn-appmesh-gatewayroute-gatewayroutetarget-virtualservice"></a>
  An object that represents a virtual service gateway route target.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    virtualService: GatewayRouteVirtualServiceProps;
}
