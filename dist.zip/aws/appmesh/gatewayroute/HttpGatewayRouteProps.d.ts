import { HttpGatewayRouteActionProps } from './HttpGatewayRouteActionProps';
import { HttpGatewayRouteMatchProps } from './HttpGatewayRouteMatchProps';
/**
  An object that represents an HTTP gateway route.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appmesh-gatewayroute-httpgatewayroute.html">the AWS Docs</a>
*/
export interface HttpGatewayRouteProps {
    /** <code>Action</code>  <a name="cfn-appmesh-gatewayroute-httpgatewayroute-action"></a>
  An object that represents the action to take if a match is determined.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    action: HttpGatewayRouteActionProps;
    /** <code>Match</code>  <a name="cfn-appmesh-gatewayroute-httpgatewayroute-match"></a>
  An object that represents the criteria for determining a request match.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    match: HttpGatewayRouteMatchProps;
}
