import { GatewayRouteTargetProps } from './GatewayRouteTargetProps';
/**
  An object that represents the action to take if a match is determined.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appmesh-gatewayroute-grpcgatewayrouteaction.html">the AWS Docs</a>
*/
export interface GrpcGatewayRouteActionProps {
    /** <code>Target</code>  <a name="cfn-appmesh-gatewayroute-grpcgatewayrouteaction-target"></a>
  An object that represents the target that traffic is routed to when a request matches the gateway route.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    target: GatewayRouteTargetProps;
}
