import { Value } from '../../../kloudformation/Value';
/**
  An object that represents the criteria for determining a request match.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appmesh-gatewayroute-httpgatewayroutematch.html">the AWS Docs</a>
*/
export interface HttpGatewayRouteMatchProps {
    /** <code>Prefix</code>  <a name="cfn-appmesh-gatewayroute-httpgatewayroutematch-prefix"></a>
  Specifies the path to match requests with. This parameter must always start with <code>/</code>, which by itself matches all requests to the virtual service name. You can also match for path-based routing of requests. For example, if your virtual service name is <code>my-service.local</code> and you want the route to match requests to <code>my-service.local/metrics</code>, your prefix should be <code>/metrics</code>.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    prefix: Value<string>;
}
