import { HttpGatewayRouteProps } from './HttpGatewayRouteProps';
import { GrpcGatewayRouteProps } from './GrpcGatewayRouteProps';
/**
  An object that represents a gateway route specification. Specify one gateway route type.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appmesh-gatewayroute-gatewayroutespec.html">the AWS Docs</a>
*/
export interface GatewayRouteSpecProps {
    /** <code>HttpRoute</code>  <a name="cfn-appmesh-gatewayroute-gatewayroutespec-httproute"></a>
  An object that represents the specification of an HTTP gateway route.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    httpRoute?: HttpGatewayRouteProps;
    /** <code>Http2Route</code>  <a name="cfn-appmesh-gatewayroute-gatewayroutespec-http2route"></a>
  An object that represents the specification of an HTTP/2 gateway route.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    http2Route?: HttpGatewayRouteProps;
    /** <code>GrpcRoute</code>  <a name="cfn-appmesh-gatewayroute-gatewayroutespec-grpcroute"></a>
  An object that represents the specification of a gRPC gateway route.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    grpcRoute?: GrpcGatewayRouteProps;
}
