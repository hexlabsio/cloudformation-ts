import { Value } from '../../../kloudformation/Value';
/**
  Use the BasicAuthConfig property type to set password protection at an app level to all your branches.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-amplify-app-basicauthconfig.html">the AWS Docs</a>
*/
export interface BasicAuthConfigProps {
    /** <code>Username</code>  <a name="cfn-amplify-app-basicauthconfig-username"></a>
  The user name for basic authorization.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    username?: Value<string>;
    /** <code>EnableBasicAuth</code>  <a name="cfn-amplify-app-basicauthconfig-enablebasicauth"></a>
  Enables basic authorization for the Amplify app’s branches.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    enableBasicAuth?: Value<boolean>;
    /** <code>Password</code>  <a name="cfn-amplify-app-basicauthconfig-password"></a>
  The password for basic authorization.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    password?: Value<string>;
}
