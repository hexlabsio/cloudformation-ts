import { Value } from '../../../kloudformation/Value';
/**
  The CustomRule property type allows you to specify redirects, rewrites, and reverse proxies. Redirects enable a web app to reroute navigation from one URL to another.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-amplify-app-customrule.html">the AWS Docs</a>
*/
export interface CustomRuleProps {
    /** <code>Condition</code>  <a name="cfn-amplify-app-customrule-condition"></a>
  The condition for a URL rewrite or redirect rule, such as a country code.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    condition?: Value<string>;
    /** <code>Status</code>  <a name="cfn-amplify-app-customrule-status"></a>
  The status code for a URL rewrite or redirect rule.<br />
  200<br />
  Represents a 200 rewrite rule.<br />
  301<br />
  Represents a 301 (moved pemanently) redirect rule. This and all future requests should be directed to the target URL.<br />
  302<br />
  Represents a 302 temporary redirect rule.<br />
  404<br />
  Represents a 404 redirect rule.<br />
  404-200<br />
  Represents a 404 rewrite rule.
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    status?: Value<string>;
    /** <code>Target</code>  <a name="cfn-amplify-app-customrule-target"></a>
  The target pattern for a URL rewrite or redirect rule.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    target: Value<string>;
    /** <code>Source</code>  <a name="cfn-amplify-app-customrule-source"></a>
  The source pattern for a URL rewrite or redirect rule.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    source: Value<string>;
}
