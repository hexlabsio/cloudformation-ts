import { EnvironmentVariableProps } from './EnvironmentVariableProps';
import { Value } from '../../../kloudformation/Value';
import { BasicAuthConfigProps } from './BasicAuthConfigProps';
/**
  Use the AutoBranchCreationConfig property type to automatically create branches that match a certain pattern.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-amplify-app-autobranchcreationconfig.html">the AWS Docs</a>
*/
export interface AutoBranchCreationConfigProps {
    /** <code>EnvironmentVariables</code>  <a name="cfn-amplify-app-autobranchcreationconfig-environmentvariables"></a>
  Environment variables for the auto created branch.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    environmentVariables?: EnvironmentVariableProps[];
    /** <code>EnableAutoBranchCreation</code>  <a name="cfn-amplify-app-autobranchcreationconfig-enableautobranchcreation"></a>
  Enables automated branch creation for the Amplify app.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    enableAutoBranchCreation?: Value<boolean>;
    /** <code>PullRequestEnvironmentName</code>  <a name="cfn-amplify-app-autobranchcreationconfig-pullrequestenvironmentname"></a>
  If pull request previews are enabled, you can use this property to specify a dedicated backend environment for your previews. For example, you could specify an environment named <code>prod</code>, <code>test</code>, or <code>dev</code> that you initialized with the Amplify CLI.<br />
  To enable pull request previews, set the <code>EnablePullRequestPreview</code> property to <code>true</code>.<br />
  If you don’t specify an environment, the Amplify Console provides backend support for each preview by automatically provisioning a temporary backend environment. Amplify Console deletes this environment when the pull request is closed.<br />
  For more information about creating backend environments, see <a href="https://docs.aws.amazon.com/amplify/latest/userguide/multi-environments.html">Feature Branch Deployments and Team Workflows</a> in the
  AWS Amplify Console User Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    pullRequestEnvironmentName?: Value<string>;
    /** <code>AutoBranchCreationPatterns</code>  <a name="cfn-amplify-app-autobranchcreationconfig-autobranchcreationpatterns"></a>
  Automated branch creation glob patterns for the Amplify app.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    autoBranchCreationPatterns?: Value<Value<string>[]>;
    /** <code>EnablePullRequestPreview</code>  <a name="cfn-amplify-app-autobranchcreationconfig-enablepullrequestpreview"></a>
  Sets whether pull request previews are enabled for each branch that Amplify Console automatically creates for your app. Amplify Console creates previews by deploying your app to a unique URL whenever a pull request is opened for the branch. Development and QA teams can use this preview to test the pull request before it’s merged into a production or integration branch.<br />
  To provide backend support for your preview, the Amplify Console automatically provisions a temporary backend environment that it deletes when the pull request is closed. If you want to specify a dedicated backend environment for your previews, use the <code>PullRequestEnvironmentName</code> property.<br />
  For more information, see <a href="https://docs.aws.amazon.com/amplify/latest/userguide/pr-previews.html">Web Previews</a> in the
  AWS Amplify Console User Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    enablePullRequestPreview?: Value<boolean>;
    /** <code>EnableAutoBuild</code>  <a name="cfn-amplify-app-autobranchcreationconfig-enableautobuild"></a>
  Enables auto building for the auto created branch.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    enableAutoBuild?: Value<boolean>;
    /** <code>EnablePerformanceMode</code>  <a name="cfn-amplify-app-autobranchcreationconfig-enableperformancemode"></a>
  Enables performance mode for the branch.<br />
  Performance mode optimizes for faster hosting performance by keeping content cached at the edge for a longer interval. When performance mode is enabled, hosting configuration or code changes can take up to 10 minutes to roll out.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    enablePerformanceMode?: Value<boolean>;
    /** <code>BuildSpec</code>  <a name="cfn-amplify-app-autobranchcreationconfig-buildspec"></a>
  Build spec for the auto created branch.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    buildSpec?: Value<string>;
    /** <code>Stage</code>  <a name="cfn-amplify-app-autobranchcreationconfig-stage"></a>
  Stage for the auto created branch.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    stage?: Value<string>;
    /** <code>BasicAuthConfig</code>  <a name="cfn-amplify-app-autobranchcreationconfig-basicauthconfig"></a>
  Sets password protection for your auto created branch.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    basicAuthConfig?: BasicAuthConfigProps;
}
