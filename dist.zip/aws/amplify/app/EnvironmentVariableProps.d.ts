import { Value } from '../../../kloudformation/Value';
/**
  Environment variables are key-value pairs that are available at build time. Set environment variables for all branches in your app.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-amplify-app-environmentvariable.html">the AWS Docs</a>
*/
export interface EnvironmentVariableProps {
    /** <code>Value</code>  <a name="cfn-amplify-app-environmentvariable-value"></a>
  The environment variable value.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    value: Value<string>;
    /** <code>Name</code>  <a name="cfn-amplify-app-environmentvariable-name"></a>
  The environment variable name.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    name: Value<string>;
}
