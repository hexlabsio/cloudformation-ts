import { Value } from '../../kloudformation/Value';
import { EnvironmentVariableProps } from './branch/EnvironmentVariableProps';
import { BasicAuthConfigProps } from './branch/BasicAuthConfigProps';
import { Tag } from '../Tag';
import { Attribute } from '../../kloudformation/Attribute';
import { KloudResource } from '../../kloudformation/KloudResource';
export declare type BranchAttributes = {
    BranchName: Attribute<string>;
    Arn: Attribute<string>;
};
export declare type Branch = BranchProperties & {
    attributes: BranchAttributes;
};
/**
  The AWS::Amplify::Branch resource creates a new branch within an app.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-amplify-branch.html">the AWS Docs</a>
*/
export declare function branch(branchProps: BranchProperties): Branch;
/**
  The AWS::Amplify::Branch resource creates a new branch within an app.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-amplify-branch.html">the AWS Docs</a>
*/
export interface BranchProperties extends KloudResource {
    /** <code>Description</code>  <a name="cfn-amplify-branch-description"></a>
  The description for the branch.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>EnvironmentVariables</code>  <a name="cfn-amplify-branch-environmentvariables"></a>
  The environment variables for the branch.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    environmentVariables?: EnvironmentVariableProps[];
    /** <code>AppId</code>  <a name="cfn-amplify-branch-appid"></a>
  The unique ID for an Amplify app.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    appId: Value<string>;
    /** <code>PullRequestEnvironmentName</code>  <a name="cfn-amplify-branch-pullrequestenvironmentname"></a>
  If pull request previews are enabled for this branch, you can use this property to specify a dedicated backend environment for your previews. For example, you could specify an environment named <code>prod</code>, <code>test</code>, or <code>dev</code> that you initialized with the Amplify CLI and mapped to this branch.<br />
  To enable pull request previews, set the <code>EnablePullRequestPreview</code> property to <code>true</code>.<br />
  If you don’t specify an environment, the Amplify Console provides backend support for each preview by automatically provisioning a temporary backend environment. Amplify Console deletes this environment when the pull request is closed.<br />
  For more information about creating backend environments, see <a href="https://docs.aws.amazon.com/amplify/latest/userguide/multi-environments.html">Feature Branch Deployments and Team Workflows</a> in the
  AWS Amplify Console User Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    pullRequestEnvironmentName?: Value<string>;
    /** <code>EnablePullRequestPreview</code>  <a name="cfn-amplify-branch-enablepullrequestpreview"></a>
  Sets whether the Amplify Console creates a preview for each pull request that is made for this branch. If this property is enabled, the Amplify Console deploys your app to a unique preview URL after each pull request is opened. Development and QA teams can use this preview to test the pull request before it’s merged into a production or integration branch.<br />
  To provide backend support for your preview, the Amplify Console automatically provisions a temporary backend environment that it deletes when the pull request is closed. If you want to specify a dedicated backend environment for your previews, use the <code>PullRequestEnvironmentName</code> property.<br />
  For more information, see <a href="https://docs.aws.amazon.com/amplify/latest/userguide/pr-previews.html">Web Previews</a> in the
  AWS Amplify Console User Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    enablePullRequestPreview?: Value<boolean>;
    /** <code>EnableAutoBuild</code>  <a name="cfn-amplify-branch-enableautobuild"></a>
  Enables auto building for the branch.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    enableAutoBuild?: Value<boolean>;
    /** <code>EnablePerformanceMode</code>  <a name="cfn-amplify-branch-enableperformancemode"></a>
  Enables performance mode for the branch.<br />
  Performance mode optimizes for faster hosting performance by keeping content cached at the edge for a longer interval. When performance mode is enabled, hosting configuration or code changes can take up to 10 minutes to roll out.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    enablePerformanceMode?: Value<boolean>;
    /** <code>BuildSpec</code>  <a name="cfn-amplify-branch-buildspec"></a>
  The build specification (build spec) for the branch.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    buildSpec?: Value<string>;
    /** <code>Stage</code>  <a name="cfn-amplify-branch-stage"></a>
  Describes the current stage for the branch.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    stage?: Value<string>;
    /** <code>BranchName</code>  <a name="cfn-amplify-branch-branchname"></a>
  The name for the branch.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    branchName: Value<string>;
    /** <code>BasicAuthConfig</code>  <a name="cfn-amplify-branch-basicauthconfig"></a>
  The basic authorization credentials for a branch of an Amplify app.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    basicAuthConfig?: BasicAuthConfigProps;
    /** <code>Tags</code>  <a name="cfn-amplify-branch-tags"></a>
  The tag for the branch.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: Tag[];
}
