"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  The AWS::Amplify::App resource creates Apps in the Amplify Console. An App is a collection of branches.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-amplify-app.html">the AWS Docs</a>
*/
function app(appProps) { return ({ ...appProps, _logicalType: 'AWS::Amplify::App', attributes: { AppId: 'AppId', Arn: 'Arn', DefaultDomain: 'DefaultDomain', AppName: 'AppName' } }); }
exports.app = app;
