import { AutoBranchCreationConfigProps } from './app/AutoBranchCreationConfigProps';
import { Value } from '../../kloudformation/Value';
import { EnvironmentVariableProps } from './app/EnvironmentVariableProps';
import { CustomRuleProps } from './app/CustomRuleProps';
import { BasicAuthConfigProps } from './app/BasicAuthConfigProps';
import { Tag } from '../Tag';
import { Attribute } from '../../kloudformation/Attribute';
import { KloudResource } from '../../kloudformation/KloudResource';
export declare type AppAttributes = {
    AppId: Attribute<string>;
    Arn: Attribute<string>;
    DefaultDomain: Attribute<string>;
    AppName: Attribute<string>;
};
export declare type App = AppProperties & {
    attributes: AppAttributes;
};
/**
  The AWS::Amplify::App resource creates Apps in the Amplify Console. An App is a collection of branches.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-amplify-app.html">the AWS Docs</a>
*/
export declare function app(appProps: AppProperties): App;
/**
  The AWS::Amplify::App resource creates Apps in the Amplify Console. An App is a collection of branches.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-amplify-app.html">the AWS Docs</a>
*/
export interface AppProperties extends KloudResource {
    /** <code>AutoBranchCreationConfig</code>  <a name="cfn-amplify-app-autobranchcreationconfig"></a>
  Sets the configuration for your automatic branch creation.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    autoBranchCreationConfig?: AutoBranchCreationConfigProps;
    /** <code>OauthToken</code>  <a name="cfn-amplify-app-oauthtoken"></a>
  The OAuth token for a third-party source control system for an Amplify app. The OAuth token is used to create a webhook and a read-only deploy key. The OAuth token is not stored.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    oauthToken?: Value<string>;
    /** <code>Description</code>  <a name="cfn-amplify-app-description"></a>
  The description for an Amplify app.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>EnableBranchAutoDeletion</code>  <a name="cfn-amplify-app-enablebranchautodeletion"></a>
  Automatically disconnect a branch in the Amplify Console when you delete a branch from your Git repository.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    enableBranchAutoDeletion?: Value<boolean>;
    /** <code>Name</code>  <a name="cfn-amplify-app-name"></a>
  The name for an Amplify app.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    name: Value<string>;
    /** <code>Repository</code>  <a name="cfn-amplify-app-repository"></a>
  The repository for an Amplify app.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    repository?: Value<string>;
    /** <code>EnvironmentVariables</code>  <a name="cfn-amplify-app-environmentvariables"></a>
  The environment variables map for an Amplify app.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    environmentVariables?: EnvironmentVariableProps[];
    /** <code>AccessToken</code>  <a name="cfn-amplify-app-accesstoken"></a>
  Personal Access token for 3rd party source control system for an Amplify App, used to create webhook and read-only deploy key. Token is not stored.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    accessToken?: Value<string>;
    /** <code>BuildSpec</code>  <a name="cfn-amplify-app-buildspec"></a>
  The build specification (build spec) for an Amplify app.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    buildSpec?: Value<string>;
    /** <code>CustomRules</code>  <a name="cfn-amplify-app-customrules"></a>
  The custom rewrite and redirect rules for an Amplify app.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    customRules?: CustomRuleProps[];
    /** <code>BasicAuthConfig</code>  <a name="cfn-amplify-app-basicauthconfig"></a>
  The credentials for basic authorization for an Amplify app.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    basicAuthConfig?: BasicAuthConfigProps;
    /** <code>CustomHeaders</code>  <a name="cfn-amplify-app-customheaders"></a>
  The custom HTTP headers for an Amplify app.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    customHeaders?: Value<string>;
    /** <code>Tags</code>  <a name="cfn-amplify-app-tags"></a>
  The tag for an Amplify app.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: Tag[];
    /** <code>IAMServiceRole</code>  <a name="cfn-amplify-app-iamservicerole"></a>
  The AWS Identity and Access Management (IAM) service role for the Amazon Resource Name (ARN) of the Amplify app.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    iAMServiceRole?: Value<string>;
}
