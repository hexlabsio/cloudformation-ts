import { Value } from '../../../kloudformation/Value';
/**
  The SubDomainSetting property type allows you to connect a subdomain (e.g. foo.yourdomain.com) to a specific branch.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-amplify-domain-subdomainsetting.html">the AWS Docs</a>
*/
export interface SubDomainSettingProps {
    /** <code>Prefix</code>  <a name="cfn-amplify-domain-subdomainsetting-prefix"></a>
  The prefix setting for the subdomain.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    prefix: Value<string>;
    /** <code>BranchName</code>  <a name="cfn-amplify-domain-subdomainsetting-branchname"></a>
  The branch name setting for the subdomain.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    branchName: Value<string>;
}
