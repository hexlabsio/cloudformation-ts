import { Value } from '../../../kloudformation/Value';
/**
  Use the BasicAuthConfig property type to set password protection for a specific branch.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-amplify-branch-basicauthconfig.html">the AWS Docs</a>
*/
export interface BasicAuthConfigProps {
    /** <code>Username</code>  <a name="cfn-amplify-branch-basicauthconfig-username"></a>
  The user name for basic authorization.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    username: Value<string>;
    /** <code>EnableBasicAuth</code>  <a name="cfn-amplify-branch-basicauthconfig-enablebasicauth"></a>
  Enables basic authorization for the branch.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    enableBasicAuth?: Value<boolean>;
    /** <code>Password</code>  <a name="cfn-amplify-branch-basicauthconfig-password"></a>
  The password for basic authorization.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    password: Value<string>;
}
