import { Value } from '../../../kloudformation/Value';
/**
  The EnvironmentVariable property type sets environment variables for a specific branch. Environment variables are key-value pairs that are available at build time.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-amplify-branch-environmentvariable.html">the AWS Docs</a>
*/
export interface EnvironmentVariableProps {
    /** <code>Value</code>  <a name="cfn-amplify-branch-environmentvariable-value"></a>
  The environment variable value.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    value: Value<string>;
    /** <code>Name</code>  <a name="cfn-amplify-branch-environmentvariable-name"></a>
  The environment variable name.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    name: Value<string>;
}
