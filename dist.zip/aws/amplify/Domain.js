"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  The AWS::Amplify::Domain resource allows you to connect a custom domain to your app.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-amplify-domain.html">the AWS Docs</a>
*/
function domain(domainProps) { return ({ ...domainProps, _logicalType: 'AWS::Amplify::Domain', attributes: { AutoSubDomainIAMRole: 'AutoSubDomainIAMRole', DomainName: 'DomainName', StatusReason: 'StatusReason', EnableAutoSubDomain: 'EnableAutoSubDomain', Arn: 'Arn', DomainStatus: 'DomainStatus', AutoSubDomainCreationPatterns: 'AutoSubDomainCreationPatterns', CertificateRecord: 'CertificateRecord' } }); }
exports.domain = domain;
