"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  The AWS::Amplify::Branch resource creates a new branch within an app.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-amplify-branch.html">the AWS Docs</a>
*/
function branch(branchProps) { return ({ ...branchProps, _logicalType: 'AWS::Amplify::Branch', attributes: { BranchName: 'BranchName', Arn: 'Arn' } }); }
exports.branch = branch;
