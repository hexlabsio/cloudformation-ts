import { SubDomainSettingProps } from './domain/SubDomainSettingProps';
import { Value } from '../../kloudformation/Value';
import { Attribute } from '../../kloudformation/Attribute';
import { KloudResource } from '../../kloudformation/KloudResource';
export declare type DomainAttributes = {
    AutoSubDomainIAMRole: Attribute<string>;
    DomainName: Attribute<string>;
    StatusReason: Attribute<string>;
    EnableAutoSubDomain: Attribute<boolean>;
    Arn: Attribute<string>;
    DomainStatus: Attribute<string>;
    AutoSubDomainCreationPatterns: Attribute<string[]>;
    CertificateRecord: Attribute<string>;
};
export declare type Domain = DomainProperties & {
    attributes: DomainAttributes;
};
/**
  The AWS::Amplify::Domain resource allows you to connect a custom domain to your app.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-amplify-domain.html">the AWS Docs</a>
*/
export declare function domain(domainProps: DomainProperties): Domain;
/**
  The AWS::Amplify::Domain resource allows you to connect a custom domain to your app.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-amplify-domain.html">the AWS Docs</a>
*/
export interface DomainProperties extends KloudResource {
    /** <code>SubDomainSettings</code>  <a name="cfn-amplify-domain-subdomainsettings"></a>
  The setting for the subdomain.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    subDomainSettings: SubDomainSettingProps[];
    /** <code>AppId</code>  <a name="cfn-amplify-domain-appid"></a>
  The unique ID for an Amplify app.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    appId: Value<string>;
    /** <code>AutoSubDomainIAMRole</code>  <a name="cfn-amplify-domain-autosubdomainiamrole"></a>
  The required AWS Identity and Access Management (IAM) service role for the Amazon Resource Name (ARN) for automatically creating subdomains.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    autoSubDomainIAMRole?: Value<string>;
    /** <code>DomainName</code>  <a name="cfn-amplify-domain-domainname"></a>
  The domain name for the domain association.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    domainName: Value<string>;
    /** <code>EnableAutoSubDomain</code>  <a name="cfn-amplify-domain-enableautosubdomain"></a>
  Enables the automated creation of subdomains for branches.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    enableAutoSubDomain?: Value<boolean>;
    /** <code>AutoSubDomainCreationPatterns</code>  <a name="cfn-amplify-domain-autosubdomaincreationpatterns"></a>
  Sets the branch patterns for automatic subdomain creation.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    autoSubDomainCreationPatterns?: Value<Value<string>[]>;
}
