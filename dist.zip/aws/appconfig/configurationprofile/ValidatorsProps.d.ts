import { Value } from '../../../kloudformation/Value';
/**
  A validator provides a syntactic or semantic check to ensure the configuration you want to deploy functions as intended. To validate your application configuration data, you provide a schema or a Lambda function that runs against the configuration. The configuration deployment or update can only proceed when the configuration data is valid.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appconfig-configurationprofile-validators.html">the AWS Docs</a>
*/
export interface ValidatorsProps {
    /** <code>Type</code>  <a name="cfn-appconfig-configurationprofile-validators-type"></a>
  AWS AppConfig supports validators of type <code>JSON_SCHEMA</code> and <code>LAMBDA</code><br />
  
  Required: No<br />
  
  Allowed values: <code>JSON_SCHEMA | LAMBDA</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    type?: Value<'JSON_SCHEMA' | 'LAMBDA'>;
    /** <code>Content</code>  <a name="cfn-appconfig-configurationprofile-validators-content"></a>
  Either the JSON Schema content or the Amazon Resource Name (ARN) of an AWS Lambda function.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>32768</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    content?: Value<string>;
}
