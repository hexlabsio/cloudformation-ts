import { Value } from '../../../kloudformation/Value';
/**
  Metadata to assign to the configuration profile. Tags help organize and categorize your AWS AppConfig resources. Each tag consists of a key and an optional value, both of which you define.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appconfig-configurationprofile-tags.html">the AWS Docs</a>
*/
export interface TagsProps {
    /** <code>Value</code>  <a name="cfn-appconfig-configurationprofile-tags-value"></a>
  The tag value can be up to 256 characters.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    value?: Value<string>;
    /** <code>Key</code>  <a name="cfn-appconfig-configurationprofile-tags-key"></a>
  The key-value string map. The valid character set is <code>[a-zA-Z+-=._:/]</code>. The tag key can be up to 128 characters and must not start with <code>aws:</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    key?: Value<string>;
}
