"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function configurationProfile(configurationProfileProps) { return ({ ...configurationProfileProps, _logicalType: 'AWS::AppConfig::ConfigurationProfile' }); }
exports.configurationProfile = configurationProfile;
