"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function deployment(deploymentProps) { return ({ ...deploymentProps, _logicalType: 'AWS::AppConfig::Deployment' }); }
exports.deployment = deployment;
