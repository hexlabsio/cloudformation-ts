"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function application(applicationProps) { return ({ ...applicationProps, _logicalType: 'AWS::AppConfig::Application' }); }
exports.application = application;
