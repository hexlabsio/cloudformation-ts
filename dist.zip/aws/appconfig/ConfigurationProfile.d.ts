import { Value } from '../../kloudformation/Value';
import { ValidatorsProps } from './configurationprofile/ValidatorsProps';
import { TagsProps } from './configurationprofile/TagsProps';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::AppConfig::ConfigurationProfile</code> resource creates a configuration profile that enables AppConfig to access the configuration source. Valid configuration sources include Systems Manager (SSM) documents, SSM Parameter Store parameters, and Amazon S3. A configuration profile includes the following information.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appconfig-configurationprofile.html">the AWS Docs</a>
*/
export declare type ConfigurationProfile = ConfigurationProfileProperties;
export declare function configurationProfile(configurationProfileProps: ConfigurationProfileProperties): ConfigurationProfile;
/**
  The <code>AWS::AppConfig::ConfigurationProfile</code> resource creates a configuration profile that enables AppConfig to access the configuration source. Valid configuration sources include Systems Manager (SSM) documents, SSM Parameter Store parameters, and Amazon S3. A configuration profile includes the following information.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appconfig-configurationprofile.html">the AWS Docs</a>
*/
export interface ConfigurationProfileProperties extends KloudResource {
    /** <code>LocationUri</code>  <a name="cfn-appconfig-configurationprofile-locationuri"></a>
  A URI to locate the configuration. You can specify the AppConfig hosted configuration store, Systems Manager (SSM) document, an SSM Parameter Store parameter, or an Amazon S3 object. For the hosted configuration store, specify <code>hosted</code>. For an SSM document, specify either the document name in the format <code>ssm-document://&lt;Document_name&gt;</code> or the Amazon Resource Name (ARN). For a parameter, specify either the parameter name in the format <code>ssm-parameter://&lt;Parameter_name&gt;</code> or the ARN. For an Amazon S3 object, specify the URI in the following format: <code>s3://&lt;bucket&gt;/&lt;objectKey&gt; </code>. Here is an example: s3://my-bucket/my-app/us-east-1/my-config.json<br />
  
  Required: Yes<br />
  
  Minimum: <code>1</code><br />
  
  Maximum: <code>2048</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    locationUri: Value<string>;
    /** <code>Description</code>  <a name="cfn-appconfig-configurationprofile-description"></a>
  A description of the configuration profile.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>1024</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>Validators</code>  <a name="cfn-appconfig-configurationprofile-validators"></a>
  A list of methods for validating the configuration.<br />
  
  Required: No<br />
  
  Maximum: <code>2</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    validators?: ValidatorsProps[];
    /** <code>RetrievalRoleArn</code>  <a name="cfn-appconfig-configurationprofile-retrievalrolearn"></a>
  The ARN of an IAM role with permission to access the configuration at the specified LocationUri.<br />
  A retrieval role ARN is not required for configurations stored in the AppConfig hosted configuration store. It is required for all other sources that store your configuration.
  
  Required: No<br />
  
  Minimum: <code>20</code><br />
  
  Maximum: <code>2048</code><br />
  
  Pattern: <code>^((arn):(aws|aws-cn|aws-iso|aws-iso-[a-z]{1}|aws-us-gov):(iam)::\d{12}:role[/].*)$</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    retrievalRoleArn?: Value<string>;
    /** <code>ApplicationId</code>  <a name="cfn-appconfig-configurationprofile-applicationid"></a>
  The application ID.<br />
  
  Required: Yes<br />
  
  Pattern: <code>[a-z0-9]{4,7}</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    applicationId: Value<string>;
    /** <code>Tags</code>  <a name="cfn-appconfig-configurationprofile-tags"></a>
  Metadata to assign to the configuration profile. Tags help organize and categorize your AWS AppConfig resources. Each tag consists of a key and an optional value, both of which you define.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: TagsProps[];
    /** <code>Name</code>  <a name="cfn-appconfig-configurationprofile-name"></a>
  A name for the configuration profile.<br />
  
  Required: Yes<br />
  
  Minimum: <code>1</code><br />
  
  Maximum: <code>64</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    name: Value<string>;
}
