"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function environment(environmentProps) { return ({ ...environmentProps, _logicalType: 'AWS::AppConfig::Environment' }); }
exports.environment = environment;
