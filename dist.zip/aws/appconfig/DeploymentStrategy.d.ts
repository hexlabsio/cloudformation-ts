import { Value } from '../../kloudformation/Value';
import { TagsProps } from './deploymentstrategy/TagsProps';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::AppConfig::DeploymentStrategy</code> resource creates an AppConfig deployment strategy. A deployment strategy defines important criteria for rolling out your configuration to the designated targets. A deployment strategy includes: the overall duration required, a percentage of targets to receive the deployment during each interval, an algorithm that defines how percentage grows, and bake time.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appconfig-deploymentstrategy.html">the AWS Docs</a>
*/
export declare type DeploymentStrategy = DeploymentStrategyProperties;
export declare function deploymentStrategy(deploymentStrategyProps: DeploymentStrategyProperties): DeploymentStrategy;
/**
  The <code>AWS::AppConfig::DeploymentStrategy</code> resource creates an AppConfig deployment strategy. A deployment strategy defines important criteria for rolling out your configuration to the designated targets. A deployment strategy includes: the overall duration required, a percentage of targets to receive the deployment during each interval, an algorithm that defines how percentage grows, and bake time.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appconfig-deploymentstrategy.html">the AWS Docs</a>
*/
export interface DeploymentStrategyProperties extends KloudResource {
    /** <code>ReplicateTo</code>  <a name="cfn-appconfig-deploymentstrategy-replicateto"></a>
  Save the deployment strategy to a Systems Manager (SSM) document.<br />
  
  Required: Yes<br />
  
  Allowed values: <code>NONE | SSM_DOCUMENT</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    replicateTo: Value<'NONE' | 'SSM_DOCUMENT'>;
    /** <code>GrowthType</code>  <a name="cfn-appconfig-deploymentstrategy-growthtype"></a>
  The algorithm used to define how percentage grows over time. AWS AppConfig supports the following growth types:<br />
  <strong>Linear</strong>: For this type, AppConfig processes the deployment by dividing the total number of targets by the value specified for <code>Step percentage</code>. For example, a linear deployment that uses a <code>Step percentage</code> of 10 deploys the configuration to 10 percent of the hosts. After those deployments are complete, the system deploys the configuration to the next 10 percent. This continues until 100% of the targets have successfully received the configuration.<br />
  <strong>Exponential</strong>: For this type, AppConfig processes the deployment exponentially using the following formula: <code>G*(2^N)</code>. In this formula, <code>G</code> is the growth factor specified by the user and <code>N</code> is the number of steps until the configuration is deployed to all targets. For example, if you specify a growth factor of 2, then the system rolls out the configuration as follows:<br />
  <code>2*(2^0)</code><br />
  <code>2*(2^1)</code><br />
  <code>2*(2^2)</code><br />
  Expressed numerically, the deployment rolls out as follows: 2% of the targets, 4% of the targets, 8% of the targets, and continues until the configuration has been deployed to all targets.<br />
  
  Required: No<br />
  
  Allowed values: <code>EXPONENTIAL | LINEAR</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    growthType?: Value<'EXPONENTIAL' | 'LINEAR'>;
    /** <code>Description</code>  <a name="cfn-appconfig-deploymentstrategy-description"></a>
  A description of the deployment strategy.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>1024</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>DeploymentDurationInMinutes</code>  <a name="cfn-appconfig-deploymentstrategy-deploymentdurationinminutes"></a>
  Total amount of time for a deployment to last.<br />
  
  Required: Yes<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>1440</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    deploymentDurationInMinutes: Value<number>;
    /** <code>GrowthFactor</code>  <a name="cfn-appconfig-deploymentstrategy-growthfactor"></a>
  The percentage of targets to receive a deployed configuration during each interval.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    growthFactor: Value<number>;
    /** <code>FinalBakeTimeInMinutes</code>  <a name="cfn-appconfig-deploymentstrategy-finalbaketimeinminutes"></a>
  The amount of time AWS AppConfig monitors for alarms before considering the deployment to be complete and no longer eligible for automatic roll back.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>1440</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    finalBakeTimeInMinutes?: Value<number>;
    /** <code>Tags</code>  <a name="cfn-appconfig-deploymentstrategy-tags"></a>
  Metadata to assign to an AWS AppConfig resource. Tags help organize and categorize your AWS AppConfig resources. Each tag consists of a key and an optional value, both of which you define. You can specify a maximum of 50 tags for a resource.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: TagsProps[];
    /** <code>Name</code>  <a name="cfn-appconfig-deploymentstrategy-name"></a>
  A name for the deployment strategy.<br />
  
  Required: Yes<br />
  
  Minimum: <code>1</code><br />
  
  Maximum: <code>64</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    name: Value<string>;
}
