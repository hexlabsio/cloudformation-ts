import { Value } from '../../../kloudformation/Value';
/**
  Amazon CloudWatch alarms to monitor during the deployment process.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appconfig-environment-monitors.html">the AWS Docs</a>
*/
export interface MonitorsProps {
    /** <code>AlarmArn</code>  <a name="cfn-appconfig-environment-monitors-alarmarn"></a>
  ARN of the Amazon CloudWatch alarm.<br />
  
  Required: No<br />
  
  Minimum: <code>20</code><br />
  
  Maximum: <code>2048</code><br />
  
  Pattern: <code>arn:(aws[a-zA-Z-]*)?:[a-z]+:([a-z]{2}((-gov)|(-iso(b?)))?-[a-z]+-\d{1})?:(\d{12})?:[a-zA-Z0-9-_/:.]+</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    alarmArn?: Value<string>;
    /** <code>AlarmRoleArn</code>  <a name="cfn-appconfig-environment-monitors-alarmrolearn"></a>
  ARN of an IAM role for AWS AppConfig to monitor <code>AlarmArn</code>.<br />
  
  Required: No<br />
  
  Minimum: <code>20</code><br />
  
  Maximum: <code>2048</code><br />
  
  Pattern: <code>^((arn):(aws|aws-cn|aws-iso|aws-iso-[a-z]{1}|aws-us-gov):(iam)::\d{12}:role[/].*)$</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    alarmRoleArn?: Value<string>;
}
