import { Value } from '../../kloudformation/Value';
import { TagsProps } from './deployment/TagsProps';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::AppConfig::Deployment</code> resource starts a deployment. Starting a deployment in AWS AppConfig calls the <code>StartDeployment</code> API action. This call includes the IDs of the AppConfig application, the environment, the configuration profile, and (optionally) the configuration data version to deploy. The call also includes the ID of the deployment strategy to use, which determines how the configuration data is deployed.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appconfig-deployment.html">the AWS Docs</a>
*/
export declare type Deployment = DeploymentProperties;
export declare function deployment(deploymentProps: DeploymentProperties): Deployment;
/**
  The <code>AWS::AppConfig::Deployment</code> resource starts a deployment. Starting a deployment in AWS AppConfig calls the <code>StartDeployment</code> API action. This call includes the IDs of the AppConfig application, the environment, the configuration profile, and (optionally) the configuration data version to deploy. The call also includes the ID of the deployment strategy to use, which determines how the configuration data is deployed.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appconfig-deployment.html">the AWS Docs</a>
*/
export interface DeploymentProperties extends KloudResource {
    /** <code>DeploymentStrategyId</code>  <a name="cfn-appconfig-deployment-deploymentstrategyid"></a>
  The deployment strategy ID.<br />
  
  Required: Yes<br />
  
  Pattern: <code>[a-z0-9]{4,7}</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    deploymentStrategyId: Value<string>;
    /** <code>ConfigurationProfileId</code>  <a name="cfn-appconfig-deployment-configurationprofileid"></a>
  The configuration profile ID.<br />
  
  Required: Yes<br />
  
  Pattern: <code>[a-z0-9]{4,7}</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    configurationProfileId: Value<string>;
    /** <code>EnvironmentId</code>  <a name="cfn-appconfig-deployment-environmentid"></a>
  The environment ID.<br />
  
  Required: Yes<br />
  
  Pattern: <code>[a-z0-9]{4,7}</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    environmentId: Value<string>;
    /** <code>Description</code>  <a name="cfn-appconfig-deployment-description"></a>
  A description of the deployment.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>1024</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    description?: Value<string>;
    /** <code>ConfigurationVersion</code>  <a name="cfn-appconfig-deployment-configurationversion"></a>
  The configuration version to deploy.<br />
  
  Required: Yes<br />
  
  Minimum: <code>1</code><br />
  
  Maximum: <code>1024</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    configurationVersion: Value<string>;
    /** <code>ApplicationId</code>  <a name="cfn-appconfig-deployment-applicationid"></a>
  The application ID.<br />
  
  Required: Yes<br />
  
  Pattern: <code>[a-z0-9]{4,7}</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    applicationId: Value<string>;
    /** <code>Tags</code>  <a name="cfn-appconfig-deployment-tags"></a>
  Metadata to assign to the deployment. Tags help organize and categorize your AWS AppConfig resources. Each tag consists of a key and an optional value, both of which you define.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: TagsProps[];
}
