import { Value } from '../../kloudformation/Value';
import { TagsProps } from './application/TagsProps';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::AppConfig::Application</code> resource creates an application, which is a logical unit of code that provides capabilities for your customers. For example, an application can be a microservice that runs on Amazon EC2 instances, a mobile application installed by your users, a serverless application using Amazon API Gateway and AWS Lambda, or any system you run on behalf of others.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appconfig-application.html">the AWS Docs</a>
*/
export declare type Application = ApplicationProperties;
export declare function application(applicationProps: ApplicationProperties): Application;
/**
  The <code>AWS::AppConfig::Application</code> resource creates an application, which is a logical unit of code that provides capabilities for your customers. For example, an application can be a microservice that runs on Amazon EC2 instances, a mobile application installed by your users, a serverless application using Amazon API Gateway and AWS Lambda, or any system you run on behalf of others.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appconfig-application.html">the AWS Docs</a>
*/
export interface ApplicationProperties extends KloudResource {
    /** <code>Description</code>  <a name="cfn-appconfig-application-description"></a>
  A description of the application.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>1024</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>Tags</code>  <a name="cfn-appconfig-application-tags"></a>
  Metadata to assign to the application. Tags help organize and categorize your AWS AppConfig resources. Each tag consists of a key and an optional value, both of which you define.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: TagsProps[];
    /** <code>Name</code>  <a name="cfn-appconfig-application-name"></a>
  A name for the application.<br />
  
  Required: Yes<br />
  
  Minimum: <code>1</code><br />
  
  Maximum: <code>64</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    name: Value<string>;
}
