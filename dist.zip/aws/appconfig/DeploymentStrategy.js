"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function deploymentStrategy(deploymentStrategyProps) { return ({ ...deploymentStrategyProps, _logicalType: 'AWS::AppConfig::DeploymentStrategy' }); }
exports.deploymentStrategy = deploymentStrategy;
