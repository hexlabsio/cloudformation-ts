import { Value } from '../../kloudformation/Value';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  Create a new configuration in the AppConfig hosted configuration store. Configurations must be 64 KB or smaller. The AppConfig hosted configuration store provides the following benefits over other configuration store options.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appconfig-hostedconfigurationversion.html">the AWS Docs</a>
*/
export declare type HostedConfigurationVersion = HostedConfigurationVersionProperties;
export declare function hostedConfigurationVersion(hostedConfigurationVersionProps: HostedConfigurationVersionProperties): HostedConfigurationVersion;
/**
  Create a new configuration in the AppConfig hosted configuration store. Configurations must be 64 KB or smaller. The AppConfig hosted configuration store provides the following benefits over other configuration store options.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appconfig-hostedconfigurationversion.html">the AWS Docs</a>
*/
export interface HostedConfigurationVersionProperties extends KloudResource {
    /** <code>ConfigurationProfileId</code>  <a name="cfn-appconfig-hostedconfigurationversion-configurationprofileid"></a>
  The configuration profile ID.<br />
  
  Required: Yes<br />
  
  Pattern: <code>[a-z0-9]{4,7}</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    configurationProfileId: Value<string>;
    /** <code>Description</code>  <a name="cfn-appconfig-hostedconfigurationversion-description"></a>
  A description of the configuration.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>1024</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    description?: Value<string>;
    /** <code>ContentType</code>  <a name="cfn-appconfig-hostedconfigurationversion-contenttype"></a>
  A standard MIME type describing the format of the configuration content. For more information, see <a href="https://www.w3.org/Protocols/rfc2616/rfc2616-sec14.html#sec14.17">Content-Type</a>.<br />
  
  Required: Yes<br />
  
  Minimum: <code>1</code><br />
  
  Maximum: <code>255</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    contentType: Value<string>;
    /** <code>LatestVersionNumber</code>  <a name="cfn-appconfig-hostedconfigurationversion-latestversionnumber"></a>
  An optional locking token used to prevent race conditions from overwriting configuration updates when creating a new version. To ensure your data is not overwritten when creating multiple hosted configuration versions in rapid succession, specify the version number of the latest hosted configuration version.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    latestVersionNumber?: Value<number>;
    /** <code>Content</code>  <a name="cfn-appconfig-hostedconfigurationversion-content"></a>
  The content of the configuration or the configuration data.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    content: Value<string>;
    /** <code>ApplicationId</code>  <a name="cfn-appconfig-hostedconfigurationversion-applicationid"></a>
  The application ID.<br />
  
  Required: Yes<br />
  
  Pattern: <code>[a-z0-9]{4,7}</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    applicationId: Value<string>;
}
