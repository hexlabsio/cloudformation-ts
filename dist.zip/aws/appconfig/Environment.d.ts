import { Value } from '../../kloudformation/Value';
import { MonitorsProps } from './environment/MonitorsProps';
import { TagsProps } from './environment/TagsProps';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  The <code>AWS::AppConfig::Environment</code> resource creates an environment, which is a logical deployment group of AppConfig targets, such as applications in a <code>Beta</code> or <code>Production</code> environment. You define one or more environments for each AppConfig application. You can also define environments for application subcomponents such as the <code>Web</code>, <code>Mobile</code> and <code>Back-end</code> components for your application. You can configure Amazon CloudWatch alarms for each environment. The system monitors alarms during a configuration deployment. If an alarm is triggered, the system rolls back the configuration.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appconfig-environment.html">the AWS Docs</a>
*/
export declare type Environment = EnvironmentProperties;
export declare function environment(environmentProps: EnvironmentProperties): Environment;
/**
  The <code>AWS::AppConfig::Environment</code> resource creates an environment, which is a logical deployment group of AppConfig targets, such as applications in a <code>Beta</code> or <code>Production</code> environment. You define one or more environments for each AppConfig application. You can also define environments for application subcomponents such as the <code>Web</code>, <code>Mobile</code> and <code>Back-end</code> components for your application. You can configure Amazon CloudWatch alarms for each environment. The system monitors alarms during a configuration deployment. If an alarm is triggered, the system rolls back the configuration.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appconfig-environment.html">the AWS Docs</a>
*/
export interface EnvironmentProperties extends KloudResource {
    /** <code>Description</code>  <a name="cfn-appconfig-environment-description"></a>
  A description of the environment.<br />
  
  Required: No<br />
  
  Minimum: <code>0</code><br />
  
  Maximum: <code>1024</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    description?: Value<string>;
    /** <code>Monitors</code>  <a name="cfn-appconfig-environment-monitors"></a>
  Amazon CloudWatch alarms to monitor during the deployment process.<br />
  
  Required: No<br />
  
  Maximum: <code>5</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    monitors?: MonitorsProps[];
    /** <code>ApplicationId</code>  <a name="cfn-appconfig-environment-applicationid"></a>
  The application ID.<br />
  
  Required: Yes<br />
  
  Pattern: <code>[a-z0-9]{4,7}</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    applicationId: Value<string>;
    /** <code>Tags</code>  <a name="cfn-appconfig-environment-tags"></a>
  Metadata to assign to the environment. Tags help organize and categorize your AWS AppConfig resources. Each tag consists of a key and an optional value, both of which you define.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: TagsProps[];
    /** <code>Name</code>  <a name="cfn-appconfig-environment-name"></a>
  A name for the environment.<br />
  
  Required: Yes<br />
  
  Minimum: <code>1</code><br />
  
  Maximum: <code>64</code><br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    name: Value<string>;
}
