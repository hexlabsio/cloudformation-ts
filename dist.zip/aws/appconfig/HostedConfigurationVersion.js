"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function hostedConfigurationVersion(hostedConfigurationVersionProps) { return ({ ...hostedConfigurationVersionProps, _logicalType: 'AWS::AppConfig::HostedConfigurationVersion' }); }
exports.hostedConfigurationVersion = hostedConfigurationVersion;
