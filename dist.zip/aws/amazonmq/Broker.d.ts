import { Value } from '../../kloudformation/Value';
import { ConfigurationIdProps } from './broker/ConfigurationIdProps';
import { MaintenanceWindowProps } from './broker/MaintenanceWindowProps';
import { UserProps } from './broker/UserProps';
import { LogListProps } from './broker/LogListProps';
import { LdapServerMetadataProps } from './broker/LdapServerMetadataProps';
import { EncryptionOptionsProps } from './broker/EncryptionOptionsProps';
import { TagsEntryProps } from './broker/TagsEntryProps';
import { Attribute } from '../../kloudformation/Attribute';
import { KloudResource } from '../../kloudformation/KloudResource';
export declare type BrokerAttributes = {
    IpAddresses: Attribute<string[]>;
    OpenWireEndpoints: Attribute<string[]>;
    ConfigurationRevision: Attribute<number>;
    StompEndpoints: Attribute<string[]>;
    MqttEndpoints: Attribute<string[]>;
    AmqpEndpoints: Attribute<string[]>;
    Arn: Attribute<string>;
    ConfigurationId: Attribute<string>;
    WssEndpoints: Attribute<string[]>;
};
export declare type Broker = BrokerProperties & {
    attributes: BrokerAttributes;
};
/**
  A <em>broker</em> is a message broker environment running on Amazon MQ. It is the basic building block of Amazon MQ.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-amazonmq-broker.html">the AWS Docs</a>
*/
export declare function broker(brokerProps: BrokerProperties): Broker;
/**
  A <em>broker</em> is a message broker environment running on Amazon MQ. It is the basic building block of Amazon MQ.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-amazonmq-broker.html">the AWS Docs</a>
*/
export interface BrokerProperties extends KloudResource {
    /** <code>SecurityGroups</code>  <a name="cfn-amazonmq-broker-securitygroups"></a>
  The list of rules (1 minimum, 125 maximum) that authorize connections to brokers.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    securityGroups?: Value<Value<string>[]>;
    /** <code>StorageType</code>  <a name="cfn-amazonmq-broker-storagetype"></a>
  The broker’s storage type.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    storageType?: Value<string>;
    /** <code>EngineVersion</code>  <a name="cfn-amazonmq-broker-engineversion"></a>
  The version of the broker engine. For a list of supported engine versions, see <a href="https://docs.aws.amazon.com/amazon-mq/latest/developer-guide/broker-engine.html">Engine</a> in the
  Amazon MQ Developer Guide: br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    engineVersion: Value<string>;
    /** <code>Configuration</code>  <a name="cfn-amazonmq-broker-configuration"></a>
  A list of information about the configuration. Does not apply to RabbitMQ brokers.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-some-interrupt">Some interruptions</a> */
    configuration?: ConfigurationIdProps;
    /** <code>AuthenticationStrategy</code>  <a name="cfn-amazonmq-broker-authenticationstrategy"></a>
  Optional. The authentication strategy used to secure the broker. The default is <code>SIMPLE</code>.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    authenticationStrategy?: Value<string>;
    /** <code>MaintenanceWindowStartTime</code>  <a name="cfn-amazonmq-broker-maintenancewindowstarttime"></a>
  The scheduled time period relative to UTC during which Amazon MQ begins to apply pending updates or patches to the broker.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    maintenanceWindowStartTime?: MaintenanceWindowProps;
    /** <code>HostInstanceType</code>  <a name="cfn-amazonmq-broker-hostinstancetype"></a>
  The broker’s instance type.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-some-interrupt">Some interruptions</a> */
    hostInstanceType: Value<string>;
    /** <code>AutoMinorVersionUpgrade</code>  <a name="cfn-amazonmq-broker-autominorversionupgrade"></a>
  Enables automatic upgrades to new minor versions for brokers, as new engine versions are released. The automatic upgrades occur during the maintenance window of the broker or after a manual broker reboot.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    autoMinorVersionUpgrade: Value<boolean>;
    /** <code>Users</code>  <a name="cfn-amazonmq-broker-users"></a>
  The list of ActiveMQ users (persons or applications) who can access queues and topics. For RabbitMQ brokers, one and only one administrative user is accepted and created when a broker is first provisioned. All subsequent RabbitMQ users are created by via the RabbitMQ web console or by using the RabbitMQ management API. This value can contain only alphanumeric characters, dashes, periods, underscores, and tildes (- . _ ~). This value must be 2-100 characters long.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    users: UserProps[];
    /** <code>Logs</code>  <a name="cfn-amazonmq-broker-logs"></a>
  Enables Amazon CloudWatch logging for brokers.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    logs?: LogListProps;
    /** <code>SubnetIds</code>  <a name="cfn-amazonmq-broker-subnetids"></a>
  The list of groups that define which subnets and IP ranges the broker can use from different Availability Zones. If you specify more than one subnet, the subnets must be in different Availability Zones. Amazon MQ will not be able to create VPC endpoints for your broker with multiple subnets in the same Availability Zone. A SINGLE_INSTANCE deployment requires one subnet (for example, the default subnet). An ACTIVE_STANDBY_MULTI_AZ deployment (ACTIVEMQ) requires two subnets. A CLUSTER_MULTI_AZ deployment (RABBITMQ) has no subnet requirements when deployed with public accessibility, deployment without public accessibility requires at least one subnet.<br />
  If you specify subnets in a shared VPC for a RabbitMQ broker, the associated VPC to which the specified subnets belong must be owned by your AWS account. Amazon MQ will not be able to create VPC enpoints in VPCs that are not owned by your AWS account.
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    subnetIds?: Value<Value<string>[]>;
    /** <code>BrokerName</code>  <a name="cfn-amazonmq-broker-brokername"></a>
  The name of the broker. This value must be unique in your AWS account, 1-50 characters long, must contain only letters, numbers, dashes, and underscores, and must not contain white spaces, brackets, wildcard characters, or special characters.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    brokerName: Value<string>;
    /** <code>LdapServerMetadata</code>  <a name="cfn-amazonmq-broker-ldapservermetadata"></a>
  Optional. The metadata of the LDAP server used to authenticate and authorize connections to the broker. Does not apply to RabbitMQ brokers.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    ldapServerMetadata?: LdapServerMetadataProps;
    /** <p> */
    deploymentMode: Value<string>;
    /** <code>EngineType</code>  <a name="cfn-amazonmq-broker-enginetype"></a>
  The type of broker engine. Currently, Amazon MQ supports ACTIVEMQ and RABBITMQ.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    engineType: Value<string>;
    /** <code>PubliclyAccessible</code>  <a name="cfn-amazonmq-broker-publiclyaccessible"></a>
  Enables connections from applications outside of the VPC that hosts the broker’s subnets.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    publiclyAccessible: Value<boolean>;
    /** <code>EncryptionOptions</code>  <a name="cfn-amazonmq-broker-encryptionoptions"></a>
  Encryption options for the broker. Does not apply to RabbitMQ brokers.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    encryptionOptions?: EncryptionOptionsProps;
    /** <code>Tags</code>  <a name="cfn-amazonmq-broker-tags"></a>
  An array of key-value pairs. For more information, see <a href="https://docs.aws.amazon.com/awsaccountbilling/latest/aboutv2/cost-alloc-tags.html">Using Cost Allocation Tags</a> in the
  AWS Billing and Cost Management User Guide: br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    tags?: TagsEntryProps[];
}
