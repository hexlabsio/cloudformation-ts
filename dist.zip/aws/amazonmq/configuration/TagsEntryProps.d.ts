import { Value } from '../../../kloudformation/Value';
/**
  A key-value pair to associate with the configuration.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-amazonmq-configuration-tagsentry.html">the AWS Docs</a>
*/
export interface TagsEntryProps {
    /** <code>Value</code>  <a name="cfn-amazonmq-configuration-tagsentry-value"></a>
  The value in a key-value pair.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    value: Value<string>;
    /** <code>Key</code>  <a name="cfn-amazonmq-configuration-tagsentry-key"></a>
  The key in a key-value pair.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    key: Value<string>;
}
