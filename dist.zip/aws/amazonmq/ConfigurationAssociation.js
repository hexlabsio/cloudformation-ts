"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function configurationAssociation(configurationAssociationProps) { return ({ ...configurationAssociationProps, _logicalType: 'AWS::AmazonMQ::ConfigurationAssociation' }); }
exports.configurationAssociation = configurationAssociation;
