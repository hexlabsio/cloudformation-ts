import { Value } from '../../kloudformation/Value';
import { ConfigurationIdProps } from './configurationassociation/ConfigurationIdProps';
import { KloudResource } from '../../kloudformation/KloudResource';
/**
  Use the AWS CloudFormation <code>AWS::AmazonMQ::ConfigurationAssociation</code> resource to associate a configuration with a broker, or return information about the specified ConfigurationAssociation. Only use one per broker, and don’t use a configuration on the broker resource if you have associated a configuration with that broker.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-amazonmq-configurationassociation.html">the AWS Docs</a>
*/
export declare type ConfigurationAssociation = ConfigurationAssociationProperties;
export declare function configurationAssociation(configurationAssociationProps: ConfigurationAssociationProperties): ConfigurationAssociation;
/**
  Use the AWS CloudFormation <code>AWS::AmazonMQ::ConfigurationAssociation</code> resource to associate a configuration with a broker, or return information about the specified ConfigurationAssociation. Only use one per broker, and don’t use a configuration on the broker resource if you have associated a configuration with that broker.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-amazonmq-configurationassociation.html">the AWS Docs</a>
*/
export interface ConfigurationAssociationProperties extends KloudResource {
    /** <code>Broker</code>  <a name="cfn-amazonmq-configurationassociation-broker"></a>
  The broker to associate with a configuration.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement">Replacement</a> */
    broker: Value<string>;
    /** <code>Configuration</code>  <a name="cfn-amazonmq-configurationassociation-configuration"></a>
  The configuration to associate with a broker.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    configuration: ConfigurationIdProps;
}
