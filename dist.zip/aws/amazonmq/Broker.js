"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  A <em>broker</em> is a message broker environment running on Amazon MQ. It is the basic building block of Amazon MQ.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-amazonmq-broker.html">the AWS Docs</a>
*/
function broker(brokerProps) { return ({ ...brokerProps, _logicalType: 'AWS::AmazonMQ::Broker', attributes: { IpAddresses: 'IpAddresses', OpenWireEndpoints: 'OpenWireEndpoints', ConfigurationRevision: 'ConfigurationRevision', StompEndpoints: 'StompEndpoints', MqttEndpoints: 'MqttEndpoints', AmqpEndpoints: 'AmqpEndpoints', Arn: 'Arn', ConfigurationId: 'ConfigurationId', WssEndpoints: 'WssEndpoints' } }); }
exports.broker = broker;
