"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
  Creates a new configuration for the specified configuration name. Amazon MQ uses the default configuration (the engine type and version).
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-amazonmq-configuration.html">the AWS Docs</a>
*/
function configuration(configurationProps) { return ({ ...configurationProps, _logicalType: 'AWS::AmazonMQ::Configuration', attributes: { Revision: 'Revision', Id: 'Id', Arn: 'Arn' } }); }
exports.configuration = configuration;
