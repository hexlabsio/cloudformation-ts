import { Value } from '../../../kloudformation/Value';
/**
  Encryption options for the broker.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-amazonmq-broker-encryptionoptions.html">the AWS Docs</a>
*/
export interface EncryptionOptionsProps {
    /** <code>KmsKeyId</code>  <a name="cfn-amazonmq-broker-encryptionoptions-kmskeyid"></a>
  The customer master key (CMK) to use for the AWS Key Management Service (KMS). This key is used to encrypt your data at rest. If not provided, Amazon MQ will use a default CMK to encrypt your data.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    kmsKeyId?: Value<string>;
    /** <code>UseAwsOwnedKey</code>  <a name="cfn-amazonmq-broker-encryptionoptions-useawsownedkey"></a>
  Enables the use of an AWS owned CMK using AWS Key Management Service (KMS). Set to <code>true</code> by default, if no value is provided, for example, for RabbitMQ brokers.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    useAwsOwnedKey: Value<boolean>;
}
