import { Value } from '../../../kloudformation/Value';
/**
  Optional. The metadata of the LDAP server used to authenticate and authorize connections to the broker.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-amazonmq-broker-ldapservermetadata.html">the AWS Docs</a>
*/
export interface LdapServerMetadataProps {
    /** <code>Hosts</code>  <a name="cfn-amazonmq-broker-ldapservermetadata-hosts"></a>
  Specifies the location of the LDAP server such as AWS Directory Service for Microsoft Active Directory. Optional failover server.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    hosts: Value<Value<string>[]>;
    /** <code>UserRoleName</code>  <a name="cfn-amazonmq-broker-ldapservermetadata-userrolename"></a>
  The name of the LDAP attribute in the user’s directory entry for the user’s group membership. In some cases, user roles may be identified by the value of an attribute in the user’s directory entry. The <code>UserRoleName</code> option allows you to provide the name of this attribute.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    userRoleName?: Value<string>;
    /** <code>UserSearchMatching</code>  <a name="cfn-amazonmq-broker-ldapservermetadata-usersearchmatching"></a>
  The LDAP search filter used to find users within the <code>userBase</code>. The client’s username is substituted into the <code>{0}</code> placeholder in the search filter. For example, if this option is set to <code>(uid={0})</code> and the received username is <code>janedoe</code>, the search filter becomes <code>(uid=janedoe)</code> after string substitution. It will result in matching an entry like <code>uid=janedoe</code>, <code>ou=Users</code>, <code>ou=corp</code>, <code>dc=corp</code>, <code>dc=example</code>, <code>dc=com</code>.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    userSearchMatching: Value<string>;
    /** <code>RoleName</code>  <a name="cfn-amazonmq-broker-ldapservermetadata-rolename"></a>
  The group name attribute in a role entry whose value is the name of that role. For example, you can specify <code>cn</code> for a group entry’s common name. If authentication succeeds, then the user is assigned the the value of the <code>cn</code> attribute for each role entry that they are a member of.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    roleName?: Value<string>;
    /** <code>UserBase</code>  <a name="cfn-amazonmq-broker-ldapservermetadata-userbase"></a>
  Select a particular subtree of the directory information tree (DIT) to search for user entries. The subtree is specified by a DN, which specifies the base node of the subtree. For example, by setting this option to <code>ou=Users</code>,<code>ou=corp</code>, <code>dc=corp</code>, <code>dc=example</code>, <code>dc=com</code>, the search for user entries is restricted to the subtree beneath <code>ou=Users</code>,<code>ou=corp</code>, <code>dc=corp</code>, <code>dc=example</code>, <code>dc=com</code>.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    userBase: Value<string>;
    /** <code>UserSearchSubtree</code>  <a name="cfn-amazonmq-broker-ldapservermetadata-usersearchsubtree"></a>
  The directory search scope for the user. If set to true, scope is to search the entire subtree.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    userSearchSubtree?: Value<boolean>;
    /** <code>RoleSearchMatching</code>  <a name="cfn-amazonmq-broker-ldapservermetadata-rolesearchmatching"></a>
  The LDAP search filter used to find roles within the roleBase. The distinguished name of the user matched by userSearchMatching is substituted into the <code>{0}</code> placeholder in the search filter. The client’s username is substituted into the <code>{1}</code> placeholder. For example, if you set this option to <code>(member=uid={1})</code> for the user janedoe, the search filter becomes <code>(member=uid=janedoe)</code> after string substitution. It matches all role entries that have a member attribute equal to <code>uid=janedoe</code> under the subtree selected by the <code>RoleBases</code>.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    roleSearchMatching: Value<string>;
    /** <code>ServiceAccountUsername</code>  <a name="cfn-amazonmq-broker-ldapservermetadata-serviceaccountusername"></a>
  Service account username. A service account is an account in your LDAP server that has access to initiate a connection. For example, <code>cn=admin</code>, <code>ou=corp</code>, <code>dc=corp</code>, <code>dc=example</code>, <code>dc=com</code>.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    serviceAccountUsername: Value<string>;
    /** <code>RoleBase</code>  <a name="cfn-amazonmq-broker-ldapservermetadata-rolebase"></a>
  The distinguished name of the node in the directory information tree (DIT) to search for roles or groups. For example, <code>ou=group</code>, <code>ou=corp</code>, <code>dc=corp</code>, <code>dc=example</code>, <code>dc=com</code>.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    roleBase: Value<string>;
    /** <code>ServiceAccountPassword</code>  <a name="cfn-amazonmq-broker-ldapservermetadata-serviceaccountpassword"></a>
  Service account password. A service account is an account in your LDAP server that has access to initiate a connection. For example, <code>cn=admin</code>,<code>dc=corp</code>, <code>dc=example</code>, <code>dc=com</code>.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    serviceAccountPassword: Value<string>;
    /** <code>RoleSearchSubtree</code>  <a name="cfn-amazonmq-broker-ldapservermetadata-rolesearchsubtree"></a>
  The directory search scope for the role. If set to true, scope is to search the entire subtree.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    roleSearchSubtree?: Value<boolean>;
}
