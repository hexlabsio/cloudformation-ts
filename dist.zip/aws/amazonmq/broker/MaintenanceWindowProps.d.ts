import { Value } from '../../../kloudformation/Value';
/**
  The parameters that determine the <code>WeeklyStartTime</code> to apply pending updates or patches to the broker.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-amazonmq-broker-maintenancewindow.html">the AWS Docs</a>
*/
export interface MaintenanceWindowProps {
    /** <code>DayOfWeek</code>  <a name="cfn-amazonmq-broker-maintenancewindow-dayofweek"></a>
  The day of the week.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    dayOfWeek: Value<string>;
    /** <code>TimeOfDay</code>  <a name="cfn-amazonmq-broker-maintenancewindow-timeofday"></a>
  The time, in 24-hour format.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    timeOfDay: Value<string>;
    /** <code>TimeZone</code>  <a name="cfn-amazonmq-broker-maintenancewindow-timezone"></a>
  The time zone, UTC by default, in either the Country/City format, or the UTC offset format.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    timeZone: Value<string>;
}
