import { Value } from '../../../kloudformation/Value';
/**
  The list of information about logs to be enabled for the specified broker.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-amazonmq-broker-loglist.html">the AWS Docs</a>
*/
export interface LogListProps {
    /** <code>Audit</code>  <a name="cfn-amazonmq-broker-loglist-audit"></a>
  Enables audit logging. Every user management action made using JMX or the ActiveMQ Web Console is logged. Does not apply to RabbitMQ brokers.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    audit?: Value<boolean>;
    /** <code>General</code>  <a name="cfn-amazonmq-broker-loglist-general"></a>
  Enables general logging.<br />
  
  Required: No<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    general?: Value<boolean>;
}
