import { Value } from '../../../kloudformation/Value';
/**
  A list of information about the configuration.
  For full documentation go to <a href="http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-amazonmq-broker-configurationid.html">the AWS Docs</a>
*/
export interface ConfigurationIdProps {
    /** <code>Revision</code>  <a name="cfn-amazonmq-broker-configurationid-revision"></a>
  The revision number of the configuration.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    revision: Value<number>;
    /** <code>Id</code>  <a name="cfn-amazonmq-broker-configurationid-id"></a>
  The unique ID that Amazon MQ generates for the configuration.<br />
  
  Required: Yes<br />
  
  Update requires: <a href="https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-no-interrupt">No interruption</a> */
    id: Value<string>;
}
